import fs from 'node:fs';import path from 'node:path';
const variant=process.argv[2];const {importFreshArtifact}=await import('./fresh-'+variant+'.mjs');const root=path.join(import.meta.dirname,'identity-'+variant);fs.mkdirSync(root,{recursive:true});
fs.writeFileSync(path.join(root,'entry.mjs'),"import item from './bridge.cjs';export default item;");
fs.writeFileSync(path.join(root,'bridge.cjs'),`const child=module.require('./child.cjs'); module.exports={path:module.path,dirname:__dirname,filename:module.filename,childNamesParent:child.parent===module,parentIncludesChild:module.children.includes(child.self),childSelfMatchesParentChildren:child.parent?.children.includes(child.self) ?? null,constructorInstance:module instanceof require('node:module').Module,childParentPath:child.parent?.path ?? null};`);
fs.writeFileSync(path.join(root,'child.cjs'),`module.exports={self:module,parent:module.parent};`);
console.log(JSON.stringify({variant,node:process.version,result:(await importFreshArtifact(path.join(root,'entry.mjs'))).default}));
