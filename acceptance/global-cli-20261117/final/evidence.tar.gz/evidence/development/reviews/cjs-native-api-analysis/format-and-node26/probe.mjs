import fs from 'node:fs';import path from 'node:path';
const method=process.argv[2];const depth=Number(process.argv[3]||2);
const loader=await import('./fresh-'+(process.argv[4]||'percall')+'.mjs');const root=path.join(import.meta.dirname,method+'-'+depth);fs.mkdirSync(root,{recursive:true});const entry=path.join(root,'entry.mjs');
fs.writeFileSync(entry,"import item from './bridge.cjs';export default item;");
for(let n=0;n<depth;n++){
const name=n===0?'bridge.cjs':'hop'+n+'.cjs';const next=n===depth-1?'value.cjs':'hop'+(n+1)+'.cjs';
fs.writeFileSync(path.join(root,name),`const first=${method}('./${next}');module.exports={eager:first.eager??first.value,read:()=>{const next=${method}('./${next}');return next.read?next.read():next.value},self:module,first,dirname:__dirname,filename:__filename,readFile:()=>${method}('node:fs').readFileSync(__filename,'utf8')};`);
}
fs.writeFileSync(path.join(root,'value.cjs'),'module.exports={value:1,self:module};');
let result;try{
const old=(await loader.importFreshArtifact(entry)).default;const initial=[old.eager,old.read()];
fs.writeFileSync(path.join(root,'value.cjs'),'module.exports={value:999,self:module};');
const current=(await loader.importFreshArtifact(entry)).default;
const alternating=[old.read(),current.read(),old.read(),current.read()];
const graph={parent:old.first.self.parent===old.self,children:old.self.children.includes(old.first.self),instance:old.self instanceof (await import('node:module')).Module,filename:old.filename,dirname:old.dirname,fileReads:old.readFile().startsWith('const first=')};
result={method,depth,initial,current:current.eager,alternating,graph,events:loader.probeEvents};console.log(JSON.stringify(result));
}catch(e){console.error(e);console.log(JSON.stringify({method,depth,events:loader.probeEvents}));process.exitCode=1;}
