import fs from 'node:fs';import path from 'node:path';import {importFreshArtifact} from './fresh-dir.mjs';
const root=path.join(import.meta.dirname,process.argv[2]);fs.mkdirSync(root,{recursive:true});
fs.writeFileSync(path.join(root,'entry.mjs'),"import item from './bridge.cjs';export default item;");
const method=process.argv[2]==='require'?'require':'module.require';
fs.writeFileSync(path.join(root,'bridge.cjs'),`module.exports = ${method}('./helper.cjs');`);
fs.writeFileSync(path.join(root,'helper.cjs'),'module.exports={value:1}');
try{console.log('initial',(await importFreshArtifact(path.join(root,'entry.mjs'))).default.value);fs.writeFileSync(path.join(root,'helper.cjs'),'module.exports={value:999}');console.log('changed',(await importFreshArtifact(path.join(root,'entry.mjs'))).default.value);}catch(e){console.error(e);process.exitCode=1;}
