# Independent diagnosis: Linux included-SDK repair

Cligent PR 101 / head 395fa71 / 0.40.0-rc.1. This is diagnosis and early implementation review, not formal acceptance, merge approval or publication. No product repository, user authentication or user configuration was modified. All installation and fault mutations were confined to unique scratch package trees.

## Conclusion

The original printed repair is a confirmed P1 installation-repair defect on Linux Node 22.23.4 / npm 10.9.9. I reproduced the CI TypeError after installing only the candidate tarball globally and deleting the actual selected Codex native package. The npm failure occurs while resolving Cligent's Vitest DEVELOPMENT peer graph, before native extraction. --omit=dev omits physical development installation but does not prevent npm from building that dependency graph.

Do not use --legacy-peer-deps alone as the final fix. It repairs native availability but removes Claude's declared non-optional Anthropic and MCP SDK peers. Current bundled SDK imports still pass without those packages, so a green availability probe would mask the incomplete dependency contract.

The verified repair direction is an isolated temporary production manifest: clone the installed owner's runtime dependencies, omit development dependencies only in that temporary copy, apply BOTH exact SDK targets from Cligent's descriptor, and run npm's normal peer-aware install there. Restore the validated staged packages into the real owner tree while preserving the original manifest and unrelated optional/host packages. This avoids the failing development graph without disabling required peer resolution or changing SDK floors.

## Original CI and faithful reproduction

Original failure: /tmp/cligent-job.log lines 197–206, Node v22.23.4; line 143 identifies npm 10.9.9. It prints the owner-root command with --omit=dev --save-prod --no-save and the two exact SDK specs, then Cannot read properties of null (reading edgesOut). The original verifier deleted its temporary cache in finally, so that CI log does not retain the full npm debug stack or explicitly identify which loop fault failed.

Test VM identity was verified using the home-esxi-test Skill: Ubuntu VM 75, codex-ubuntu, powered on, expected SSH host bobo@192.168.1.17, Linux x86_64. Unique remote root: /home/bobo/sdk-linux-repair-review-YLeQlD. Portable Node 22.23.4 was obtained from the official immutable Node distribution URL; it bundles npm 10.9.9, matching CI. The existing separate portable Node 25.5.0 plus an isolated npm 10.9.9 installation supplied comparison controls.

Candidate tarball was packed with --ignore-scripts from the local committed candidate context into scratch, without rebuilding/modifying the repository. SHA-256: 7abdb05015d6af58e0da46260db317adbc5a83a8be28828e06780d141c40170e. It predates the proposed new helper and is not proof of that helper's implementation.

Faithful Linux Node22 case:
- Ordinary global tarball-only install, scripts ignored, no separately supplied SDK: exit 0, 35.959s; both actual SDK/native adapters were initially available.
- Delete the native package located by the installed Codex runtime probe, retaining the rest of the installed global tree and hidden metadata.
- Execute the original repair argv, project scope at the installed Cligent root: exit 1, 45.348s, same edgesOut error.
- Repeat with --package-lock=false: exit 1, 10.727s.
- Repeat with --package-lock=false --install-strategy=nested: exit 1, 11.240s.

All exact argv, statuses, probes and manifest hash are in linux22-summary.json. The debug files were directed outside the installed tree and retained.

## Root-cause evidence and limits

The primary reproduced stack is linux22-debug/2026-11-17T17_26_20_134Z-debug-0.log, lines 1208 onwards:

    #loadPeerSet
    npm/node_modules/@npmcli/arborist/lib/arborist/build-ideal-tree.js:1289:38
    const parentEdge = node.parent.edgesOut.get(edge.name)

It recursively fails building the ideal tree. The unfinished timer is idealTree:node_modules/vitest. Immediately preceding requests include @vitest/browser-playwright 5.1.0 and vitest 4.1.12, unrelated to normal SDK installation. No Vitest runtime is required by Cligent users.

The installed Cligent manifest repeats each included SDK as an open ordinary range and an independent exact development target. This is intentional policy and must remain. The old repair uses --save-prod --no-save plus BOTH SDK specs to avoid npm treating them as omitted dev-only edges and to avoid pruning the other SDK. Those safeguards do not prevent npm from resolving other root development peers.

This diagnosis establishes the exact failing graph/path, not a complete upstream explanation for every Arborist scheduling/runtime difference. Mac Node25.5/npm11.8 had previously passed all four faults. Additional real Mac Node25.5/npm10.9.9 tests passed both native repair and missing-Claude-SDK repair, including repository-cwd invocation; several dry-run strategy controls also passed but are not treated as actual repair proof. Linux Node25.5/npm10.9.9 completed an additional direct repair control, but that setup used an initial --omit=optional install and did not recreate the precise deleted-native/hidden-lock state. Therefore neither OS alone nor npm major alone is established as the sole trigger, and upgrading only CI's npm would not be a principled product fix.

## legacy-peer-deps: apparent success, incomplete repair

On the reproduced Linux Node22 failure tree, appending only --legacy-peer-deps to the original repair returned 0 in about 21s. It restored Codex native resolution and both adapter availability probes. The installed Cligent manifest remained unchanged.

However, npm reported removed 8 packages and audited only 13. Independent lookup FROM THE PHYSICAL CLAUDE SDK found:
- @anthropic-ai/sdk, declared required range >=0.93.0: absent.
- @modelcontextprotocol/sdk, declared required range ^1.29.0: absent.
- zod, declared required range ^4.0.0: present at 4.6.6.

SDK import and createSdkMcpServer construction still passed with the SDK's currently bundled code. That is a useful limit: no model-call failure is claimed, but the non-optional SDK dependency graph is demonstrably incomplete. This flag would not alter ordinary SLC installation if confined to the printed repair; it would still degrade a normally installed tree when the user executes that repair. Do not infer completeness from process exit 0, native existence or isAvailable alone.

Evidence: linux22-legacy-repair.log/.exit, linux22-legacy-after.json, linux22-legacy-peers.json, linux22-legacy-debug/.

## Production staging: verified mechanism

The experiment wrote a new scratch manifest cloned from the installed owner's metadata/runtime dependencies, removing devDependencies and scripts ONLY FROM THAT TEMPORARY COPY and marking it private. It copied the compiled library solely to run independent staged ownership probes. No source pin or original manifest was changed.

Using the SAME Linux Node22.23.4/npm10.9.9, normal peer resolution and the two descriptor exact SDK specs, the isolated production install returned 0 in 35.299s: 114 packages added, 115 audited, zero reported vulnerabilities. Both staged SDK/native probes passed, as did complete peer lookup.

For this mechanism experiment, I moved the old scratch owner's node_modules aside and moved the staged node_modules into the SAME actual owner location. After the move:
- Claude 0.3.325 and Codex 0.159.1 resolved from that installed Cligent tree; both native executables were present and both adapters were available.
- Required Claude peers resolved from its physical SDK context: @anthropic-ai/sdk 1.9.0, @modelcontextprotocol/sdk 1.32.2, zod 4.6.6.
- SDK import and credential-free MCP server construction passed.
- No Vitest, ESLint or TypeScript was installed.
- Original installed package.json remained byte-identical, SHA-256 7c31501fb922074c7a2525a7bd1257168b490d9cc843d1b2c1d69e0df5f04953; its runtime ranges and independent development pins remain unchanged.

This proves the production staging dependency-resolution mechanism. It does NOT validate a production helper's package-by-package merge, .bin handling, rollback, optional-SDK preservation, process interruption or Windows behavior. Those remain requirements for the forthcoming implementation; this experiment used a whole-tree swap only in disposable scratch.

Evidence: linux22-production-stage-summary.json, linux22-production-stage-install.log, linux22-stage-before-swap.json, linux22-stage-peers-before-swap.json, linux22-stage-after-swap.json, linux22-stage-peers-after-swap.json.

## Minimal implementation recommendation

Implement a built-in-only installed repair helper and print its exact node/helper argv. It should derive SDK identities/exact targets from the installed runtime descriptor, clone authoritative owner runtime constraints into a production-only temporary manifest, and use normal npm peer resolution. Do not duplicate floors or change repository dev pins.

Stage on the owner's filesystem for rename semantics; validate the resulting SDK/native and required peer graph before applying. Merge at package-root granularity (@scope/name), preserving packages absent from staging, including optional adapters/host dependencies. Do not replace a whole scope or entire .bin directory, and do not transplant the staging hidden .package-lock.json. Roll back all changes from the transaction if any replacement fails. Keep the original installed package.json unchanged on every path.

Keep normal SLC installation unchanged. Update installed-package tests to extract and execute the actual new printed helper argv, and assert both included SDKs, native components, required peers, manifest preservation and unrelated optional-package preservation. Re-run the four real faults under exact Linux Node22/npm10, current Mac tooling and native Windows; retain failure/debug logs. A passing npm11-only CI run would not close this reproduced bug.

No helper source was reviewed or final helper command executed during this diagnosis. No provider/model call, merge or publication was performed.

## Evidence locations

Local evidence root: /tmp/sdk-linux-repair-review-YLeQlD
Remote scratch retained for the authorized helper-review follow-up: /home/bobo/sdk-linux-repair-review-YLeQlD
Linux raw evidence archive: /tmp/sdk-linux-repair-review-YLeQlD/linux-evidence.tar.gz
Extracted raw evidence: /tmp/sdk-linux-repair-review-YLeQlD/linux-evidence/
Original CI log: /tmp/cligent-job.log

The combined archive below includes this report, actual tarball, reproduction programs, Mac controls, Linux receipts/probes and complete owned debug logs; it excludes large Node binaries and node_modules. Hash manifests enable checking the archived bytes. Scratch files can be cleaned after the requested new-helper review and reproduction complete.
