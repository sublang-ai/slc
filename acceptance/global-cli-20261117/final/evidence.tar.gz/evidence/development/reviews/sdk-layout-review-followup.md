# Cligent real-layout follow-up review

AT-slc-global-20261117. Early implementation/debugging review, not formal acceptance. No repository file was changed by this reviewer.

## Conclusion

The old printed global SDK repair fails for both included adapters. The smallest verified replacement is one project-scoped install into the physical installed Cligent package root, explicitly requesting BOTH descriptor-derived exact SDKs as production edges while saving neither manifest nor pins:

    npm install --global=false --location=project --prefix <Cligent-packageRoot> --omit=dev --save-prod --no-save @openai/codex-sdk@0.159.1 @anthropic-ai/claude-agent-sdk@0.3.325

These literals describe the tested runtime descriptor; implementation must derive them from it. OpenCode retains its separate optional-peer repair targeting.

## Package/environment and cache

macOS Darwin 24.3.0 arm64, Node v25.5.0, npm 11.8.0. Cache: /Users/boboyang/.npm (confirmed with npm config get cache). Latest native SDK tarballs were downloaded in the first install; exact conformance versions used in repairs were already cached. Reusing this cache with fresh consumer/prefix directories proves installation/layout, not cold network downloading.

Tarball SHA-256: 6631c22de77d3029fe3784b2ef3ad22dff50527979406343627521830ee06dfe. Packed at 2026-11-17T15:18:50.665015+00:00 with npm pack --ignore-scripts from the earlier in-progress Cligent 0.39.0 implementation. This avoids rebuilding/changing repository dist. The tarball contains the OLD repair renderer before the parent's current changes and must not be presented as the latest source execution.

Only that tarball was globally installed, with --ignore-scripts --no-audit --no-fund, no sibling SDK specs. npm exited 0: 116 packages added in 25m. See global-install.log, pack.json, environment.json.

The second nested cold install was stopped at the parent's request to reduce bandwidth contention: SIGTERM exit 143 after SIGINT did not stop the active fetch. See nested-interrupted.json. This is neither a completed nested test nor a product failure.

## Actual physical ownership

The normal global install resolved both SDKs from Cligent/node_modules. Open ranges selected Claude 0.3.326 and Codex SDK/CLI 0.169.0. Both SDKs and native executables were available; both versions honestly classified as untested. See global-codex-before.json.

The Codex wrapper was Cligent/node_modules/@openai/codex/bin/codex.js, resolved from the SDK's physical manifest. The native executable was separately under Cligent/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex. Therefore the native executable is under neither the SDK-root prefix nor the wrapper-root prefix. A fixed SDK/node_modules/@openai/codex expectation is also wrong for this valid global layout.

Independently derive the wrapper from the real SDK manifest and its declared dependency, then the native platform package from the wrapper's physical require context. Keep unrelated decoy isolation. Broadening both checks to a common Cligent/node_modules prefix loses that guarantee. Running wrapper --version against its SDK-declared wrapper version is an additional useful independent check, not run in this follow-up.

## Actual printed repair fails

For Codex and Claude separately: move the selected native package outside every selected dependency path; invoke the actual installed tmux-play CLI with that adapter explicitly configured; extract its printed npm command; execute that argv unchanged. Both fault CLIs exited 1 before any stub session was created.

The printed commands were npm install -g --prefix <original-prefix> SDK@tested. Both exited 0 (Codex 2.827s, Claude 18.581s), but the same nearer SDK remained selected and its native package remained missing. This confirms a product repair defect, not merely absent test coverage.

The old CLI also reports only an unusable adapter, omitting the concrete missing native package, and incorrectly describes the outer module tree as the SDK-resolution tree. Concrete missing packages appear in the probe JSON.

Evidence: experiment-summary.json, global-*-fault-launcher.log, global-*-fault.json, global-*-after.json, global-*-repair.log. global-early-probe.json was taken while npm was still installing and is explicitly NOT success/failure evidence.

## Why both SDK specs and production-edge flags are required

Small local-package experiments proved --omit=dev --no-save still omits an explicitly requested SDK repeated in devDependencies; --include=prod alone does not help. Adding --save-prod together with --no-save installs it while leaving package.json unchanged. Both flag orders were checked. Evidence: npm-duplicate-edge/results.json and no-save-prod-results.json.

The real Cligent tree confirmed the cross-adapter hazard. First move prior printed-repair sibling SDKs outside the resolution paths so fallback cannot mask pruning. An owner-targeted Codex-only repair with these flags exited 0 in 126.011s and repaired Codex, but removed 104 packages and made Claude no-sdk/unavailable.

Requesting BOTH descriptor exact SDKs in that same command exited 0 in 6.720s and restored both SDK/native stacks under Cligent/node_modules. Package.json SHA-256 remained 175a6ff2795a1998b5953d14bdfb9c1e0eb5e1c12a3557d08a277a2a6ef943b7. Evidence: candidate-repair-summary.json, candidate-single-install.log / candidate-single-after.json, candidate-both-install.log / candidate-both-after.json.

## Proposed replacement fault matrix: four of four

The proposed two-SDK command was independently exercised against Codex native missing, Codex SDK missing, Claude native missing and Claude SDK missing. Every fault was confirmed by a fresh process. Every repair exited 0, restored the same removed physical path, retained the manifest SHA, and left BOTH adapters available. The actual installed tmux-play CLI then exited 0 and created a stub session in every case.

The repaired Cligent tree contains no eslint, vitest, TypeScript or optional OpenCode SDK.

Evidence: candidate-fault-matrix-summary.json, candidate-fault-matrix.log and candidate-{codex|claude}-{native|sdk}-* files. All four trial assertions were independently checked when writing this report.

These replacement commands were manually supplied debugging commands: this tarball still prints the old failed repair. Final verification must pack the revised source, extract its NEW actual printed command, execute unchanged, and repeat both adapters' readiness and installed-CLI checks. This report does not claim that new-printer step has passed.

## Boundaries and minimum revision

Use the physical installed Cligent packageRoot for included-SDK repairs, project scope, tested production-edge flags and BOTH descriptor-derived exact SDK specs. Keep external CLI/OpenCode rules independent. Name concrete missing SDK/native components using existing Cligent runtime probes. Preserve authentication separation and decoy isolation.

Cold installation took 25m here; explicitly recorded cache reuse can avoid that delay with fresh install directories. It is not a cold network test.

tmux/glow were stubs solely to observe readiness gating and session commands. No provider/model call, real-glow acceptance, Linux/native Windows result, registry prerelease installation or SLC compilation is claimed.

Evidence root: /tmp/cligent-sdk-layout-review-VyMSA9. artifact-sha256.json hashes the report, tarball, programs and direct top-level raw evidence files for archival.
