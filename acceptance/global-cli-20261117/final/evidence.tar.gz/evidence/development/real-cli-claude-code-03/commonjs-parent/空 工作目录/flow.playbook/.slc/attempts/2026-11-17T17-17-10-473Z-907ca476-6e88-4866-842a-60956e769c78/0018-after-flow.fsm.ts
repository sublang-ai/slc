import { assign, fromPromise, setup } from 'xstate';

export type FlowStateId = 'writeCommitMessage';

export type FlowSourceItem = 'flow-5';

/**
 * Stable working-leaf ids that may suspend on a Boss question and be resumed
 * by `BOSS_REPLY`. The machine has at most one active player task, so the
 * scalar Boss-reply form applies.
 */
const RESUMABLE_STATE_IDS = ['writeCommitMessage'] as const;
export type ResumableStateId = (typeof RESUMABLE_STATE_IDS)[number];

/** JSON-safe normalization of a rejected invocation, retained for inspection. */
export type NormalizedError = {
  readonly name: string;
  readonly message: string;
  readonly stack?: string;
};

/** Question record raised by the suspended 提交说明作者 working leaf. */
export type PendingBossQuestion = {
  readonly questionId: ResumableStateId;
  readonly resumeStateId: ResumableStateId;
  readonly sourceItem: FlowSourceItem;
  readonly asker: { readonly kind: 'role'; readonly roleId: '提交说明作者' };
  readonly question: string;
};

/** Typed input for the delegated `player` actor. */
export type PlayerInput = {
  readonly stateId: 'writeCommitMessage';
  readonly role: '提交说明作者';
  readonly sourceItem: 'flow-5';
  readonly prompt: string;
  readonly result: Readonly<Record<string, string>>;
  /** Backs the prompt's `<boss-intent>` placeholder with the exact Boss input. */
  readonly bossIntent: string;
  readonly pendingBossQuestion?: PendingBossQuestion;
  readonly bossReply?: string;
};

/** Discriminated result contract of the delegated `player` actor. */
export type PlayerOutput =
  | {
      readonly guard: 'generated';
      /** 完整代码块形式的提交说明。 */
      readonly message: string;
    }
  | {
      readonly guard: 'cannotGenerate';
      /** 说明具体限制的失败原因。 */
      readonly reason: string;
    }
  | { readonly guard: 'needsBossReply'; readonly question: string };

/**
 * Terminal result derived from typed context: 已生成 hands `message` over
 * verbatim to the caller; 无法生成 hands `reason` over verbatim.
 */
export type FlowPlaybookOutput =
  | {
      readonly status: 'generated';
      /** 完整代码块形式的提交说明，原样交给调用者。 */
      readonly message: string;
    }
  | {
      readonly status: 'cannotGenerate';
      /** 说明具体限制的 reason，原样交给调用者。 */
      readonly reason: string;
    };

/** The machine reads no input: the Boss text arrives on `START_FLOW`. */
export type FlowInput = Readonly<Record<never, never>>;

export type FlowCompletion = 'generated' | 'cannotGenerate';

export type FlowContext = {
  readonly bossIntent?: string;
  readonly message?: string;
  readonly reason?: string;
  readonly completion?: FlowCompletion;
  readonly lastError?: NormalizedError;
  readonly pendingBossQuestion?: PendingBossQuestion;
  readonly bossReply?: string;
};

/** Typed Boss surfaces: the Boss entry event and the Boss reply. */
export type FlowEvent =
  | { readonly type: 'START_FLOW'; readonly bossIntent: string }
  | {
      readonly type: 'BOSS_REPLY';
      readonly answer: string;
      readonly questionId?: ResumableStateId;
    };

/** No parallel group in this playbook. */
export const concurrentRoleSets: readonly (readonly string[])[] = [];

const WRITE_COMMIT_MESSAGE_PROMPT = [
  '读取任务文件及其引用的改动和上下文，以及项目约定。',
  '生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。',
  '只生成文本，不暂存文件，不执行 git commit，不 amend。',
  '标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。',
  'type 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。',
  '标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。',
  '标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。',
  '正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。',
  '不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。',
  '表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。',
  '输出可直接粘贴的代码块。',
  '用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。',
  '> <boss-intent>',
].join('\n');

const NEEDS_BOSS_REPLY_RESULT =
  "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.";

const WRITE_COMMIT_MESSAGE_RESULTS = {
  generated:
    '成功生成提交说明，message 的内容为完整代码块。Output shall include `message: <完整代码块>`.',
  cannotGenerate:
    '任务文件或引用的输入无法读取，或资料不足以生成提交说明。Output shall include `reason: <说明具体限制>`.',
  needsBossReply: NEEDS_BOSS_REPLY_RESULT,
} as const;

const STATE_DESCRIPTIONS = {
  ready: '等待用户要求生成提交说明并以普通文本提供任务文件的绝对路径。',
  writeCommitMessage:
    '提交说明作者正在读取任务文件及其引用的改动和上下文，并完成提交说明。',
  awaitBossReply: "Waiting for Boss to answer the acting agent's question.",
  failed: '流程因错误或无效结果而失败，等待用户重新提供任务文件的绝对路径。',
  generated:
    '已生成：提交说明作者成功生成提交说明，流程结束并将 message 原样交给调用者。',
  cannotGenerate:
    '无法生成：任务文件或引用的输入无法读取或资料不足以生成提交说明，流程结束并将 reason 原样交给调用者。',
} as const;

type DescribedStateId = keyof typeof STATE_DESCRIPTIONS;

function playbookMeta(stateId: DescribedStateId, role?: '提交说明作者') {
  return {
    playbook: {
      stateId,
      description: STATE_DESCRIPTIONS[stateId],
      ...(role === undefined ? {} : { role }),
    },
  };
}

/** A final state also publishes whether its outcome is success or failure. */
function terminalMeta(
  stateId: DescribedStateId,
  terminal: 'success' | 'failure',
) {
  return {
    playbook: {
      stateId,
      description: STATE_DESCRIPTIONS[stateId],
      terminal,
    },
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

/**
 * Narrows an unknown event's `output` structurally to the declared `player`
 * contract. Output missing a field its guard requires narrows to `undefined`.
 */
function playerOutputOf(event: unknown): PlayerOutput | undefined {
  if (!isRecord(event) || !isRecord(event.output)) return undefined;
  const output = event.output;
  if (output.guard === 'generated' && isNonEmptyString(output.message)) {
    return { guard: 'generated', message: output.message };
  }
  if (output.guard === 'cannotGenerate' && isNonEmptyString(output.reason)) {
    return { guard: 'cannotGenerate', reason: output.reason };
  }
  if (output.guard === 'needsBossReply' && isNonEmptyString(output.question)) {
    return { guard: 'needsBossReply', question: output.question };
  }
  return undefined;
}

/** Narrows an unknown event's `error` structurally to a JSON-safe record. */
function normalizedErrorOf(event: unknown): NormalizedError {
  const error = isRecord(event) ? event.error : undefined;
  if (error instanceof Error) {
    const name = error.name || 'Error';
    return typeof error.stack === 'string'
      ? { name, message: error.message, stack: error.stack }
      : { name, message: error.message };
  }
  if (isRecord(error)) {
    const name = typeof error.name === 'string' ? error.name : 'Error';
    const message =
      typeof error.message === 'string'
        ? error.message
        : 'player actor rejected without a normalized error';
    return typeof error.stack === 'string'
      ? { name, message, stack: error.stack }
      : { name, message };
  }
  return {
    name: 'Error',
    message:
      typeof error === 'string'
        ? error
        : 'player actor rejected without a normalized error',
  };
}

function isResumableStateId(value: string): value is ResumableStateId {
  return (RESUMABLE_STATE_IDS as readonly string[]).includes(value);
}

type ResumeTransition = {
  readonly guard: {
    readonly type: 'canResume';
    readonly params: { readonly stateId: ResumableStateId };
  };
  readonly target: `#${ResumableStateId}`;
  readonly reenter: true;
  readonly actions: 'acceptBossReply';
};

/** Builds one guarded `BOSS_REPLY` resume arm per registered working-leaf id. */
function resumableStates(
  ids: readonly ResumableStateId[],
): ResumeTransition[] {
  return ids.map((id) => ({
    guard: { type: 'canResume', params: { stateId: id } },
    target: `#${id}`,
    reenter: true,
    actions: 'acceptBossReply',
  }));
}

const machineSetup = setup({
  types: {} as {
    context: FlowContext;
    events: FlowEvent;
    input: FlowInput;
    output: FlowPlaybookOutput;
  },
  actors: {
    player: fromPromise<PlayerOutput, PlayerInput>(async () => {
      throw new Error('player actor must be provided by the runner');
    }),
  },
  guards: {
    // The entry guard validates the text the current event supplies, before
    // the entry action copies it into context.
    givesBossIntent: ({ event }) =>
      event.type === 'START_FLOW' && isNonEmptyString(event.bossIntent),
    isGenerated: ({ event }) => playerOutputOf(event)?.guard === 'generated',
    isCannotGenerate: ({ event }) =>
      playerOutputOf(event)?.guard === 'cannotGenerate',
    needsBossReply: (
      { event },
      params: { readonly stateId: ResumableStateId },
    ) =>
      playerOutputOf(event)?.guard === 'needsBossReply' &&
      isResumableStateId(params.stateId),
    canResume: (
      { context, event },
      params: { readonly stateId: ResumableStateId },
    ) => {
      if (event.type !== 'BOSS_REPLY' || !isNonEmptyString(event.answer)) {
        return false;
      }
      const pending = context.pendingBossQuestion;
      if (pending === undefined || pending.resumeStateId !== params.stateId) {
        return false;
      }
      return (
        event.questionId === undefined ||
        event.questionId === pending.questionId
      );
    },
  },
  actions: {
    'playbook.acceptedOutcome': (
      _args,
      _params: {
        readonly source: string;
        readonly target: string;
        readonly acceptedOutcome: string;
      },
    ) => undefined,
    startFlow: assign(({ context, event }): Partial<FlowContext> => {
      if (event.type !== 'START_FLOW') return {};
      return {
        bossIntent: event.bossIntent,
        ...(context.lastError === undefined ? {} : { lastError: undefined }),
        ...(context.pendingBossQuestion === undefined
          ? {}
          : { pendingBossQuestion: undefined }),
        ...(context.bossReply === undefined ? {} : { bossReply: undefined }),
      };
    }),
    rememberGenerated: assign(({ context, event }): Partial<FlowContext> => {
      const output = playerOutputOf(event);
      if (output?.guard !== 'generated') return {};
      return {
        message: output.message,
        completion: 'generated',
        ...(context.pendingBossQuestion === undefined
          ? {}
          : { pendingBossQuestion: undefined }),
        ...(context.bossReply === undefined ? {} : { bossReply: undefined }),
      };
    }),
    rememberCannotGenerate: assign(
      ({ context, event }): Partial<FlowContext> => {
        const output = playerOutputOf(event);
        if (output?.guard !== 'cannotGenerate') return {};
        return {
          reason: output.reason,
          completion: 'cannotGenerate',
          ...(context.pendingBossQuestion === undefined
            ? {}
            : { pendingBossQuestion: undefined }),
          ...(context.bossReply === undefined ? {} : { bossReply: undefined }),
        };
      },
    ),
    setPendingBossQuestion: assign(
      (
        { context, event },
        params: {
          readonly stateId: ResumableStateId;
          readonly sourceItem: FlowSourceItem;
        },
      ): Partial<FlowContext> => {
        const output = playerOutputOf(event);
        if (output?.guard !== 'needsBossReply') return {};
        return {
          pendingBossQuestion: {
            questionId: params.stateId,
            resumeStateId: params.stateId,
            sourceItem: params.sourceItem,
            asker: { kind: 'role', roleId: '提交说明作者' },
            question: output.question,
          },
          ...(context.bossReply === undefined ? {} : { bossReply: undefined }),
        };
      },
    ),
    acceptBossReply: assign(({ event }): Partial<FlowContext> =>
      event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {},
    ),
    clearBossReplyContext: assign(({ context }): Partial<FlowContext> =>
      context.pendingBossQuestion === undefined &&
      context.bossReply === undefined
        ? {}
        : { pendingBossQuestion: undefined, bossReply: undefined },
    ),
    rememberActorError: assign(({ event }): Partial<FlowContext> => ({
      lastError: normalizedErrorOf(event),
    })),
    rememberMalformedPlayerOutput: assign((): Partial<FlowContext> => ({
      lastError: {
        name: 'MalformedPlayerOutput',
        message:
          '提交说明作者针对 flow-5 的结果未满足其结果契约中声明的任一结局。',
      },
    })),
    rememberMalformedBossReply: assign((): Partial<FlowContext> => ({
      lastError: {
        name: 'MalformedBossReply',
        message: 'BOSS_REPLY 的回答为空，或未指向任何待回答的问题。',
      },
    })),
  },
});

export const flowMachine = machineSetup.createMachine({
  id: 'flow',
  initial: 'ready',
  context: () => ({}),
  output: ({ context }): FlowPlaybookOutput => {
    if (context.completion === 'generated') {
      if (!isNonEmptyString(context.message)) {
        throw new Error('flow 已到达“已生成”但未保留 message');
      }
      return { status: 'generated', message: context.message };
    }
    if (context.completion === 'cannotGenerate') {
      if (!isNonEmptyString(context.reason)) {
        throw new Error('flow 已到达“无法生成”但未保留 reason');
      }
      return { status: 'cannotGenerate', reason: context.reason };
    }
    throw new Error('flow 已到达终态但未记录任何完成结果');
  },
  states: {
    ready: {
      id: 'ready',
      description: STATE_DESCRIPTIONS.ready,
      meta: playbookMeta('ready'),
      tags: ['playbook.parked'],
      on: {
        START_FLOW: {
          guard: 'givesBossIntent',
          target: 'writeCommitMessage',
          actions: 'startFlow',
        },
      },
    },
    writeCommitMessage: {
      id: 'writeCommitMessage',
      description: STATE_DESCRIPTIONS.writeCommitMessage,
      meta: playbookMeta('writeCommitMessage', '提交说明作者'),
      tags: ['playbook.busy'],
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({
          stateId: 'writeCommitMessage',
          role: '提交说明作者',
          sourceItem: 'flow-5',
          prompt: WRITE_COMMIT_MESSAGE_PROMPT,
          result: WRITE_COMMIT_MESSAGE_RESULTS,
          // Entry is guarded on a non-empty Boss input, so this state is
          // never entered without it.
          bossIntent: context.bossIntent ?? '',
          ...(context.pendingBossQuestion === undefined
            ? {}
            : { pendingBossQuestion: context.pendingBossQuestion }),
          ...(context.bossReply === undefined
            ? {}
            : { bossReply: context.bossReply }),
        }),
        onDone: [
          {
            guard: 'isGenerated',
            target: 'generated',
            actions: [
              {
                type: 'playbook.acceptedOutcome',
                params: {
                  source: 'writeCommitMessage',
                  target: 'generated',
                  acceptedOutcome: 'generated',
                },
              },
              'rememberGenerated',
            ],
          },
          {
            guard: 'isCannotGenerate',
            target: 'cannotGenerate',
            actions: [
              {
                type: 'playbook.acceptedOutcome',
                params: {
                  source: 'writeCommitMessage',
                  target: 'cannotGenerate',
                  acceptedOutcome: 'cannotGenerate',
                },
              },
              'rememberCannotGenerate',
            ],
          },
          {
            guard: {
              type: 'needsBossReply',
              params: { stateId: 'writeCommitMessage' },
            },
            target: 'awaitBossReply',
            actions: [
              {
                type: 'playbook.acceptedOutcome',
                params: {
                  source: 'writeCommitMessage',
                  target: 'awaitBossReply',
                  acceptedOutcome: 'needsBossReply',
                },
              },
              {
                type: 'setPendingBossQuestion',
                params: {
                  stateId: 'writeCommitMessage',
                  sourceItem: 'flow-5',
                },
              },
            ],
          },
          {
            target: 'failed',
            actions: 'rememberMalformedPlayerOutput',
          },
        ],
        onError: { target: 'failed', actions: 'rememberActorError' },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply',
      description: STATE_DESCRIPTIONS.awaitBossReply,
      meta: playbookMeta('awaitBossReply'),
      tags: ['playbook.parked'],
      on: {
        BOSS_REPLY: [
          ...resumableStates(RESUMABLE_STATE_IDS),
          {
            target: 'failed',
            actions: ['rememberMalformedBossReply', 'clearBossReplyContext'],
          },
        ],
        START_FLOW: {
          guard: 'givesBossIntent',
          target: 'writeCommitMessage',
          actions: 'startFlow',
        },
      },
    },
    failed: {
      id: 'failed',
      description: STATE_DESCRIPTIONS.failed,
      meta: playbookMeta('failed'),
      tags: ['playbook.parked'],
      on: {
        START_FLOW: {
          guard: 'givesBossIntent',
          target: 'writeCommitMessage',
          actions: 'startFlow',
        },
      },
    },
    generated: {
      id: 'generated',
      description: STATE_DESCRIPTIONS.generated,
      meta: terminalMeta('generated', 'success'),
      type: 'final',
    },
    cannotGenerate: {
      id: 'cannotGenerate',
      description: STATE_DESCRIPTIONS.cannotGenerate,
      meta: terminalMeta('cannotGenerate', 'failure'),
      type: 'final',
    },
  },
});

export default flowMachine;
