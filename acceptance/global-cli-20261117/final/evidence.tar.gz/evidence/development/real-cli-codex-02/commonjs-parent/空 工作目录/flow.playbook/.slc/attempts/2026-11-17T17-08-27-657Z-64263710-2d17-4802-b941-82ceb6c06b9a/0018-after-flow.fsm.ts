import { assign, enqueueActions, fromPromise, setup } from 'xstate';
import { isAbsolute } from 'node:path';

export type MachineInput = Record<string, never>;
export type MachineOutput = { message: string } | { reason: string };
export const concurrentRoleSets = [] as const;

export interface PendingBossQuestion {
  questionId: 'writeMessage';
  resumeStateId: 'writeMessage';
  sourceItem: 'flow-8';
  asker: { kind: 'role'; roleId: '提交说明作者' };
  question: string;
}

const result = {
  generated: '成功生成提交说明。Output shall include `message: <字符串，内容为完整代码块>`。',
  unavailable: '任务文件或引用的输入无法读取、或资料不足以生成说明。Output shall include `reason: <字符串，说明具体限制>`。',
  needsBossReply: "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.",
} as const;

export interface PlayerInput {
  stateId: 'writeMessage';
  sourceItem: 'flow-8';
  role: '提交说明作者';
  prompt: string;
  result: typeof result;
  taskFilePath: string;
  pendingBossQuestion?: PendingBossQuestion;
  bossReply?: string;
}

export type PlayerOutput =
  | { guard: 'generated'; message: string }
  | { guard: 'unavailable'; reason: string }
  | { guard: 'needsBossReply'; question: string };

type JumpableStateId = 'ready' | 'writeMessage' | 'failed';
type ResumableStateId = 'writeMessage';
export type MachineEvent =
  | { type: 'START'; taskFilePath: string }
  | { type: 'BOSS_INTERRUPT'; targetId: JumpableStateId }
  | { type: 'BOSS_REPLY'; answer: string; questionId?: string };

interface NormalizedError { name: string; message: string; stack?: string }
interface FlowContext {
  taskFilePath?: string;
  completion?: MachineOutput;
  pendingBossQuestion?: PendingBossQuestion;
  bossReply?: string;
  lastError?: NormalizedError;
}

const prompt = "读取下方引用的任务文件绝对路径所指向的任务文件及其引用的改动和上下文，然后完成提交说明。\n读取用户提供的改动及项目约定，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。\n\n> <task-file-path>";

function record(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function outputOf(event: unknown): unknown {
  return record(event) ? event.output : undefined;
}
function errorOf(event: unknown): unknown {
  return record(event) ? event.error : undefined;
}
function playerOutput(event: unknown): PlayerOutput | undefined {
  const output = outputOf(event);
  if (!record(output)) return undefined;
  if (output.guard === 'generated' && typeof output.message === 'string' && output.message.trim()) {
    return { guard: 'generated', message: output.message };
  }
  if (output.guard === 'unavailable' && typeof output.reason === 'string' && output.reason.trim()) {
    return { guard: 'unavailable', reason: output.reason };
  }
  if (output.guard === 'needsBossReply' && typeof output.question === 'string' && output.question.trim()) {
    return { guard: 'needsBossReply', question: output.question };
  }
  return undefined;
}
function validPath(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0 && isAbsolute(value);
}
function normalizeError(error: unknown): NormalizedError {
  if (error instanceof Error) {
    return { name: error.name, message: error.message, ...(typeof error.stack === 'string' ? { stack: error.stack } : {}) };
  }
  if (record(error) && typeof error.message === 'string') {
    return { name: typeof error.name === 'string' ? error.name : 'Error', message: error.message };
  }
  return { name: 'Error', message: typeof error === 'string' ? error : 'Player invocation failed.' };
}
function bossInterrupts(ids: readonly JumpableStateId[]) {
  return ids.map((id) => ({
    target: `#${id}`,
    reenter: true,
    guard: ({ context, event }: { context: FlowContext; event: MachineEvent }) =>
      event.type === 'BOSS_INTERRUPT' && event.targetId === id &&
      (id !== 'writeMessage' || validPath(context.taskFilePath)) &&
      (id !== 'failed' || context.lastError !== undefined),
    actions: id === 'failed' ? 'clearBossReplyContext' as const : 'clearTransientContext' as const,
  }));
}
function resumableStates(ids: readonly ResumableStateId[]) {
  return ids.map((id) => ({
    target: `#${id}`,
    guard: ({ context, event }: { context: FlowContext; event: MachineEvent }) => {
      const question = context.pendingBossQuestion;
      return event.type === 'BOSS_REPLY' && typeof event.answer === 'string' && event.answer.trim().length > 0 &&
        question?.questionId === id && question.resumeStateId === id && question.sourceItem === 'flow-8' &&
        question.asker.kind === 'role' && question.asker.roleId === '提交说明作者' &&
        (event.questionId === undefined || event.questionId === id) && validPath(context.taskFilePath);
    },
    actions: 'rememberBossReply' as const,
  }));
}

export const flowMachine = setup({
  types: {
    context: {} as FlowContext,
    events: {} as MachineEvent,
    input: {} as MachineInput,
    output: {} as MachineOutput,
  },
  actors: {
    player: fromPromise<PlayerOutput, PlayerInput>(async () => {
      throw new Error('player actor must be provided by the runner');
    }),
  },
  guards: {
    validEntry: ({ event }) => event.type === 'START' && validPath(event.taskFilePath),
    generated: ({ event }) => playerOutput(event)?.guard === 'generated',
    unavailable: ({ event }) => playerOutput(event)?.guard === 'unavailable',
    needsBossReply: ({ event }) => playerOutput(event)?.guard === 'needsBossReply',
    invalidReply: ({ event }) => event.type === 'BOSS_REPLY' &&
      (typeof event.answer !== 'string' || event.answer.trim().length === 0),
  },
  actions: {
    'playbook.acceptedOutcome': (_args, _params: { source: string; target: string; acceptedOutcome: string }) => {},
    // Clone through assign before deleting optional properties so prior snapshots
    // retain their context and the new context omits absent JSON members.
    clearBossReplyContext: enqueueActions(({ enqueue }) => {
      enqueue.assign({});
      enqueue(({ context }) => {
        delete context.pendingBossQuestion;
        delete context.bossReply;
      });
    }),
    clearTransientContext: enqueueActions(({ enqueue }) => {
      enqueue.assign({});
      enqueue(({ context }) => {
        delete context.pendingBossQuestion;
        delete context.bossReply;
        delete context.completion;
        delete context.lastError;
      });
    }),
    rememberEntry: assign(({ event }) => event.type === 'START' ? { taskFilePath: event.taskFilePath } : {}),
    rememberGenerated: assign(({ event }) => {
      const output = playerOutput(event);
      return output?.guard === 'generated' ? { completion: { message: output.message } } : {};
    }),
    rememberUnavailable: assign(({ event }) => {
      const output = playerOutput(event);
      return output?.guard === 'unavailable' ? { completion: { reason: output.reason } } : {};
    }),
    setPendingBossQuestion: enqueueActions(({ enqueue, event }) => {
      const output = playerOutput(event);
      if (output?.guard !== 'needsBossReply') return;
      enqueue.assign({});
      enqueue(({ context }) => {
        delete context.pendingBossQuestion;
        delete context.bossReply;
      });
      enqueue.assign({
        pendingBossQuestion: {
          questionId: 'writeMessage', resumeStateId: 'writeMessage', sourceItem: 'flow-8',
          asker: { kind: 'role', roleId: '提交说明作者' }, question: output.question,
        },
      });
    }),
    rememberBossReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    rememberActorError: assign(({ event }) => ({
      lastError: normalizeError(errorOf(event)),
    })),
    rememberMalformedOutput: assign({ lastError: () => ({ name: 'InvalidPlayerOutput', message: 'Player output does not match the declared result contract.' }) }),
    rememberInvalidReply: assign({ lastError: () => ({ name: 'InvalidBossReply', message: 'Boss reply must contain a nonempty answer matching the pending question.' }) }),
    rememberInvalidEntry: assign({ lastError: () => ({ name: 'InvalidTaskFilePath', message: 'Boss must supply the absolute task-file path as plain text.' }) }),
  },
}).createMachine({
  id: 'flow',
  initial: 'ready',
  context: {},
  output: ({ context }) => {
    if (!context.completion) throw new Error('No accepted terminal result.');
    return context.completion;
  },
  on: {
    BOSS_INTERRUPT: bossInterrupts(['ready', 'writeMessage', 'failed']),
    BOSS_REPLY: { guard: 'invalidReply', target: '#failed', actions: ['rememberInvalidReply', 'clearBossReplyContext'] },
  },
  states: {
    ready: {
      id: 'ready', description: '等待 Boss 提供任务文件的绝对路径。', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'ready', description: '等待 Boss 提供任务文件的绝对路径。' } },
      on: {
        START: [
          { guard: 'validEntry', target: '#writeMessage', actions: ['clearTransientContext', 'rememberEntry'] },
          { target: '#failed', actions: ['clearTransientContext', 'rememberInvalidEntry'] },
        ],
      },
    },
    writeMessage: {
      id: 'writeMessage', description: '由提交说明作者读取任务文件并生成提交说明。', tags: ['playbook.busy'],
      meta: { playbook: { stateId: 'writeMessage', description: '由提交说明作者读取任务文件并生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({
          stateId: 'writeMessage', sourceItem: 'flow-8', role: '提交说明作者', prompt, result,
          taskFilePath: context.taskFilePath!,
          ...(context.pendingBossQuestion ? { pendingBossQuestion: context.pendingBossQuestion } : {}),
          ...(typeof context.bossReply === 'string' ? { bossReply: context.bossReply } : {}),
        }),
        onDone: [
          { guard: 'generated', target: '#generated', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'generated', acceptedOutcome: 'generated' } },
            'rememberGenerated', 'clearBossReplyContext',
          ] },
          { guard: 'unavailable', target: '#unavailable', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'unavailable', acceptedOutcome: 'unavailable' } },
            'rememberUnavailable', 'clearBossReplyContext',
          ] },
          { guard: 'needsBossReply', target: '#awaitBossReply', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } },
            'setPendingBossQuestion',
          ] },
          { target: '#failed', actions: ['rememberMalformedOutput', 'clearBossReplyContext'] },
        ],
        onError: { target: '#failed', actions: ['rememberActorError', 'clearBossReplyContext'] },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question.", tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question." } },
      on: {
        BOSS_REPLY: [
          ...resumableStates(['writeMessage']),
          { target: '#failed', actions: ['rememberInvalidReply', 'clearBossReplyContext'] },
        ],
        START: [
          { guard: 'validEntry', target: '#writeMessage', actions: ['clearTransientContext', 'rememberEntry'] },
          { target: '#failed', actions: ['clearTransientContext', 'rememberInvalidEntry'] },
        ],
      },
    },
    failed: {
      id: 'failed', description: '流程发生运行错误，等待 Boss 恢复。', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'failed', description: '流程发生运行错误，等待 Boss 恢复。' } },
      on: {
        START: [
          { guard: 'validEntry', target: '#writeMessage', actions: ['clearTransientContext', 'rememberEntry'] },
          { target: '#failed', reenter: true, actions: ['clearTransientContext', 'rememberInvalidEntry'] },
        ],
      },
    },
    generated: {
      id: 'generated', type: 'final', description: '已生成：将完整代码块 message 原样交给调用者。',
      meta: { playbook: { stateId: 'generated', description: '已生成：将完整代码块 message 原样交给调用者。', terminal: 'success' } },
    },
    unavailable: {
      id: 'unavailable', type: 'final', description: '无法生成：将说明具体限制的 reason 原样交给调用者。',
      meta: { playbook: { stateId: 'unavailable', description: '无法生成：将说明具体限制的 reason 原样交给调用者。', terminal: 'failure' } },
    },
  },
});

export const coverageWitnesses = {
  schema: 'sublang.slc.coverage-witnesses.v1',
  entries: [{ events: [{ type: 'START', taskFilePath: '/tmp/commit-task.md' }] }],
} as const;
