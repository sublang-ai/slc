import { assign, enqueueActions, fromPromise, setup } from 'xstate';

export interface MachineInput {}

export interface PendingBossQuestion {
  questionId: 'writing';
  resumeStateId: 'writing';
  sourceItem: 'flow-5';
  asker: { kind: 'role'; roleId: '提交说明作者' };
  question: string;
}

export interface PlayerInput {
  stateId: 'writing';
  role: '提交说明作者';
  sourceItem: 'flow-5';
  prompt: string;
  result: Readonly<Record<'generated' | 'unavailable' | 'needsBossReply', string>>;
  bossInput: string;
  pendingBossQuestion?: PendingBossQuestion;
  bossReply?: string;
}

export type PlayerOutput =
  | { guard: 'generated'; message: string }
  | { guard: 'unavailable'; reason: string }
  | { guard: 'needsBossReply'; question: string };

export type MachineOutput = { message: string } | { reason: string };

type ErrorInfo = { name: string; message: string; stack?: string };
type JumpableStateId = 'ready' | 'writing' | 'failed';
type ResumableStateId = 'writing';

export type BossEvent =
  | { type: 'BOSS_TASK'; bossInput: string }
  | { type: 'BOSS_INTERRUPT'; targetId: JumpableStateId; bossInput?: string }
  | { type: 'BOSS_REPLY'; answer: string; questionId?: string };

interface FlowContext {
  bossInput: string | null;
  completion: MachineOutput | null;
  lastError: ErrorInfo | null;
  pendingBossQuestion?: PendingBossQuestion;
  bossReply?: string;
}

type EventArgs = { context: FlowContext; event: BossEvent };

export const concurrentRoleSets = [] as const;
export const coverageWitnesses = {
  schema: 'sublang.slc.coverage-witnesses.v1',
  entries: [{ events: [{ type: 'BOSS_TASK', bossInput: '/tmp/commit-task.md' }] }],
} as const;

function hasText(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

function plainData(value: unknown): value is Record<string, unknown> {
  if (value === null || typeof value !== 'object') return false;
  const prototype: unknown = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) return false;
  return Reflect.ownKeys(value).every((key) => {
    if (typeof key !== 'string') return false;
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    return descriptor !== undefined && descriptor.enumerable === true && 'value' in descriptor;
  });
}

function playerOutput(event: unknown): PlayerOutput | undefined {
  if (!plainData(event) || !plainData(event.output)) return undefined;
  const output = event.output;
  if (Object.keys(output).length !== 2) return undefined;
  if (output.guard === 'generated' && hasText(output.message)) {
    return { guard: 'generated', message: output.message };
  }
  if (output.guard === 'unavailable' && hasText(output.reason)) {
    return { guard: 'unavailable', reason: output.reason };
  }
  if (output.guard === 'needsBossReply' && hasText(output.question)) {
    return { guard: 'needsBossReply', question: output.question };
  }
  return undefined;
}

function normalizeError(event: unknown): ErrorInfo {
  const error = plainData(event) ? event.error : undefined;
  if (error instanceof Error) {
    return {
      name: error.name,
      message: error.message,
      ...(typeof error.stack === 'string' ? { stack: error.stack } : {}),
    };
  }
  return { name: 'ActorError', message: typeof error === 'string' ? error : 'The player invocation failed.' };
}

function bossInterrupts(ids: readonly JumpableStateId[]) {
  return ids.map((id) => ({
    target: `#${id}`,
    reenter: true,
    guard: ({ context, event }: EventArgs) => {
      if (event.type !== 'BOSS_INTERRUPT' || event.targetId !== id) return false;
      if (event.bossInput !== undefined && !hasText(event.bossInput)) return false;
      return id !== 'writing' || hasText(event.bossInput ?? context.bossInput);
    },
    actions: ['clearBossReplyContext', 'rememberInterrupt'] as const,
  }));
}

function resumableStates(ids: readonly ResumableStateId[]) {
  return ids.map((id) => ({
    target: `#${id}`,
    guard: ({ context, event }: EventArgs) => {
      const question = context.pendingBossQuestion;
      return event.type === 'BOSS_REPLY'
        && hasText(event.answer)
        && hasText(context.bossInput)
        && question?.resumeStateId === id
        && question.questionId === id
        && question.sourceItem === 'flow-5'
        && question.asker.kind === 'role'
        && question.asker.roleId === '提交说明作者'
        && (event.questionId === undefined || event.questionId === question.questionId);
    },
    actions: 'rememberBossReply' as const,
  }));
}

export const domainPrompt = "读取 Boss 提供的任务文件及其引用的改动和上下文，读取项目约定，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n只生成文本，不暂存文件，不执行 git commit，不 amend；不得通过执行 Git 提交来代替输出说明。\n标题使用 type(scope): imperative summary 格式，其中 type、scope 和 imperative summary 分别为实际类型、范围和祈使式摘要；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。\n用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。\n任务文件或引用的输入无法读取、或资料不足以生成说明时，说明具体限制。\n\n> <boss-input>";

const resultContract = {
  "generated": "已成功生成提交说明；输出应包含 `message: <string>`，内容为完整代码块。",
  "unavailable": "任务文件或引用的输入无法读取、或资料不足以生成说明；输出应包含 `reason: <string>`，说明具体限制。",
  "needsBossReply": "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`."
} as const;

export const flowMachine = setup({
  types: {
    context: {} as FlowContext,
    events: {} as BossEvent,
    input: {} as MachineInput,
    output: {} as MachineOutput,
  },
  actors: {
    player: fromPromise<PlayerOutput, PlayerInput>(async () => {
      throw new Error('player actor must be provided by the runner');
    }),
  },
  guards: {
    validTask: ({ event }) => event.type === 'BOSS_TASK' && hasText(event.bossInput),
    generated: ({ event }) => playerOutput(event)?.guard === 'generated',
    unavailable: ({ event }) => playerOutput(event)?.guard === 'unavailable',
    needsBossReply: ({ event }) => playerOutput(event)?.guard === 'needsBossReply',
  },
  actions: {
    'playbook.acceptedOutcome': (_args: unknown, _params: { source: string; target: string; acceptedOutcome: string }) => {},
    // Clone via assign before deleting optional members; prior snapshots stay intact.
    clearBossReplyContext: enqueueActions(({ enqueue }) => {
      enqueue.assign({});
      enqueue(({ context }) => {
        delete context.pendingBossQuestion;
        delete context.bossReply;
      });
    }),
    startTask: assign(({ event }) => event.type === 'BOSS_TASK' ? {
      bossInput: event.bossInput,
      completion: null,
      lastError: null,
    } : {}),
    rememberInterrupt: assign(({ context, event }) => event.type === 'BOSS_INTERRUPT' ? {
      bossInput: event.bossInput ?? context.bossInput,
      completion: null,
      lastError: null,
    } : {}),
    rememberGenerated: assign(({ event }) => {
      const output = playerOutput(event);
      return output?.guard === 'generated' ? { completion: { message: output.message } } : {};
    }),
    rememberUnavailable: assign(({ event }) => {
      const output = playerOutput(event);
      return output?.guard === 'unavailable' ? { completion: { reason: output.reason } } : {};
    }),
    setPendingBossQuestion: assign(({ event }) => {
      const output = playerOutput(event);
      if (output?.guard !== 'needsBossReply') return {};
      const pendingBossQuestion: PendingBossQuestion = {
        questionId: 'writing',
        resumeStateId: 'writing',
        sourceItem: 'flow-5',
        asker: { kind: 'role', roleId: '提交说明作者' },
        question: output.question,
      };
      return { pendingBossQuestion };
    }),
    rememberBossReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    rememberActorError: assign(({ event }) => ({ lastError: normalizeError(event) })),
    rememberInvalidOutput: assign({
      lastError: { name: 'InvalidPlayerOutput', message: 'The player returned no valid result under its declared contract.' },
    }),
    rememberInvalidBossInput: assign({
      lastError: { name: 'InvalidBossInput', message: 'Boss input or its pending-question binding is invalid.' },
    }),
  },
}).createMachine({
  id: 'flow',
  description: '根据改动生成提交说明',
  initial: 'ready',
  context: () => ({ bossInput: null, completion: null, lastError: null }),
  output: ({ context }) => {
    if (context.completion === null) throw new Error('The machine has no declared terminal result.');
    return context.completion;
  },
  on: {
    BOSS_INTERRUPT: bossInterrupts(['ready', 'writing', 'failed']),
    BOSS_REPLY: { target: '#failed', actions: ['clearBossReplyContext', 'rememberInvalidBossInput'] },
  },
  states: {
    ready: {
      id: 'ready',
      description: '等待 Boss 提供任务文件的绝对路径。',
      tags: 'playbook.parked',
      meta: { playbook: { stateId: 'ready', description: '等待 Boss 提供任务文件的绝对路径。' } },
      on: {
        BOSS_TASK: [
          { guard: 'validTask', target: '#writing', actions: ['clearBossReplyContext', 'startTask'] },
          { target: '#failed', actions: ['clearBossReplyContext', 'rememberInvalidBossInput'] },
        ],
      },
    },
    writing: {
      id: 'writing',
      description: '读取任务文件并生成提交说明。',
      tags: 'playbook.busy',
      meta: { playbook: { stateId: 'writing', description: '读取任务文件并生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => {
          return {
            stateId: 'writing',
            role: '提交说明作者',
            sourceItem: 'flow-5',
            prompt: domainPrompt,
            result: resultContract,
            bossInput: context.bossInput!,
            ...(context.pendingBossQuestion === undefined ? {} : { pendingBossQuestion: context.pendingBossQuestion }),
            ...(context.bossReply === undefined ? {} : { bossReply: context.bossReply }),
          };
        },
        onDone: [
          {
            guard: 'generated', target: '#generated',
            actions: [
              { type: 'playbook.acceptedOutcome', params: { source: 'writing', target: 'generated', acceptedOutcome: 'generated' } },
              'rememberGenerated', 'clearBossReplyContext',
            ],
          },
          {
            guard: 'unavailable', target: '#unavailable',
            actions: [
              { type: 'playbook.acceptedOutcome', params: { source: 'writing', target: 'unavailable', acceptedOutcome: 'unavailable' } },
              'rememberUnavailable', 'clearBossReplyContext',
            ],
          },
          {
            guard: 'needsBossReply', target: '#awaitBossReply',
            actions: [
              { type: 'playbook.acceptedOutcome', params: { source: 'writing', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } },
              'clearBossReplyContext', 'setPendingBossQuestion',
            ],
          },
          { target: '#failed', actions: ['clearBossReplyContext', 'rememberInvalidOutput'] },
        ],
        onError: { target: '#failed', actions: ['clearBossReplyContext', 'rememberActorError'] },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply',
      description: "Waiting for Boss to answer the acting agent's question.",
      tags: 'playbook.parked',
      meta: { playbook: { stateId: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question." } },
      on: {
        BOSS_REPLY: [
          ...resumableStates(['writing']),
          { target: '#failed', actions: ['clearBossReplyContext', 'rememberInvalidBossInput'] },
        ],
        BOSS_TASK: [
          { guard: 'validTask', target: '#writing', actions: ['clearBossReplyContext', 'startTask'] },
          { target: '#failed', actions: ['clearBossReplyContext', 'rememberInvalidBossInput'] },
        ],
      },
    },
    failed: {
      id: 'failed',
      description: '工作动作执行失败，等待 Boss 恢复。',
      tags: 'playbook.parked',
      meta: { playbook: { stateId: 'failed', description: '工作动作执行失败，等待 Boss 恢复。' } },
      on: {
        BOSS_TASK: [
          { guard: 'validTask', target: '#writing', actions: ['clearBossReplyContext', 'startTask'] },
          { target: '#failed', actions: ['clearBossReplyContext', 'rememberInvalidBossInput'] },
        ],
      },
    },
    generated: {
      id: 'generated', type: 'final', description: '已生成',
      meta: { playbook: { stateId: 'generated', description: '已生成', terminal: 'success' } },
    },
    unavailable: {
      id: 'unavailable', type: 'final', description: '无法生成',
      meta: { playbook: { stateId: 'unavailable', description: '无法生成', terminal: 'failure' } },
    },
  },
});

export default flowMachine;
