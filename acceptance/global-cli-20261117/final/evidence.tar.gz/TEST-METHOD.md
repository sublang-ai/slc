# Global SLC compilation acceptance method

This acceptance evaluates installation, compilation and safe runtime initialization. It does not evaluate business execution or output quality. The spex-playbook Skill is excluded.

## Fixed inputs and two installation layers

Use the same complete workflow definition copied byte-for-byte from `/Users/boboyang/work/goodme-skill-test/long-task-clean-082/flow.md`; record its SHA-256 before every case. It defines one delegated commit-message action, an absolute task-file Boss input, all writing rules, and separate success-message/failure-reason returns. Test users do not edit intermediate GEARS, FSM, linked code or generated entries.

The local functional layer uses locally built distributable tarballs, installed into an isolated tool location; any preparation needed to supply coordinated unpublished packages is recorded and cannot establish automatic registry acquisition. The registry layer uses a clean global-style prefix and exactly one package request: the exact SLC prerelease. Playbook, Cligent, both SDKs, their native components and compiler tools must arrive through declared dependencies. A shared download cache is allowed and reported; a new installation prefix and a new workflow directory are mandatory. No source-directory links, developer trees, manually installed SDKs or previous compilation caches may stand in for candidate dependencies.

Node and npm are host prerequisites, separate from workflow/project dependencies. Native macOS arm64, Linux x64 and Windows x64 use their recorded Node versions. Windows runs native Node/npm/PowerShell or CMD; WSL and POSIX tmux UI are not used to establish Windows support.

## Real CLI matrix

Each OS/backend combination runs each row below in a new empty child. Copy only the input definition before compilation. Choose Codex using existing login authentication, or Claude Code using the authorized GLM endpoint/model and private test credential, through environment variables. Run the installed SLC executable, without creating a child package manifest, tsconfig, node_modules or Git repository by hand.

| Parent fixture | Required distinction |
| --- | --- |
| No project | No ancestor Node manifest or runtime, outside Git. |
| CommonJS | An ancestor explicitly declares CommonJS. |
| ESM | An ancestor explicitly declares ESM, inside a parent Git repository. |
| Compatible runtime | Parent runtime code is compatible but has distinct physical roots; the compiler must select its installed pair. |
| Missing declared runtime | Parent declares unavailable dependencies, outside Git. |
| Conflicting runtime | Parent has an incompatible runtime whose import must not be selected. |
| Unrelated TypeScript setup | Parent tsconfig and ambient declarations would break a project-selected check. |
| Spaces and Chinese path | Both spelling and inherited CommonJS scope are exercised, outside Git. |

The intended matrix is 3 native platforms × 2 configured backends × 8 parent fixtures = 48 independent cold workflow compilations. Case records distinguish every attempted candidate, retry, failure, interruption and successful rerun. A generated file alone, a cache hit, an Agent's statement, or an auxiliary mock test cannot count as this matrix's pass.

## Observable pass conditions

1. The actual CLI exits zero and publishes a managed entry plus accepted manifest; required compiler gates actually ran on the accepted bytes.
2. The entry is JavaScript `.mjs`; generated runtime files load through the workflow-owned private ESM package and the two owned runtime directory links. Windows uses junctions, with no Developer Mode changes for preparation.
3. Actual runtime imports agree with the recorded physical Playbook/XState identities. An independent native process validates the bundle and initializes/disposes the real factory with inert recording capabilities, without a business Boss turn or real Agent/effect dispatch.
4. Parent manifests, locks, config, dependencies and Git metadata retain their recorded identities. The child has no user-created Node project or Git repository.
5. Exact source, candidate versions, safe environment values, commands, stdout/stderr, start/end times, exit status, file hashes, phase snapshots and gate findings are retained and linked from the case result. Credentials are excluded and evidence is scanned before delivery.

## Deterministic regressions

Separately exercise occupied paths and unsafe metadata; missing/malformed managed markers; changed executable code and missing runtime targets; deleted Source/GEARS/log archives; unchanged reuse; changed compiler/runtime identity; failed/canceled recompilation preserving the last accepted bundle; fresh transitive ESM/CommonJS reads; explicit return-field omissions at the producer; legal absolute-path public entries and JSON witnesses with false/private-context controls; finite-budget diagnosis; initialization/construction/disposal failures; legacy `.ts` consumers; invocation inside the artifact directory; and supported/unsupported actual `-o` targets.

These cases validate compiler and host mechanics. Their synthetic performing models or fixtures remain auxiliary evidence and do not replace real backend compilations. Existing repository regressions remain required.

## Review and delivery gate

Independent reviewers examine the design and implementation before formal execution, and different fresh-context reviewers examine actual execution and per-requirement delivery evidence. Missing coverage is a gap, not a pass. For temporarily unavailable cases, retain the reason, risk and alternative test; revisit them after other work. Merge only when required native acceptance and exact-head CI are satisfied.
