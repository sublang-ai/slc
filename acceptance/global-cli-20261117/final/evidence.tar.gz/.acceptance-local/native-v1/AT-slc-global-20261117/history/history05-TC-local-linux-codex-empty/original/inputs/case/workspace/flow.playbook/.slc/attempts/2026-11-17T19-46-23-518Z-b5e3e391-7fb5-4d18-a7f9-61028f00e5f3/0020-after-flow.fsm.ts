import { setup, assign, fromPromise } from 'xstate';
const prompt = "读取 Boss 提供的任务文件及其引用的改动和上下文，然后完成提交说明。\n生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n只生成文本，不暂存文件，不执行 git commit，不 amend；不得通过执行 Git 提交来代替输出说明。\n标题使用 type(scope): imperative summary 格式，其中 type 为提交类型、scope 为范围、imperative summary 为祈使表达的摘要；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。\n成功生成时，返回完整代码块；任务文件或引用的输入无法读取、或资料不足以生成说明时，说明具体限制。\n\n> <boss-input>";
export interface MachineInput { bossInput?: string }
export interface PendingBossQuestion {
  questionId: 'compose'; resumeStateId: 'compose'; sourceItem: 'flow-5';
  asker: { kind: 'role'; roleId: '提交说明作者' }; question: string;
}
export interface PlayerInput {
  stateId: 'compose'; role: '提交说明作者'; sourceItem: 'flow-5'; prompt: string; bossInput: string;
  result: Record<'generated' | 'unavailable' | 'needsBossReply', string>;
  pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
}
export type PlayerOutput = { guard: 'generated'; message: string } | { guard: 'unavailable'; reason: string } | { guard: 'needsBossReply'; question: string };
export type MachineOutput = { message: string } | { reason: string };
type Context = { bossInput?: string; pendingBossQuestion?: PendingBossQuestion; bossReply?: string; terminalOutput?: MachineOutput; lastError?: { name: string; message: string; stack?: string } };
type Events = { type: 'START'; bossInput: string } | { type: 'BOSS_INTERRUPT'; targetId: 'ready' | 'compose' | 'failed' } | { type: 'BOSS_REPLY'; answer: string; questionId?: string };
export const concurrentRoleSets: readonly (readonly string[])[] = [];
const result = {
  generated: '提交说明作者成功生成提交说明。Output shall include `message: <完整代码块字符串>`。',
  unavailable: '任务文件或引用的输入无法读取、或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`。',
  needsBossReply: "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.",
};
function record(value: unknown): value is Record<string, unknown> { return typeof value === 'object' && value !== null; }
function output(event: unknown): PlayerOutput | undefined {
  if (!record(event) || !record(event.output)) return undefined;
  const v = event.output;
  if (v.guard === 'generated' && typeof v.message === 'string' && v.message.trim()) return { guard: 'generated', message: v.message };
  if (v.guard === 'unavailable' && typeof v.reason === 'string' && v.reason.trim()) return { guard: 'unavailable', reason: v.reason };
  if (v.guard === 'needsBossReply' && typeof v.question === 'string' && v.question.trim()) return { guard: 'needsBossReply', question: v.question };
  return undefined;
}
function clear(context: Context): Context {
  return { ...context, pendingBossQuestion: undefined, bossReply: undefined };
}
function bossInterrupts(ids: readonly ('ready' | 'compose' | 'failed')[]) {
  return ids.map(id => ({ target: '#' + id, reenter: true,
    guard: ({ context, event }: { context: Context; event: Events }) => event.type === 'BOSS_INTERRUPT' && event.targetId === id && (id !== 'compose' || (typeof context.bossInput === 'string' && context.bossInput.trim().startsWith('/'))),
    actions: 'clearBossReplyContext' as const,
  }));
}
function resumableStates(ids: readonly ['compose']) {
  return ids.map(id => ({ target: '#' + id,
    guard: ({ context, event }: { context: Context; event: Events }) => event.type === 'BOSS_REPLY' && typeof event.answer === 'string' && event.answer.trim().length > 0 && (event.questionId === undefined || event.questionId === id) && context.pendingBossQuestion?.resumeStateId === id && context.pendingBossQuestion.sourceItem === 'flow-5' && context.pendingBossQuestion.asker.roleId === '提交说明作者',
    actions: 'rememberBossReply' as const,
  }));
}
export const machine = setup({
  types: { context: {} as Context, events: {} as Events, input: {} as MachineInput, output: {} as MachineOutput },
  actors: { player: fromPromise<PlayerOutput, PlayerInput>(async () => { throw new Error('player actor must be provided by the runner'); }) },
  actions: {
    'playbook.acceptedOutcome': (_args, _params: { source: string; target: string; acceptedOutcome: string }) => {},
    clearBossReplyContext: assign(({ context }) => clear(context)),
    start: assign(({ event }) => event.type === 'START' ? { bossInput: event.bossInput, terminalOutput: undefined, lastError: undefined } : {}),
    rememberGenerated: assign(({ event }) => { const v = output(event); return v?.guard === 'generated' ? { terminalOutput: { message: v.message } } : {}; }),
    rememberUnavailable: assign(({ event }) => { const v = output(event); return v?.guard === 'unavailable' ? { terminalOutput: { reason: v.reason } } : {}; }),
    setPendingBossQuestion: assign(({ context, event }) => {
      const v = output(event); const next = clear(context);
      return v?.guard === 'needsBossReply' ? { ...next, pendingBossQuestion: { questionId: 'compose' as const, resumeStateId: 'compose' as const, sourceItem: 'flow-5' as const, asker: { kind: 'role' as const, roleId: '提交说明作者' as const }, question: v.question } } : next;
    }),
    rememberBossReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    rememberError: assign(({ event }) => {
      const error: unknown = record(event) && 'error' in event ? event.error : undefined;
      return { lastError: error instanceof Error ? { name: error.name, message: error.message, ...(error.stack ? { stack: error.stack } : {}) } : { name: 'Error', message: typeof error === 'string' ? error : 'Malformed actor output or Boss reply.' } };
    }),
  },
  guards: {
    validEntry: ({ event }) => event.type === 'START' && typeof event.bossInput === 'string' && event.bossInput.trim().startsWith('/'),
    generated: ({ event }) => output(event)?.guard === 'generated',
    unavailable: ({ event }) => output(event)?.guard === 'unavailable',
    needsBossReply: ({ event }) => output(event)?.guard === 'needsBossReply',
  },
}).createMachine({
  id: 'flow', initial: 'ready',
  context: ({ input }) => ({ ...(input?.bossInput !== undefined ? { bossInput: input.bossInput } : {}) }),
  output: ({ context }) => { if (!context.terminalOutput) throw new Error('No terminal output'); return context.terminalOutput; },
  on: { BOSS_INTERRUPT: bossInterrupts(['ready', 'compose', 'failed']) },
  states: {
    ready: { id: 'ready', description: '等待 Boss 提供任务文件绝对路径。', tags: ['playbook.parked'], meta: { playbook: { stateId: 'ready', description: '等待 Boss 提供任务文件绝对路径。' } }, on: { START: { guard: 'validEntry', target: 'compose', actions: ['clearBossReplyContext', 'start'] } } },
    compose: {
      id: 'compose', description: '生成提交说明。', tags: ['playbook.busy'], meta: { playbook: { stateId: 'compose', description: '生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({ stateId: 'compose', sourceItem: 'flow-5', role: '提交说明作者', prompt, result, bossInput: context.bossInput!, ...(context.pendingBossQuestion ? { pendingBossQuestion: context.pendingBossQuestion } : {}), ...(context.bossReply !== undefined ? { bossReply: context.bossReply } : {}) }),
        onDone: [
          { guard: 'generated', target: 'done', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'compose', target: 'done', acceptedOutcome: 'generated' } }, 'rememberGenerated', 'clearBossReplyContext'] },
          { guard: 'unavailable', target: 'unavailable', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'compose', target: 'unavailable', acceptedOutcome: 'unavailable' } }, 'rememberUnavailable', 'clearBossReplyContext'] },
          { guard: 'needsBossReply', target: 'awaitBossReply', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'compose', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } }, 'setPendingBossQuestion'] },
          { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] },
        ],
        onError: { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] },
      },
    },
    awaitBossReply: { id: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question.", tags: ['playbook.parked'], meta: { playbook: { stateId: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question." } }, on: { BOSS_REPLY: [...resumableStates(['compose']), { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] }], START: { guard: 'validEntry', target: 'compose', actions: ['clearBossReplyContext', 'start'] } } },
    failed: { id: 'failed', description: '执行出错，等待 Boss 恢复。', tags: ['playbook.parked'], meta: { playbook: { stateId: 'failed', description: '执行出错，等待 Boss 恢复。' } }, on: { START: { guard: 'validEntry', target: 'compose', actions: ['clearBossReplyContext', 'start'] } } },
    done: { id: 'done', type: 'final', description: '已生成', meta: { playbook: { stateId: 'done', description: '已生成', terminal: 'success' } } },
    unavailable: { id: 'unavailable', type: 'final', description: '无法生成', meta: { playbook: { stateId: 'unavailable', description: '无法生成', terminal: 'failure' } } },
  },
});
export default machine;
