import { setup, assign, fromPromise, enqueueActions } from 'xstate';

export type MachineInput = { bossInput?: string };
export type PendingBossQuestion = {
  questionId: 'writeMessage'; resumeStateId: 'writeMessage'; sourceItem: 'flow-5';
  asker: { kind: 'role'; roleId: '提交说明作者' }; question: string;
};
export type PlayerInput = {
  stateId: 'writeMessage'; role: '提交说明作者'; sourceItem: 'flow-5';
  prompt: string; bossInput: string; result: Record<string, string>;
  pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
};
export type PlayerOutput =
  | { guard: 'generated'; message: string }
  | { guard: 'unable'; reason: string }
  | { guard: 'needsBossReply'; question: string };
export type MachineOutput = { message: string } | { reason: string };
type Events =
  | { type: 'START'; bossInput: string }
  | { type: 'BOSS_INTERRUPT'; targetId: 'ready' | 'writeMessage' | 'failed' }
  | { type: 'BOSS_REPLY'; answer: string; questionId?: string };
type Context = {
  bossInput: string;
  terminalOutput?: MachineOutput;
  pendingBossQuestion?: PendingBossQuestion;
  bossReply?: string;
  lastError?: { name: string; message: string; stack?: string };
};
export const concurrentRoleSets = [] as const;
const prompt = "读取 Boss 提供的任务文件及其引用的改动和上下文，结合项目约定，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格。\n成功生成时返回 message 字符串，内容为完整代码块；任务文件或引用的输入无法读取、或资料不足以生成说明时，返回 reason 字符串说明具体限制。\n> <boss-input>";
const result = {
  generated: '成功生成提交说明。Output shall include `message: <完整代码块字符串>`。',
  unable: '任务文件或引用的输入无法读取、或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`。',
  needsBossReply: "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.",
};
function outputOf(event: unknown): PlayerOutput | undefined {
  if (!event || typeof event !== 'object' || !('output' in event)) return undefined;
  const value = event.output;
  if (!value || typeof value !== 'object' || !('guard' in value)) return undefined;
  if (value.guard === 'generated' && 'message' in value && typeof value.message === 'string' && value.message.trim()) return { guard: 'generated', message: value.message };
  if (value.guard === 'unable' && 'reason' in value && typeof value.reason === 'string' && value.reason.trim()) return { guard: 'unable', reason: value.reason };
  if (value.guard === 'needsBossReply' && 'question' in value && typeof value.question === 'string' && value.question.trim()) return { guard: 'needsBossReply', question: value.question };
  return undefined;
}
function omitAbsentContext({ context }: { context: Context }): void {
  // Called only after assign creates a fresh context; prior snapshots are untouched.
  if (context.pendingBossQuestion === undefined) delete context.pendingBossQuestion;
  if (context.bossReply === undefined) delete context.bossReply;
  if (context.terminalOutput === undefined) delete context.terminalOutput;
  if (context.lastError === undefined) delete context.lastError;
}
function clearBossReplyContext({ context }: { context: Context }): Context {
  const { pendingBossQuestion: _question, bossReply: _reply, ...rest } = context;
  return { ...rest, pendingBossQuestion: undefined, bossReply: undefined };
}
function setPendingBossQuestion({ context, event }: { context: Context; event: unknown }): Context {
  const output = outputOf(event);
  if (output?.guard !== 'needsBossReply') return context;
  const next = clearBossReplyContext({ context });
  return { ...next, pendingBossQuestion: {
    questionId: 'writeMessage', resumeStateId: 'writeMessage', sourceItem: 'flow-5',
    asker: { kind: 'role', roleId: '提交说明作者' }, question: output.question,
  } };
}
function bossInterrupts(ids: readonly ('ready' | 'writeMessage' | 'failed')[]) {
  return ids.map(id => ({
    target: '#' + id, reenter: true,
    guard: ({ context, event }: { context: Context; event: Events }) => event.type === 'BOSS_INTERRUPT' && event.targetId === id && (id !== 'writeMessage' || (typeof context.bossInput === 'string' && !!context.bossInput.trim())),
    actions: 'clearBossReplyContext' as const,
  }));
}
function resumableStates(ids: readonly ['writeMessage']) {
  return ids.map(id => ({
    target: '#' + id,
    guard: ({ context, event }: { context: Context; event: Events }) => event.type === 'BOSS_REPLY' && typeof event.answer === 'string' && !!event.answer.trim() && context.pendingBossQuestion?.resumeStateId === id && (event.questionId === undefined || event.questionId === context.pendingBossQuestion.questionId),
    actions: 'rememberBossReply' as const,
  }));
}
export const machine = setup({
  types: {} as { context: Context; events: Events; input: MachineInput; output: MachineOutput },
  actors: {
    player: fromPromise<PlayerOutput, PlayerInput>(async () => { throw new Error('player actor must be provided by the runner'); }),
  },
  actions: {
    'playbook.acceptedOutcome': (_args, _params: { source: string; target: string; acceptedOutcome: string }) => {},
    clearBossReplyContext: enqueueActions(({ enqueue }) => {
      enqueue.assign(clearBossReplyContext);
      enqueue(omitAbsentContext);
    }),
    setPendingBossQuestion: enqueueActions(({ enqueue }) => {
      enqueue.assign(setPendingBossQuestion);
      enqueue(omitAbsentContext);
    }),

    rememberBossReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    begin: assign(({ event }) => ({ bossInput: event.type === 'START' ? event.bossInput : '' })),
    resetRun: enqueueActions(({ enqueue }) => {
      enqueue.assign(({ context }) => ({ bossInput: context.bossInput, terminalOutput: undefined, lastError: undefined, pendingBossQuestion: undefined, bossReply: undefined }));
      enqueue(omitAbsentContext);
    }),
    rememberOutput: assign(({ context, event }) => {
      const value = outputOf(event);
      return value?.guard === 'generated' ? { ...context, terminalOutput: { message: value.message } } : value?.guard === 'unable' ? { ...context, terminalOutput: { reason: value.reason } } : context;
    }),
    rememberError: assign(({ context, event }) => {
      const error: unknown = 'error' in event ? event.error : undefined;
      const normalized = error instanceof Error ? { name: error.name, message: error.message, ...(typeof error.stack === 'string' ? { stack: error.stack } : {}) } : { name: 'Error', message: typeof error === 'string' ? error : 'Invalid actor output or Boss reply.' };
      return { ...context, lastError: normalized };
    }),
  },
}).createMachine({
  id: 'flow', initial: 'ready',
  context: ({ input }) => ({ bossInput: input?.bossInput ?? '' }),
  output: ({ context }) => {
    if (!context.terminalOutput) throw new Error('Missing terminal output');
    return context.terminalOutput;
  },
  on: { BOSS_INTERRUPT: bossInterrupts(['ready', 'writeMessage', 'failed']) },
  states: {
    ready: {
      id: 'ready', description: '等待任务文件路径。', tags: 'playbook.parked',
      meta: { playbook: { stateId: 'ready', description: '等待任务文件路径。' } },
      on: { START: { guard: ({ event }) => typeof event.bossInput === 'string' && !!event.bossInput.trim(), target: 'writeMessage', actions: ['resetRun', 'begin'] } },
    },
    writeMessage: {
      id: 'writeMessage', description: '生成提交说明。', tags: 'playbook.busy',
      meta: { playbook: { stateId: 'writeMessage', description: '生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({ stateId: 'writeMessage', sourceItem: 'flow-5', role: '提交说明作者', prompt, result, bossInput: context.bossInput,
          ...(context.pendingBossQuestion ? { pendingBossQuestion: context.pendingBossQuestion } : {}),
          ...(context.bossReply !== undefined ? { bossReply: context.bossReply } : {}),
        }),
        onDone: [
          { guard: ({ event }) => outputOf(event)?.guard === 'generated', target: 'generated', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'generated', acceptedOutcome: 'generated' } }, 'rememberOutput', 'clearBossReplyContext'] },
          { guard: ({ event }) => outputOf(event)?.guard === 'unable', target: 'unable', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'unable', acceptedOutcome: 'unable' } }, 'rememberOutput', 'clearBossReplyContext'] },
          { guard: ({ event }) => outputOf(event)?.guard === 'needsBossReply', target: 'awaitBossReply', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } }, 'setPendingBossQuestion'] },
          { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] },
        ],
        onError: { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question.", tags: 'playbook.parked',
      meta: { playbook: { stateId: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question." } },
      on: {
        BOSS_REPLY: [...resumableStates(['writeMessage']), { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] }],
        START: { guard: ({ event }) => typeof event.bossInput === 'string' && !!event.bossInput.trim(), target: 'writeMessage', actions: ['clearBossReplyContext', 'resetRun', 'begin'] },
      },
    },
    failed: {
      id: 'failed', description: '执行异常，等待 Boss 恢复。', tags: 'playbook.parked',
      meta: { playbook: { stateId: 'failed', description: '执行异常，等待 Boss 恢复。' } },
      on: { START: { guard: ({ event }) => typeof event.bossInput === 'string' && !!event.bossInput.trim(), target: 'writeMessage', actions: ['resetRun', 'begin'] } },
    },
    generated: { id: 'generated', type: 'final', description: '已生成', meta: { playbook: { stateId: 'generated', description: '已生成', terminal: 'success' } } },
    unable: { id: 'unable', type: 'final', description: '无法生成', meta: { playbook: { stateId: 'unable', description: '无法生成', terminal: 'failure' } } },
  },
});
export default machine;
