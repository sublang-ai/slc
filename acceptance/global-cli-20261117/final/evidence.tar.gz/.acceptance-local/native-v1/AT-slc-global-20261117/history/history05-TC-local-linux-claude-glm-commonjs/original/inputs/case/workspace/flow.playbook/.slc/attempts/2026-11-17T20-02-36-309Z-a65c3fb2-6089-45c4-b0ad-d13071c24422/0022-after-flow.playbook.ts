// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: 2026 Boboyang
// Linked by slc under the complete slc/link.md (ordinary linking: the source's
// standalone relay lines use non-ASCII placeholder tokens, outside the
// materializer profiles' ASCII composer, so the playbook carries its own
// quoted-relay player composer over the shared engine).
// FSM: "./flow.fsm.ts"; export: flowMachine; strategies: shared defaults with
// a custom standalone quoted-relay player composer; judge-classified Boss
// entry (START carries two required textual fields, so no deterministic
// single-text-field entry applies); LLM-judge adjudication (shared default).
import { flowMachine as machine } from './flow.fsm.ts';
import {
  createXStatePlaybookRuntime, snapshotJsonValue, defaultComposePlayerPrompt,
  type PlaybookPlayerInput,
  type XStatePlaybookRuntimeConstruction,
  type XStatePlaybookRuntimeFactory,
  type XStatePlaybookRuntimeSpecV3,
} from '@sublang/playbook/xstate-runtime';
export type {
  PlayerResult,
  PlayerCallOptions,
  PlayerSessionStore,
  CaptainResult,
  CaptainCallOptions,
  JsonValue,
  NormalizedError,
  PlaybookCallRequest,
  PlaybookCallResult,
  PlaybookCallStart,
  PlaybookStateValue,
  PlaybookState,
  PlaybookPendingCall,
  PlaybookRunResult,
  PlaybookRuntime,
  PlaybookRuntimeFactory,
  PlaybookRuntimeSnapshot,
  PlaybookSession,
  PlaybookPorts,
  PlaybookTraceEvent,
  PlaybookTraceType,
  PlaybookControlReceipt,
  PlaybookControlView,
} from '@sublang/playbook/runtime';

export interface PlaybookRuntimeOptions {}
export type PlaybookHostCapabilities = XStatePlaybookRuntimeConstruction<
  PlaybookRuntimeOptions, { readonly authority: object }
>['hostCapabilities'];

const OPTION_SCHEMA = {} as const;
const INPUT_MAPPING = {} as const;
const RESUMABLE_STATE_IDS: ReadonlySet<string> = new Set([
  "generateMessage"
]);
const UNFINISHED_FINAL_STATE_IDS: ReadonlySet<string> = new Set([
  "cannotGenerate"
]);
const VERBATIM_PAYLOAD_FIELDS: ReadonlySet<string> = new Set<string>([]);
export function validateOptions(value: unknown): PlaybookRuntimeOptions {
  const captured = snapshotJsonValue(value === undefined ? {} : value, "FLOW runtime options");
  if (captured === null || typeof captured !== 'object' || Array.isArray(captured)) {
    throw new TypeError("FLOW runtime options must be an object");
  }
  const fields = captured as Readonly<Record<string, unknown>>;
  for (const key of Object.keys(captured)) {
    if (!Object.hasOwn(OPTION_SCHEMA, key)) throw new TypeError("FLOW runtime options." + key + ' is not declared');
  }
  for (const [key, schema] of Object.entries(OPTION_SCHEMA) as [string, { type: string; required: boolean }][]) {
    if (!Object.hasOwn(captured, key)) {
      if (schema.required) throw new TypeError("FLOW runtime options." + key + ' is required');
    } else if (typeof fields[key] !== schema.type || (schema.type === 'number' && !Number.isFinite(fields[key]))) {
      throw new TypeError("FLOW runtime options." + key + ' must be a ' + schema.type);
    }
  }
  return captured as unknown as PlaybookRuntimeOptions;
}
// The source authors its runtime-value relays as standalone quoted lines with
// non-ASCII placeholder tokens (`> <任务文件的绝对路径>`, `> <用户输入>`), which the
// shared default composer's ASCII token class cannot substitute. Composition
// keeps the materializer profiles' quoted-relay semantics — a standalone
// `> <token>` line takes its whole value quoted line by line with `> `, an
// empty value omits the complete template line, and a missing or non-string
// value retains the authored token — over the shared continuation prefix.
function composePlayerPrompt(input: PlaybookPlayerInput, _identity?: unknown, resuming = false): string {
  const fields = input as unknown as Readonly<Record<string, unknown>>;
  const mapping: Readonly<Record<string, string>> = {};
  const body = input.prompt.replace(
    /^> <(#|[^\s<>`]{1,60})>(\r?\n|$)|<(#|[^\s<>`]{1,60})>/gm,
    (match: string, quoted: string | undefined, ending: string | undefined, inline: string | undefined): string => {
      const token = quoted ?? inline!;
      const field = mapping[token] ?? (token === '#' ? 'irNumber' : token.replace(/-([A-Za-z0-9])/g, (_match: string, next: string) => next.toUpperCase()));
      const value = fields[field];
      if (typeof value !== 'string') return match;
      if (quoted === undefined) return value;
      if (value === '') return '';
      return value.split(/(\r?\n)/).map((part, index) => index % 2 === 0 && part !== '' ? '> ' + part : part).join('') + (ending ?? '');
    },
  );
  // The shared composer supplies only the continuation prefix; rendered values
  // never reenter substitution and the original PlayerInput remains unchanged.
  return defaultComposePlayerPrompt({ ...input, prompt: '' }, mapping, resuming) + body;
}
const runtimeSpec = {
  composePlayerPrompt,
  ...{
  "label": "FLOW",
  "compat": {
    "artifactSchema": 3,
    "runtimeAbi": 1
  },
  "bossEvents": [
    {
      "type": "START",
      "fields": {
        "任务文件的绝对路径": {
          "source": "judge",
          "required": true
        },
        "用户输入": {
          "source": "judge",
          "required": true
        }
      }
    }
  ],
  "roleStates": {
    "generateMessage": {
      "role": "提交说明作者",
      "label": "提交说明作者读取任务文件及其引用的改动和上下文，完成提交说明。"
    }
  },
  "outcomeAuthority": {
    "governedPlayerStates": {
      "generateMessage": {
        "message": {
          "fields": {
            "message": "semantic"
          },
          "repositoryDisposition": "unchanged"
        },
        "reason": {
          "fields": {
            "reason": "semantic"
          },
          "repositoryDisposition": "unchanged"
        },
        "needsBossReply": {
          "fields": {
            "question": "presentation"
          },
          "repositoryDisposition": "unchanged"
        }
      }
    }
  },
  "placeholderFields": {},
  "transitionEventFields": [
    "任务文件的绝对路径",
    "用户输入",
    "answer",
    "questionId"
  ],
  "controlContextFields": []
},
  snapshotOptions: validateOptions,
  machineInput: (options: PlaybookRuntimeOptions) => Object.fromEntries(
    Object.entries(INPUT_MAPPING).filter(([, key]) => options[key as keyof PlaybookRuntimeOptions] !== undefined)
      .map(([field, key]) => [field, options[key as keyof PlaybookRuntimeOptions]]),
  ),
  verbatimPayloadFields: VERBATIM_PAYLOAD_FIELDS,
  resumableStateIds: RESUMABLE_STATE_IDS,
  unfinishedFinalStateIds: UNFINISHED_FINAL_STATE_IDS,
} satisfies XStatePlaybookRuntimeSpecV3<PlaybookRuntimeOptions>;

export const _internal = {
  composePlayerPrompt,
  RESUMABLE_STATE_IDS,
  UNFINISHED_FINAL_STATE_IDS,
  VERBATIM_PAYLOAD_FIELDS,
};
const createPlaybookRuntime: XStatePlaybookRuntimeFactory<
  XStatePlaybookRuntimeConstruction<PlaybookRuntimeOptions, PlaybookHostCapabilities>, 3
> = createXStatePlaybookRuntime<PlaybookRuntimeOptions, PlaybookHostCapabilities>(machine, runtimeSpec);
export default createPlaybookRuntime;
