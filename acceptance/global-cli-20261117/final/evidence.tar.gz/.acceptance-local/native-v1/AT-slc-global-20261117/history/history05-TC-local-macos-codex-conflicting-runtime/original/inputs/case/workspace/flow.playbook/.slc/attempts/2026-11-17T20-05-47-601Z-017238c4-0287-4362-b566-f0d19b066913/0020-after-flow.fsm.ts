import { setup, fromPromise, assign } from 'xstate';

export type MachineInput = { taskFilePath?: string };
export type PlayerOutput =
  | { guard: 'generated'; message: string }
  | { guard: 'unable'; reason: string }
  | { guard: 'needsBossReply'; question: string };
export type PendingBossQuestion = {
  questionId: 'generate'; resumeStateId: 'generate'; sourceItem: 'flow-5';
  asker: { kind: 'role'; roleId: '提交说明作者' }; question: string;
};
export type PlayerInput = {
  stateId: 'generate'; role: '提交说明作者'; sourceItem: 'flow-5';
  prompt: string; result: Record<'generated' | 'unable' | 'needsBossReply', string>;
  taskFilePath: string; pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
};
export type MachineOutput = { message: string } | { reason: string };
type Events =
  | { type: 'GENERATE'; taskFilePath: string }
  | { type: 'BOSS_INTERRUPT'; targetId: 'ready' | 'generate' | 'failed'; taskFilePath?: string }
  | { type: 'BOSS_REPLY'; answer: string; questionId?: string };
type Context = {
  taskFilePath: string;
  pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
  terminalOutput?: MachineOutput;
  lastError?: { name: string; message: string; stack?: string };
};
export const concurrentRoleSets = [] as const;
const prompt = "读取 Boss 提供的任务文件及其引用的改动和上下文，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。\n\n> <task-file-path>";
const result = {
  generated: '成功生成提交说明。Output shall include `message: <完整代码块字符串>`。',
  unable: '任务文件或引用的输入无法读取、或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`。',
  needsBossReply: "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.",
} as const;
function record(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
function output(event: unknown): PlayerOutput | undefined {
  if (!record(event) || !record(event.output)) return undefined;
  const o = event.output;
  if (o.guard === 'generated' && typeof o.message === 'string' && o.message.trim()) return { guard: o.guard, message: o.message };
  if (o.guard === 'unable' && typeof o.reason === 'string' && o.reason.trim()) return { guard: o.guard, reason: o.reason };
  if (o.guard === 'needsBossReply' && typeof o.question === 'string' && o.question.trim()) return { guard: o.guard, question: o.question };
  return undefined;
}
function errorRecord(event: unknown): NonNullable<Context['lastError']> {
  const e = record(event) ? event.error : undefined;
  if (e instanceof Error) return { name: e.name, message: e.message, ...(typeof e.stack === 'string' ? { stack: e.stack } : {}) };
  return { name: 'Error', message: typeof e === 'string' ? e : 'Invalid acting output or Boss reply.' };
}
function absolutePath(value: unknown): value is string {
  return typeof value === 'string' && value.startsWith('/') && value.trim().length > 0;
}
function bossInterrupts(ids: readonly ('ready' | 'generate' | 'failed')[]) {
  return ids.map(id => ({
    target: '#' + id,
    reenter: true,
    guard: ({ context, event }: { context: Context; event: Events }) =>
      event.type === 'BOSS_INTERRUPT' && event.targetId === id &&
      (id !== 'generate' || absolutePath(event.taskFilePath ?? context.taskFilePath)),
    actions: ['clearBossReplyContext', 'interruptInput'] as const,
  }));
}
function resumableStates(ids: readonly ['generate']) {
  return ids.map(id => ({
    target: '#' + id,
    guard: ({ context, event }: { context: Context; event: Events }) =>
      event.type === 'BOSS_REPLY' && typeof event.answer === 'string' && event.answer.trim().length > 0 &&
      context.pendingBossQuestion?.resumeStateId === id &&
      (event.questionId === undefined || event.questionId === context.pendingBossQuestion.questionId),
    actions: 'rememberReply' as const,
  }));
}
const entry = { target: '#generate', guard: 'validEntry', actions: ['clearBossReplyContext', 'setInput'] } as const;
export const machine = setup({
  types: { context: {} as Context, events: {} as Events, input: {} as MachineInput, output: {} as MachineOutput },
  actors: {
    player: fromPromise<PlayerOutput, PlayerInput>(async () => { throw new Error('player actor must be provided by the runner'); }),
  },
  guards: {
    validEntry: ({ event }) => event.type === 'GENERATE' && absolutePath(event.taskFilePath),
    generated: ({ event }) => output(event)?.guard === 'generated',
    unable: ({ event }) => output(event)?.guard === 'unable',
    needsBossReply: ({ event }) => output(event)?.guard === 'needsBossReply',
  },
  actions: {
    'playbook.acceptedOutcome': (_args, _params: { source: string; target: string; acceptedOutcome: string }) => {},
    clearBossReplyContext: ({ context }) => { delete context.pendingBossQuestion; delete context.bossReply; },
    setInput: assign(({ event }) => event.type === 'GENERATE' ? { taskFilePath: event.taskFilePath } : {}),
    interruptInput: assign(({ context, event }) => ({ taskFilePath: event.type === 'BOSS_INTERRUPT' && event.taskFilePath !== undefined ? event.taskFilePath : context.taskFilePath })),
    rememberReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    setPendingBossQuestion: assign(({ event }) => {
      const o = output(event);
      if (o?.guard !== 'needsBossReply') return {};
      return { pendingBossQuestion: { questionId: 'generate' as const, resumeStateId: 'generate' as const, sourceItem: 'flow-5' as const, asker: { kind: 'role' as const, roleId: '提交说明作者' as const }, question: o.question } };
    }),
    rememberGenerated: assign(({ event }) => { const o = output(event); return o?.guard === 'generated' ? { terminalOutput: { message: o.message } } : {}; }),
    rememberUnable: assign(({ event }) => { const o = output(event); return o?.guard === 'unable' ? { terminalOutput: { reason: o.reason } } : {}; }),
    rememberError: assign(({ event }) => ({ lastError: errorRecord(event) })),
  },
}).createMachine({
  id: 'flow', initial: 'ready',
  context: ({ input }) => ({ taskFilePath: input?.taskFilePath ?? '' }),
  output: ({ context }) => {
    if (!context.terminalOutput) throw new Error('Missing terminal output');
    return context.terminalOutput;
  },
  on: { BOSS_INTERRUPT: bossInterrupts(['ready', 'generate', 'failed']) },
  states: {
    ready: {
      id: 'ready', description: '等待任务文件的绝对路径。', tags: 'playbook.parked',
      meta: { playbook: { stateId: 'ready', description: '等待任务文件的绝对路径。' } },
      on: { GENERATE: entry },
    },
    generate: {
      id: 'generate', description: '根据改动生成提交说明。', tags: 'playbook.busy',
      meta: { playbook: { stateId: 'generate', description: '根据改动生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({
          stateId: 'generate', sourceItem: 'flow-5', role: '提交说明作者', prompt, result,
          taskFilePath: context.taskFilePath,
          ...(context.pendingBossQuestion ? { pendingBossQuestion: context.pendingBossQuestion } : {}),
          ...(context.bossReply !== undefined ? { bossReply: context.bossReply } : {}),
        }),
        onDone: [
          { guard: 'generated', target: '#generated', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'generate', target: 'generated', acceptedOutcome: 'generated' } },
            'rememberGenerated', 'clearBossReplyContext',
          ] },
          { guard: 'unable', target: '#unable', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'generate', target: 'unable', acceptedOutcome: 'unable' } },
            'rememberUnable', 'clearBossReplyContext',
          ] },
          { guard: 'needsBossReply', target: '#awaitBossReply', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'generate', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } },
            'clearBossReplyContext', 'setPendingBossQuestion',
          ] },
          { target: '#failed', actions: ['rememberError', 'clearBossReplyContext'] },
        ],
        onError: { target: '#failed', actions: ['rememberError', 'clearBossReplyContext'] },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question.", tags: 'playbook.parked',
      meta: { playbook: { stateId: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question." } },
      on: {
        GENERATE: entry,
        BOSS_REPLY: [...resumableStates(['generate']), { target: '#failed', actions: ['rememberError', 'clearBossReplyContext'] }],
      },
    },
    failed: {
      id: 'failed', description: '执行错误，等待 Boss 恢复。', tags: 'playbook.parked',
      meta: { playbook: { stateId: 'failed', description: '执行错误，等待 Boss 恢复。' } },
      on: { GENERATE: entry },
    },
    generated: {
      id: 'generated', type: 'final', description: '已生成',
      meta: { playbook: { stateId: 'generated', description: '已生成', terminal: 'success' } },
    },
    unable: {
      id: 'unable', type: 'final', description: '无法生成',
      meta: { playbook: { stateId: 'unable', description: '无法生成', terminal: 'failure' } },
    },
  },
});
export default machine;
