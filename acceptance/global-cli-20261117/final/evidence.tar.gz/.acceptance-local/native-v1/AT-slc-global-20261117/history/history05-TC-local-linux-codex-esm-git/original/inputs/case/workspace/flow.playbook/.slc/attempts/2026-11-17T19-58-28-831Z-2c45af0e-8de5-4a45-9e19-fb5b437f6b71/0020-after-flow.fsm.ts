import { setup, fromPromise, assign } from 'xstate';

export type MachineInput = { taskFilePath?: string };
export type PendingBossQuestion = { questionId: 'compose'; resumeStateId: 'compose'; sourceItem: 'flow-5'; asker: { kind: 'role'; roleId: '提交说明作者' }; question: string };
export type PlayerInput = {
  stateId: 'compose'; role: '提交说明作者'; sourceItem: 'flow-5'; prompt: string;
  taskFilePath: string; result: Record<'generated' | 'unavailable' | 'needsBossReply', string>;
  pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
};
export type PlayerOutput =
  | { guard: 'generated'; message: string }
  | { guard: 'unavailable'; reason: string }
  | { guard: 'needsBossReply'; question: string };
export type MachineOutput = { message: string } | { reason: string };
export type Events =
  | { type: 'START'; taskFilePath: string }
  | { type: 'BOSS_INTERRUPT'; targetId: 'ready' | 'compose' | 'failed' }
  | { type: 'BOSS_REPLY'; answer: string; questionId?: string };
type Context = {
  taskFilePath: string;
  pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
  terminalOutput?: MachineOutput;
  lastError?: { name: string; message: string; stack?: string };
};
export const concurrentRoleSets = [] as const;
const prompt = "读取任务文件及其引用的改动和上下文，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n只生成文本，不暂存文件，不执行 git commit，不 amend。\n标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。\n成功生成时，返回 message 字符串，内容为完整代码块。\n任务文件或引用的输入无法读取、或资料不足以生成说明时，返回 reason 字符串说明具体限制。\n不得通过执行 Git 提交来代替输出说明。\n\n> <task-file-path>";
const result = {
  generated: '已成功生成提交说明。Output shall include `message: <完整代码块字符串>`。',
  unavailable: '任务文件或引用的输入无法读取、或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`。',
  needsBossReply: "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent’s prose>`.".replace('agent’s', "agent's"),
};
function record(value: unknown): value is Record<string, unknown> { return typeof value === 'object' && value !== null; }
function output(event: unknown): PlayerOutput | undefined {
  if (!record(event) || !record(event.output)) return undefined;
  const v = event.output;
  if (v.guard === 'generated' && typeof v.message === 'string' && v.message.trim()) return { guard: 'generated', message: v.message };
  if (v.guard === 'unavailable' && typeof v.reason === 'string' && v.reason.trim()) return { guard: 'unavailable', reason: v.reason };
  if (v.guard === 'needsBossReply' && typeof v.question === 'string' && v.question.trim()) return { guard: 'needsBossReply', question: v.question };
  return undefined;
}
function validPath(value: unknown): value is string { return typeof value === 'string' && value.startsWith('/') && value.trim().length > 0; }
function cleared(context: Context): Context {
  return { taskFilePath: context.taskFilePath, ...(context.terminalOutput ? { terminalOutput: context.terminalOutput } : {}), ...(context.lastError ? { lastError: context.lastError } : {}) };
}
export function clearBossReplyContext(context: Context): Context { return cleared(context); }
export function setPendingBossQuestion(event: unknown): PendingBossQuestion | undefined {
  const v = output(event);
  return v?.guard === 'needsBossReply' ? { questionId: 'compose', resumeStateId: 'compose', sourceItem: 'flow-5', asker: { kind: 'role', roleId: '提交说明作者' }, question: v.question } : undefined;
}
export function bossInterrupts(ids: readonly ('ready' | 'compose' | 'failed')[]) {
  return ids.map(id => ({
    guard: ({ context, event }: { context: Context; event: Events }) => event.type === 'BOSS_INTERRUPT' && event.targetId === id && (id !== 'compose' || validPath(context.taskFilePath)),
    target: '#' + id, reenter: true,
    actions: 'clearControl' as const,
  }));
}
export function resumableStates(ids: readonly 'compose'[]) {
  return ids.map(id => ({
    guard: ({ context, event }: { context: Context; event: Events }) => event.type === 'BOSS_REPLY' && typeof event.answer === 'string' && !!event.answer.trim() && context.pendingBossQuestion?.resumeStateId === id && (event.questionId === undefined || event.questionId === context.pendingBossQuestion.questionId),
    target: '#' + id,
    actions: 'receiveReply' as const,
  }));
}
const entry = {
  guard: ({ event }: { event: Events }) => event.type === 'START' && validPath(event.taskFilePath),
  target: '#compose',
  actions: 'start' as const,
};
export const machine = setup({
  types: { context: {} as Context, events: {} as Events, input: {} as MachineInput, output: {} as MachineOutput },
  actors: { player: fromPromise<PlayerOutput, PlayerInput>(async () => { throw new Error('player actor must be provided by the runner'); }) },
  actions: {
    start: assign(({ event }: { event: Events }) => ({ taskFilePath: event.type === 'START' ? event.taskFilePath : '', pendingBossQuestion: undefined, bossReply: undefined, terminalOutput: undefined, lastError: undefined })),
    clearControl: assign({ pendingBossQuestion: undefined, bossReply: undefined }),
    receiveReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    'playbook.acceptedOutcome': (_args, _params: { source: string; target: string; acceptedOutcome: string }) => {},
  },
}).createMachine({
  id: 'flow', initial: 'ready',
  context: ({ input }) => ({ taskFilePath: input?.taskFilePath ?? '' }),
  output: ({ context }) => { if (!context.terminalOutput) throw new Error('No terminal output'); return context.terminalOutput; },
  on: { BOSS_INTERRUPT: bossInterrupts(['ready', 'compose', 'failed']) },
  states: {
    ready: { id: 'ready', description: '等待任务文件绝对路径。', tags: ['playbook.parked'], meta: { playbook: { stateId: 'ready', description: '等待任务文件绝对路径。' } }, on: { START: entry } },
    compose: {
      id: 'compose', description: '生成提交说明。', tags: ['playbook.busy'],
      meta: { playbook: { stateId: 'compose', description: '生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({ stateId: 'compose', sourceItem: 'flow-5', role: '提交说明作者', prompt, result, taskFilePath: context.taskFilePath, ...(context.pendingBossQuestion ? { pendingBossQuestion: context.pendingBossQuestion } : {}), ...(context.bossReply !== undefined ? { bossReply: context.bossReply } : {}) }),
        onDone: [
          { guard: ({ event }) => output(event)?.guard === 'generated', target: '#generated', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'compose', target: 'generated', acceptedOutcome: 'generated' } },
            assign(({ context, event }) => { const v = output(event); return { ...clearBossReplyContext(context), pendingBossQuestion: undefined, bossReply: undefined, ...(v?.guard === 'generated' ? { terminalOutput: { message: v.message } } : {}) }; }),
          ] },
          { guard: ({ event }) => output(event)?.guard === 'unavailable', target: '#unavailable', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'compose', target: 'unavailable', acceptedOutcome: 'unavailable' } },
            assign(({ context, event }) => { const v = output(event); return { ...clearBossReplyContext(context), pendingBossQuestion: undefined, bossReply: undefined, ...(v?.guard === 'unavailable' ? { terminalOutput: { reason: v.reason } } : {}) }; }),
          ] },
          { guard: ({ event }) => output(event)?.guard === 'needsBossReply', target: '#awaitBossReply', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'compose', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } },
            assign(({ event }) => ({ pendingBossQuestion: setPendingBossQuestion(event), bossReply: undefined })),
          ] },
          { target: '#failed', actions: assign({ pendingBossQuestion: undefined, bossReply: undefined, lastError: { name: 'InvalidOutput', message: 'Malformed player output' } }) },
        ],
        onError: { target: '#failed', actions: assign(({ event }) => { const e: unknown = event.error; return { pendingBossQuestion: undefined, bossReply: undefined, lastError: e instanceof Error ? { name: e.name, message: e.message, ...(e.stack ? { stack: e.stack } : {}) } : { name: 'Error', message: String(e) } }; }) },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply', description: 'Waiting for Boss to answer the acting agent\'s question.', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'awaitBossReply', description: 'Waiting for Boss to answer the acting agent\'s question.' } },
      on: { START: entry, BOSS_REPLY: [...resumableStates(['compose']), { target: '#failed', actions: assign({ pendingBossQuestion: undefined, bossReply: undefined, lastError: { name: 'InvalidReply', message: 'Invalid Boss reply' } }) }] },
    },
    failed: { id: 'failed', description: '执行异常，等待恢复。', tags: ['playbook.parked'], meta: { playbook: { stateId: 'failed', description: '执行异常，等待恢复。' } }, on: { START: entry } },
    generated: { id: 'generated', type: 'final', description: '已生成', meta: { playbook: { stateId: 'generated', description: '已生成', terminal: 'success' } } },
    unavailable: { id: 'unavailable', type: 'final', description: '无法生成', meta: { playbook: { stateId: 'unavailable', description: '无法生成', terminal: 'failure' } } },
  },
});
export default machine;
