import { setup, assign, fromPromise } from 'xstate';

export type MachineInput = Record<string, never>;
export type MachineOutput = { message: string } | { reason: string };
export type PendingBossQuestion = {
  questionId: 'writing'; resumeStateId: 'writing'; sourceItem: 'flow-5';
  asker: { kind: 'role'; roleId: '提交说明作者' }; question: string;
};
export type PlayerInput = {
  stateId: 'writing'; role: '提交说明作者'; sourceItem: 'flow-5';
  prompt: string; bossInput: string;
  result: { generated: string; unable: string; needsBossReply: string };
  pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
};
export type PlayerOutput =
  | { guard: 'generated'; message: string }
  | { guard: 'unable'; reason: string }
  | { guard: 'needsBossReply'; question: string };
type Events =
  | { type: 'START'; bossInput: string }
  | { type: 'BOSS_INTERRUPT'; targetId: 'ready' | 'writing' | 'failed'; bossInput?: string }
  | { type: 'BOSS_REPLY'; answer: string; questionId?: string };
type Context = {
  bossInput: string;
  terminalResult?: MachineOutput;
  pendingBossQuestion?: PendingBossQuestion;
  bossReply?: string;
  lastError?: { name: string; message: string; stack?: string };
};
export const concurrentRoleSets = [] as const;
const prompt = "读取 Boss 提供的任务文件及其引用的改动和上下文，然后完成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n只生成文本，不暂存文件，不执行 git commit，不 amend。\n标题使用 \u003ctype\u003e(\u003cscope\u003e): \u003cimperative summary\u003e；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。\n成功生成时，返回 message 字符串，内容为完整代码块。\n任务文件或引用的输入无法读取、或资料不足以生成说明时，返回 reason 字符串说明具体限制。\n不得通过执行 Git 提交来代替输出说明。\n\u003e \u003cboss-input\u003e";
function outputOf(event: unknown): Record<string, unknown> | undefined {
  if (typeof event !== 'object' || event === null || !('output' in event)) return undefined;
  const output = event.output;
  return typeof output === 'object' && output !== null ? output as Record<string, unknown> : undefined;
}
function validText(value: unknown): value is string { return typeof value === 'string' && value.trim().length > 0; }
function normalizeError(event: unknown): { name: string; message: string; stack?: string } {
  const error = typeof event === 'object' && event !== null && 'error' in event ? event.error : event;
  if (error instanceof Error) return { name: error.name, message: error.message, ...(error.stack ? { stack: error.stack } : {}) };
  return { name: 'Error', message: typeof error === 'string' ? error : 'Malformed actor output or Boss reply.' };
}
function bossInterrupts(ids: readonly ('ready' | 'writing' | 'failed')[]) {
  return ids.map(id => ({
    target: `#${id}`, reenter: true,
    guard: ({ context, event }: { context: Context; event: Events }) => event.type === 'BOSS_INTERRUPT' && event.targetId === id && (id !== 'writing' || validText(event.bossInput ?? context.bossInput)),
    actions: ['clearBossReplyContext', 'interruptInput'] as const,
  }));
}
function resumableStates(ids: readonly 'writing'[]) {
  return ids.map(id => ({
    target: `#${id}`,
    guard: ({ context, event }: { context: Context; event: Events }) => event.type === 'BOSS_REPLY' && validText(event.answer) && context.pendingBossQuestion?.resumeStateId === id && (event.questionId === undefined || event.questionId === context.pendingBossQuestion.questionId),
    actions: 'storeBossReply' as const,
  }));
}
export const machine = setup({
  types: { context: {} as Context, events: {} as Events, input: {} as MachineInput, output: {} as MachineOutput },
  actors: { player: fromPromise<PlayerOutput, PlayerInput>(async () => { throw new Error('player actor must be provided by the runner'); }) },
  actions: {
    'playbook.acceptedOutcome': (_args, _params: { source: string; target: string; acceptedOutcome: string }) => {},
    clearBossReplyContext: assign({ pendingBossQuestion: undefined, bossReply: undefined }),
    startInput: assign(({ event }) => event.type === 'START' ? { bossInput: event.bossInput, terminalResult: undefined, lastError: undefined } : {}),
    interruptInput: assign(({ event }) => event.type === 'BOSS_INTERRUPT' ? { ...(event.bossInput !== undefined ? { bossInput: event.bossInput } : {}), terminalResult: undefined, lastError: undefined } : {}),
    storeBossReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    setPendingBossQuestion: assign(({ event }) => {
      const output = outputOf(event);
      return { pendingBossQuestion: { questionId: 'writing' as const, resumeStateId: 'writing' as const, sourceItem: 'flow-5' as const, asker: { kind: 'role' as const, roleId: '提交说明作者' as const }, question: typeof output?.question === 'string' ? output.question : '' }, bossReply: undefined };
    }),
    saveMessage: assign(({ event }) => { const output = outputOf(event); return typeof output?.message === 'string' ? { terminalResult: { message: output.message } } : {}; }),
    saveReason: assign(({ event }) => { const output = outputOf(event); return typeof output?.reason === 'string' ? { terminalResult: { reason: output.reason } } : {}; }),
    rememberError: assign(({ event }) => ({ lastError: normalizeError(event) })),
  },
}).createMachine({
  id: 'flow', initial: 'ready', context: { bossInput: '' },
  output: ({ context }) => { if (!context.terminalResult) throw new Error('Missing terminal result'); return context.terminalResult; },
  on: { BOSS_INTERRUPT: bossInterrupts(['ready', 'writing', 'failed']) },
  states: {
    ready: {
      id: 'ready', description: '等待任务文件绝对路径。', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'ready', description: '等待任务文件绝对路径。' } },
      on: { START: { guard: ({ event }) => validText(event.bossInput), target: 'writing', actions: ['clearBossReplyContext', 'startInput'] } },
    },
    writing: {
      id: 'writing', description: '生成提交说明。', tags: ['playbook.busy'],
      meta: { playbook: { stateId: 'writing', description: '生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({
          stateId: 'writing', role: '提交说明作者', sourceItem: 'flow-5', prompt, bossInput: context.bossInput,
          ...(context.pendingBossQuestion ? { pendingBossQuestion: context.pendingBossQuestion } : {}),
          ...(context.bossReply !== undefined ? { bossReply: context.bossReply } : {}),
          result: {
            generated: '成功生成提交说明。Output shall include `message: <完整代码块字符串>`.',
            unable: '任务文件或引用的输入无法读取、或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`.',
            needsBossReply: "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.",
          },
        }),
        onDone: [
          { guard: ({ event }) => { const o = outputOf(event); return o?.guard === 'generated' && typeof o.message === 'string'; }, target: 'generated', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'writing', target: 'generated', acceptedOutcome: 'generated' } }, 'saveMessage', 'clearBossReplyContext'] },
          { guard: ({ event }) => { const o = outputOf(event); return o?.guard === 'unable' && typeof o.reason === 'string'; }, target: 'unable', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'writing', target: 'unable', acceptedOutcome: 'unable' } }, 'saveReason', 'clearBossReplyContext'] },
          { guard: ({ event }) => { const o = outputOf(event); return o?.guard === 'needsBossReply' && validText(o.question); }, target: 'awaitBossReply', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'writing', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } }, 'setPendingBossQuestion'] },
          { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] },
        ],
        onError: { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply', description: 'Waiting for Boss to answer the acting agent\'s question.', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'awaitBossReply', description: 'Waiting for Boss to answer the acting agent\'s question.' } },
      on: {
        BOSS_REPLY: [...resumableStates(['writing']), { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] }],
        START: { guard: ({ event }) => validText(event.bossInput), target: 'writing', actions: ['clearBossReplyContext', 'startInput'] },
      },
    },
    failed: {
      id: 'failed', description: '执行失败，等待 Boss 恢复。', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'failed', description: '执行失败，等待 Boss 恢复。' } },
      on: { START: { guard: ({ event }) => validText(event.bossInput), target: 'writing', actions: ['clearBossReplyContext', 'startInput'] } },
    },
    generated: { id: 'generated', type: 'final', description: '已生成', meta: { playbook: { stateId: 'generated', description: '已生成', terminal: 'success' } } },
    unable: { id: 'unable', type: 'final', description: '无法生成', meta: { playbook: { stateId: 'unable', description: '无法生成', terminal: 'failure' } } },
  },
});
export default machine;