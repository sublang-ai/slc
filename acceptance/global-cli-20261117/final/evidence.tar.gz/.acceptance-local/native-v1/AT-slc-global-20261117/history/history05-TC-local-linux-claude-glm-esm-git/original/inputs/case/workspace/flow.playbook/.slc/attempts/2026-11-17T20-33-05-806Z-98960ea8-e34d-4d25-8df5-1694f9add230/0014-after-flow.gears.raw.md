# flow: 根据改动生成提交说明

## 意图

在用户要求写提交说明时，根据用户提供的改动及项目约定生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。
流程成功生成时以“已生成”结束，无法生成时以“无法生成”结束。

Roles:
- 提交说明作者

## 外部行为

### flow-1

When 用户要求“写提交说明”“commit message”“/commit”或“/caveman-commit”，Boss shall 用普通文本提供任务文件的绝对路径。

### flow-2

When [[flow-5](#flow-5)] 成功生成提交说明并返回 message，`flow` shall 以“已生成”结束，并将 message 原样交给调用者。

### flow-3

When 任务文件或引用的输入无法读取、或资料不足以生成说明，[[flow-5](#flow-5)] 返回 reason，`flow` shall 以“无法生成”结束，并将 reason 原样交给调用者。

### flow-4

`flow` shall 在 [[flow-5](#flow-5)] 中只生成文本，不暂存文件，不执行 git commit，不 amend，不得通过执行 Git 提交来代替输出说明。

## 内部行为

### flow-5

When 用户要求“写提交说明”“commit message”“/commit”或“/caveman-commit”且 Boss 用普通文本提供任务文件的绝对路径，Captain shall prompt 提交说明作者:

> 读取任务文件及其引用的改动和上下文，然后完成提交说明。
> 结合项目约定，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。
> 只生成文本，不暂存文件，不执行 git commit，不 amend。
> 标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。
> type 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。
> 标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。
> 标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。
> 正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。
> 不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。
> 表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。
> 输出可直接粘贴的代码块。
> 用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。
> 不得通过执行 Git 提交来代替输出说明。
> > <boss-intent>

Results:
- `message`: 成功生成提交说明，message 内容为完整代码块。Output shall include `message: <完整代码块>`.
- `reason`: 任务文件或引用的输入无法读取，或资料不足以生成说明，reason 说明具体限制。Output shall include `reason: <具体限制>`.

### flow-6

`flow` shall 只有 [[flow-5](#flow-5)] 一个工作动作，不增加额外审查或修改代码的阶段。

## 验证

### flow-7

Where Boss 用普通文本提供任务文件的绝对路径（[[flow-1](#flow-1)]），且任务文件及其引用的改动和上下文可读取、资料足以生成说明，When 用户要求“/commit”，`flow` shall 向提交说明作者送达 [[flow-5](#flow-5)] 的完整提示并只执行这一个工作动作（[[flow-6](#flow-6)]），不暂存文件、不执行 git commit、不 amend（[[flow-4](#flow-4)]），以“已生成”结束，并将 message 原样交给调用者（[[flow-2](#flow-2)]）。

### flow-8

Where 任务文件或引用的输入无法读取或资料不足以生成说明，When 用户要求“commit message”，`flow` shall 向提交说明作者送达 [[flow-5](#flow-5)] 的完整提示，以“无法生成”结束，并将 reason 原样交给调用者（[[flow-3](#flow-3)]）。
