import { setup, assign, fromPromise } from 'xstate';

export type MachineInput = { bossInput?: string };
export type PendingBossQuestion = {
  questionId: 'writeMessage'; resumeStateId: 'writeMessage'; sourceItem: 'flow-6';
  asker: { kind: 'role'; roleId: '提交说明作者' }; question: string;
};
export type PlayerInput = {
  stateId: 'writeMessage'; sourceItem: 'flow-6'; role: '提交说明作者';
  prompt: string; bossInput: string; result: Record<string, string>;
  pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
};
export type PlayerOutput =
  | { guard: 'generated'; message: string }
  | { guard: 'unable'; reason: string }
  | { guard: 'needsBossReply'; question: string };
export type MachineOutput = { message: string } | { reason: string };
type Events =
  | { type: 'START'; bossInput: string }
  | { type: 'BOSS_INTERRUPT'; targetId: 'ready' | 'writeMessage'; bossInput?: string }
  | { type: 'BOSS_REPLY'; answer: string; questionId?: string };
type Context = {
  bossInput: string;
  terminal?: MachineOutput;
  pendingBossQuestion?: PendingBossQuestion;
  bossReply?: string;
  lastError?: { name: string; message: string; stack?: string };
};
export const concurrentRoleSets = [] as const;
const prompt = "读取任务文件及其引用的改动和上下文，然后完成提交说明。\n生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n只生成文本，不暂存文件，不执行 git commit，不 amend。\n标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。\n成功生成时，返回内容为完整代码块的字符串；任务文件或引用的输入无法读取、或资料不足以生成说明时，说明具体限制。\n不得通过执行 Git 提交来代替输出说明。\n\n> <boss-input>";
const results = {
  generated: '成功生成提交说明。Output shall include `message: <完整代码块字符串>`。',
  unable: '任务文件或引用的输入无法读取、或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`。',
  needsBossReply: "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.",
};
function record(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
function output(event: unknown): PlayerOutput | undefined {
  if (!record(event) || !record(event.output)) return undefined;
  const value = event.output;
  if (value.guard === 'generated' && typeof value.message === 'string' && value.message.trim()) return { guard: 'generated', message: value.message };
  if (value.guard === 'unable' && typeof value.reason === 'string' && value.reason.trim()) return { guard: 'unable', reason: value.reason };
  if (value.guard === 'needsBossReply' && typeof value.question === 'string' && value.question.trim()) return { guard: 'needsBossReply', question: value.question };
  return undefined;
}
function normalizeError(event: unknown): { name: string; message: string; stack?: string } {
  const error = record(event) ? event.error : undefined;
  if (error instanceof Error) return { name: error.name, message: error.message, ...(error.stack ? { stack: error.stack } : {}) };
  return { name: 'Error', message: typeof error === 'string' ? error : 'Invalid actor result or Boss reply.' };
}
function bossInterrupts(ids: readonly ('ready' | 'writeMessage')[]) {
  return ids.map(id => ({
    target: '#' + id, reenter: true,
    guard: ({ context, event }: { context: Context; event: Events }) =>
      event.type === 'BOSS_INTERRUPT' && event.targetId === id &&
      (id === 'ready' || (typeof event.bossInput === 'string' ? !!event.bossInput.trim() : !!context.bossInput.trim())),
    actions: 'prepareInterrupt' as const,
  }));
}
function resumableStates(ids: readonly 'writeMessage'[]) {
  return ids.map(id => ({
    target: '#' + id,
    guard: ({ context, event }: { context: Context; event: Events }) =>
      event.type === 'BOSS_REPLY' && typeof event.answer === 'string' && !!event.answer.trim() &&
      context.pendingBossQuestion?.resumeStateId === id &&
      (event.questionId === undefined || event.questionId === context.pendingBossQuestion.questionId),
    actions: 'rememberReply' as const,
  }));
}
function clearBossReplyContext(context: Context): Partial<Context> {
  delete context.pendingBossQuestion;
  delete context.bossReply;
  return {};
}
export const machine = setup({
  types: { context: {} as Context, events: {} as Events, input: {} as MachineInput, output: {} as MachineOutput },
  actors: { player: fromPromise<PlayerOutput, PlayerInput>(async () => { throw new Error('player actor must be provided by the runner'); }) },
  actions: {
    'playbook.acceptedOutcome': (_args, _params: { source: string; target: string; acceptedOutcome: string }) => {},
    clearBossReplyContext: assign(({ context }) => clearBossReplyContext(context)),
    start: assign(({ context, event }) => {
      delete context.pendingBossQuestion; delete context.bossReply; delete context.lastError; delete context.terminal;
      return event.type === 'START' ? { bossInput: event.bossInput } : {};
    }),
    prepareInterrupt: assign(({ context, event }) => {
      delete context.pendingBossQuestion; delete context.bossReply; delete context.lastError; delete context.terminal;
      return event.type === 'BOSS_INTERRUPT' && typeof event.bossInput === 'string' ? { bossInput: event.bossInput } : {};
    }),
    rememberReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    setPendingBossQuestion: assign(({ context, event }) => {
      delete context.bossReply;
      const result = output(event);
      return result?.guard === 'needsBossReply' ? { pendingBossQuestion: {
        questionId: 'writeMessage' as const, resumeStateId: 'writeMessage' as const, sourceItem: 'flow-6' as const,
        asker: { kind: 'role' as const, roleId: '提交说明作者' as const }, question: result.question,
      } } : {};
    }),
    rememberTerminal: assign(({ event }) => {
      const result = output(event);
      return result?.guard === 'generated' ? { terminal: { message: result.message } } :
        result?.guard === 'unable' ? { terminal: { reason: result.reason } } : {};
    }),
    rememberError: assign(({ event }) => ({ lastError: normalizeError(event) })),
  },
  guards: {
    validEntry: ({ event }) => event.type === 'START' && typeof event.bossInput === 'string' && !!event.bossInput.trim(),
    generated: ({ event }) => output(event)?.guard === 'generated',
    unable: ({ event }) => output(event)?.guard === 'unable',
    needsBossReply: ({ event }) => output(event)?.guard === 'needsBossReply',
  },
}).createMachine({
  id: 'flow', initial: 'ready',
  context: ({ input }) => ({ bossInput: input?.bossInput ?? '' }),
  output: ({ context }) => {
    if (!context.terminal) throw new Error('No terminal result');
    return context.terminal;
  },
  on: { BOSS_INTERRUPT: bossInterrupts(['ready', 'writeMessage']) },
  states: {
    ready: {
      id: 'ready', description: '等待任务文件路径。', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'ready', description: '等待任务文件路径。' } },
      on: { START: { guard: 'validEntry', target: 'writeMessage', actions: 'start' } },
    },
    writeMessage: {
      id: 'writeMessage', description: '根据改动生成提交说明。', tags: ['playbook.busy'],
      meta: { playbook: { stateId: 'writeMessage', description: '根据改动生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({
          stateId: 'writeMessage', sourceItem: 'flow-6', role: '提交说明作者',
          prompt, result: results, bossInput: context.bossInput,
          ...(context.pendingBossQuestion ? { pendingBossQuestion: context.pendingBossQuestion } : {}),
          ...(context.bossReply !== undefined ? { bossReply: context.bossReply } : {}),
        }),
        onDone: [
          { guard: 'generated', target: 'generated', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'generated', acceptedOutcome: 'generated' } }, 'rememberTerminal', 'clearBossReplyContext'] },
          { guard: 'unable', target: 'unable', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'unable', acceptedOutcome: 'unable' } }, 'rememberTerminal', 'clearBossReplyContext'] },
          { guard: 'needsBossReply', target: 'awaitBossReply', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } }, 'setPendingBossQuestion'] },
          { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] },
        ],
        onError: { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question.", tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question." } },
      on: {
        START: { guard: 'validEntry', target: 'writeMessage', actions: 'start' },
        BOSS_REPLY: [...resumableStates(['writeMessage']), { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] }],
      },
    },
    failed: {
      id: 'failed', description: '执行异常，等待恢复。', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'failed', description: '执行异常，等待恢复。' } },
      on: { START: { guard: 'validEntry', target: 'writeMessage', actions: 'start' } },
    },
    generated: {
      id: 'generated', type: 'final', description: '已生成',
      meta: { playbook: { stateId: 'generated', description: '已生成', terminal: 'success' } },
    },
    unable: {
      id: 'unable', type: 'final', description: '无法生成',
      meta: { playbook: { stateId: 'unable', description: '无法生成', terminal: 'failure' } },
    },
  },
});
export default machine;

