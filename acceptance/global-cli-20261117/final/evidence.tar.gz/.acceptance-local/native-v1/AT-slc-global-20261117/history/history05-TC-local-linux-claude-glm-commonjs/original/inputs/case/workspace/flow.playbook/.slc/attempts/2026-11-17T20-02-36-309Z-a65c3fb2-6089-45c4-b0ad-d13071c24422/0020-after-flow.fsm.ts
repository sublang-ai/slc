// GEARS-to-FSM artifact for `flow` (根据改动生成提交说明), compiled from
// flow.gears.md item flow-5. The linked runtime provides the actor
// implementation and imports the exported boundary types below.

import { setup, fromPromise, assign } from 'xstate';

// ---------------------------------------------------------------------------
// Exported boundary types (the linked runtime provides the actor implementation
// and imports these exact types).
// ---------------------------------------------------------------------------

/**
 * Machine construction input. The Boss-supplied task file path and user input
 * are delivered through the Boss entry event; optional seeds may ride along at
 * construction. No agent call runs before the first Boss-originated event.
 */
export interface MachineInput {
    任务文件的绝对路径?: string;
    用户输入?: string;
}

/**
 * Terminal workflow output returned to the caller. Source declares two terminal
 * returns: the “已生成” ending hands `message` to the caller verbatim, and the
 * “无法生成” ending hands `reason` to the caller verbatim.
 */
export type MachineOutput =
    | { status: '已生成'; message: string }
    | { status: '无法生成'; reason: string };

/** Standard suspended-question record carried while awaiting a Boss reply. */
export interface PendingBossQuestion {
    questionId: string;
    resumeStateId: string;
    sourceItem: string;
    asker: { kind: 'captain' } | { kind: 'role'; roleId: string };
    question: string;
}

/** Typed input for the delegated `player` (提交说明作者) actor. */
export interface PlayerInput {
    stateId: string;
    role: '提交说明作者';
    sourceItem: string;
    prompt: string;
    任务文件的绝对路径: string;
    用户输入: string;
    pendingBossQuestion?: PendingBossQuestion;
    bossReply?: string;
    result: Record<'message' | 'reason' | 'needsBossReply', string>;
}

/** Discriminated result contract the 提交说明作者 actor returns. */
export type PlayerOutput =
    | { guard: 'message'; message: string }
    | { guard: 'reason'; reason: string }
    | { guard: 'needsBossReply'; question: string };

// ---------------------------------------------------------------------------
// Internal machine types.
// ---------------------------------------------------------------------------

interface LastError {
    name: string;
    message: string;
    stack?: string;
}

interface FlowContext {
    任务文件的绝对路径: string;
    用户输入: string;
    message: string;
    reason: string;
    status: '已生成' | '无法生成' | null;
    lastError: LastError | null;
    pendingBossQuestion: PendingBossQuestion | null;
    bossReply: string | null;
}

type FlowEvent =
    | { type: 'START'; 任务文件的绝对路径: string; 用户输入: string }
    | { type: 'BOSS_REPLY'; answer: string; questionId?: string };

interface AcceptedOutcomeParams {
    source: string;
    target: string;
    acceptedOutcome: string;
}

// ---------------------------------------------------------------------------
// Source-derived constants.
// ---------------------------------------------------------------------------

// flow-5 full final prompt, verbatim from the GEARS blockquote. The literal
// leading `>` on the quoted-context lines is prompt content and is preserved;
// `<任务文件的绝对路径>` and `<用户输入>` are runtime-value placeholders backed
// by the identically named typed actor-input fields.
const FLOW_5_PROMPT = [
    '读取用户提供的改动及项目约定，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。',
    '只生成文本，不暂存文件，不执行 git commit，不 amend。',
    '读取任务文件及其引用的改动和上下文，然后完成提交说明。',
    '必须保留以下全部规则：',
    '- 标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。',
    '- type 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。',
    '- 标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。',
    '- 标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。',
    '- 正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。',
    '- 不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。',
    '- 表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。',
    '- 输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。',
    '> <任务文件的绝对路径>',
    '> <用户输入>',
].join('\n');

// flow-5 local result contract, guard names and descriptions preserved verbatim
// in declared order, with the universal needsBossReply appended.
const FLOW_5_RESULT: Record<'message' | 'reason' | 'needsBossReply', string> = {
    message: '成功生成提交说明。Output shall include `message: <完整代码块>`。',
    reason: '任务文件或引用的输入无法读取，或资料不足以生成提交说明。Output shall include `reason: <具体限制>`。',
    needsBossReply:
        "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.",
};

// Role-id arrays per parallel group; this machine has no parallel group.
export const concurrentRoleSets = [] as const;

// ---------------------------------------------------------------------------
// Structural narrowing helpers (accept unknown event output and narrow to the
// declared contract before reading fields).
// ---------------------------------------------------------------------------

function playerOutputOf(event: unknown): PlayerOutput | null {
    if (typeof event !== 'object' || event === null) return null;
    const output = (event as { output?: unknown }).output;
    if (typeof output !== 'object' || output === null) return null;
    const guard = (output as { guard?: unknown }).guard;
    if (guard === 'message') {
        const message = (output as { message?: unknown }).message;
        if (typeof message === 'string' && message.trim().length > 0) {
            return { guard: 'message', message };
        }
        return null;
    }
    if (guard === 'reason') {
        const reason = (output as { reason?: unknown }).reason;
        if (typeof reason === 'string' && reason.trim().length > 0) {
            return { guard: 'reason', reason };
        }
        return null;
    }
    if (guard === 'needsBossReply') {
        const question = (output as { question?: unknown }).question;
        if (typeof question === 'string') return { guard: 'needsBossReply', question };
        return null;
    }
    return null;
}

function messageOf(event: unknown): string {
    const output = playerOutputOf(event);
    return output && output.guard === 'message' ? output.message : '';
}

function reasonOf(event: unknown): string {
    const output = playerOutputOf(event);
    return output && output.guard === 'reason' ? output.reason : '';
}

function normalizeError(error: unknown): LastError {
    if (error instanceof Error) {
        return error.stack !== undefined
            ? { name: error.name, message: error.message, stack: error.stack }
            : { name: error.name, message: error.message };
    }
    return { name: 'Error', message: typeof error === 'string' ? error : 'Unknown error' };
}

function nonEmptyString(value: unknown): boolean {
    return typeof value === 'string' && value.trim().length > 0;
}

// ---------------------------------------------------------------------------
// Machine.
// ---------------------------------------------------------------------------

export const flowMachine = setup({
    types: {
        context: {} as FlowContext,
        events: {} as FlowEvent,
        input: {} as MachineInput,
        output: {} as MachineOutput,
    },
    actors: {
        // Delegated 提交说明作者 work; the runner supplies the implementation.
        player: fromPromise<PlayerOutput, PlayerInput>(async () => {
            throw new Error('player actor must be provided by the runner');
        }),
    },
    actions: {
        // No-op accepted-outcome marker; the linked runtime consumes these
        // three string params to publish the accepted-outcome trace.
        'playbook.acceptedOutcome': (_args: unknown, _params: AcceptedOutcomeParams) => {},
        applyEntry: assign({
            任务文件的绝对路径: ({ event }) => {
                const value = (event as { 任务文件的绝对路径?: unknown }).任务文件的绝对路径;
                return typeof value === 'string' ? value : '';
            },
            用户输入: ({ context, event }) => {
                const value = (event as { 用户输入?: unknown }).用户输入;
                return typeof value === 'string' ? value : context.用户输入;
            },
            message: () => '',
            reason: () => '',
            status: () => null,
            lastError: () => null,
            pendingBossQuestion: () => null,
            bossReply: () => null,
        }),
        recordMessage: assign({
            message: ({ event }) => messageOf(event),
            status: () => '已生成' as const,
        }),
        recordReason: assign({
            reason: ({ event }) => reasonOf(event),
            status: () => '无法生成' as const,
        }),
        setPendingBossQuestion: assign({
            pendingBossQuestion: ({ event }): PendingBossQuestion => {
                const output = playerOutputOf(event);
                const question = output && output.guard === 'needsBossReply' ? output.question : '';
                return {
                    questionId: 'generateMessage',
                    resumeStateId: 'generateMessage',
                    sourceItem: 'flow-5',
                    asker: { kind: 'role' as const, roleId: '提交说明作者' },
                    question,
                };
            },
        }),
        storeBossReply: assign({
            bossReply: ({ event }) => {
                const answer = (event as { answer?: unknown }).answer;
                return typeof answer === 'string' ? answer : '';
            },
        }),
        clearBossReplyContext: assign({
            pendingBossQuestion: () => null,
            bossReply: () => null,
        }),
        rememberError: assign({
            lastError: ({ event }) => normalizeError((event as { error?: unknown }).error),
        }),
        rememberMalformedOutput: assign({
            lastError: () => ({
                name: 'MalformedActorOutput',
                message: '提交说明作者返回了无法识别的结果。',
            }),
        }),
        rememberEmptyReply: assign({
            lastError: () => ({
                name: 'InvalidBossReply',
                message: 'BOSS_REPLY carried an empty or whitespace-only answer.',
            }),
        }),
    },
    guards: {
        hasEntryValues: ({ event }) =>
            nonEmptyString((event as { 任务文件的绝对路径?: unknown }).任务文件的绝对路径) &&
            nonEmptyString((event as { 用户输入?: unknown }).用户输入),
        hasBossReply: ({ event }) => nonEmptyString((event as { answer?: unknown }).answer),
        playerMessage: ({ event }) => playerOutputOf(event)?.guard === 'message',
        playerReason: ({ event }) => playerOutputOf(event)?.guard === 'reason',
        playerNeedsBossReply: ({ event }) => playerOutputOf(event)?.guard === 'needsBossReply',
    },
}).createMachine({
    id: 'flow',
    description:
        '根据用户提供的改动及项目约定生成简洁、准确的 Conventional Commits 提交说明，只生成文本，不操作 Git 提交。',
    initial: 'ready',
    context: ({ input }) => ({
        任务文件的绝对路径: input.任务文件的绝对路径 ?? '',
        用户输入: input.用户输入 ?? '',
        message: '',
        reason: '',
        status: null,
        lastError: null,
        pendingBossQuestion: null,
        bossReply: null,
    }),
    output: ({ context }): MachineOutput =>
        context.status === '已生成'
            ? { status: '已生成', message: context.message }
            : { status: '无法生成', reason: context.reason },
    states: {
        ready: {
            id: 'ready',
            description: '等待 Boss 以普通文本提供任务文件绝对路径的空闲枢纽。',
            tags: ['playbook.parked'],
            meta: {
                playbook: {
                    stateId: 'ready',
                    description: '等待 Boss 以普通文本提供任务文件绝对路径的空闲枢纽。',
                },
            },
            on: {
                START: {
                    guard: 'hasEntryValues',
                    target: 'generateMessage',
                    actions: 'applyEntry',
                },
            },
        },
        generateMessage: {
            id: 'generateMessage',
            description:
                '提交说明作者读取任务文件及其引用的改动和上下文，完成提交说明。',
            tags: ['playbook.busy'],
            meta: {
                playbook: {
                    stateId: 'generateMessage',
                    description:
                        '提交说明作者读取任务文件及其引用的改动和上下文，完成提交说明。',
                    role: '提交说明作者',
                },
            },
            invoke: {
                src: 'player',
                input: ({ context }): PlayerInput => ({
                    stateId: 'generateMessage',
                    role: '提交说明作者',
                    sourceItem: 'flow-5',
                    prompt: FLOW_5_PROMPT,
                    任务文件的绝对路径: context.任务文件的绝对路径,
                    用户输入: context.用户输入,
                    ...(context.pendingBossQuestion
                        ? { pendingBossQuestion: context.pendingBossQuestion }
                        : {}),
                    ...(context.bossReply ? { bossReply: context.bossReply } : {}),
                    result: FLOW_5_RESULT,
                }),
                onDone: [
                    {
                        guard: 'playerMessage',
                        target: 'generated',
                        actions: [
                            {
                                type: 'playbook.acceptedOutcome',
                                params: {
                                    source: 'generateMessage',
                                    target: 'generated',
                                    acceptedOutcome: 'message',
                                },
                            },
                            'recordMessage',
                            'clearBossReplyContext',
                        ],
                    },
                    {
                        guard: 'playerReason',
                        target: 'cannotGenerate',
                        actions: [
                            {
                                type: 'playbook.acceptedOutcome',
                                params: {
                                    source: 'generateMessage',
                                    target: 'cannotGenerate',
                                    acceptedOutcome: 'reason',
                                },
                            },
                            'recordReason',
                            'clearBossReplyContext',
                        ],
                    },
                    {
                        guard: 'playerNeedsBossReply',
                        target: 'awaitBossReply',
                        actions: [
                            {
                                type: 'playbook.acceptedOutcome',
                                params: {
                                    source: 'generateMessage',
                                    target: 'awaitBossReply',
                                    acceptedOutcome: 'needsBossReply',
                                },
                            },
                            'setPendingBossQuestion',
                        ],
                    },
                    {
                        target: 'failed',
                        actions: ['rememberMalformedOutput', 'clearBossReplyContext'],
                    },
                ],
                onError: {
                    target: 'failed',
                    actions: ['rememberError', 'clearBossReplyContext'],
                },
            },
        },
        awaitBossReply: {
            id: 'awaitBossReply',
            description: "Waiting for Boss to answer the acting agent's question.",
            tags: ['playbook.parked'],
            meta: {
                playbook: {
                    stateId: 'awaitBossReply',
                    description: "Waiting for Boss to answer the acting agent's question.",
                },
            },
            on: {
                BOSS_REPLY: [
                    {
                        guard: 'hasBossReply',
                        target: '#generateMessage',
                        reenter: true,
                        actions: 'storeBossReply',
                    },
                    {
                        target: '#failed',
                        actions: ['rememberEmptyReply', 'clearBossReplyContext'],
                    },
                ],
            },
        },
        generated: {
            id: 'generated',
            type: 'final',
            description: '流程以“已生成”结束，message 已原样交给调用者。',
            meta: {
                playbook: {
                    stateId: 'generated',
                    description: '流程以“已生成”结束，message 已原样交给调用者。',
                    terminal: 'success',
                },
            },
        },
        cannotGenerate: {
            id: 'cannotGenerate',
            type: 'final',
            description: '流程以“无法生成”结束，reason 已原样交给调用者。',
            meta: {
                playbook: {
                    stateId: 'cannotGenerate',
                    description: '流程以“无法生成”结束，reason 已原样交给调用者。',
                    terminal: 'failure',
                },
            },
        },
        failed: {
            id: 'failed',
            description: '控制错误或畸形结果中断了流程，等待 Boss 恢复。',
            tags: ['playbook.parked'],
            meta: {
                playbook: {
                    stateId: 'failed',
                    description: '控制错误或畸形结果中断了流程，等待 Boss 恢复。',
                },
            },
            on: {
                START: {
                    guard: 'hasEntryValues',
                    target: 'generateMessage',
                    actions: 'applyEntry',
                },
            },
        },
    },
});
