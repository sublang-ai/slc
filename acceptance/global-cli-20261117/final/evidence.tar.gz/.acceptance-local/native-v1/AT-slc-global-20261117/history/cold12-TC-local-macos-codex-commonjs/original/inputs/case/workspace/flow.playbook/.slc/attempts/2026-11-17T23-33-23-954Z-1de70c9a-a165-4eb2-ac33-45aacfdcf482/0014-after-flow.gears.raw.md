# flow: 根据改动生成提交说明

## 意图

在用户要求“写提交说明”“commit message”“/commit”或“/caveman-commit”时，根据用户提供的改动及项目约定，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。
流程在成功生成说明或报告无法生成的具体限制时结束。

Roles:
- 提交说明作者

## 外部行为

### flow-1

Boss 应用普通文本提供任务文件的绝对路径，作为生成提交说明动作 [[flow-5](#flow-5)] 的输入。

### flow-2

当提交说明作者成功生成说明 [[flow-5](#flow-5)] 时，`flow` 应以“已生成”结束，将 `message` 字符串原样交给调用者，内容为完整代码块。

### flow-3

当提交说明作者因任务文件或引用的输入无法读取、或资料不足而无法生成说明 [[flow-5](#flow-5)] 时，`flow` 应以“无法生成”结束，将说明具体限制的 `reason` 字符串原样交给调用者。

### flow-4

`flow` 应在生成提交说明 [[flow-5](#flow-5)] 的全过程只生成文本，不暂存文件，不执行 git commit，不 amend，不得通过执行 Git 提交来代替输出说明。

## 内部行为

### flow-5

当 Boss 提供生成提交说明的任务文件路径 [[flow-1](#flow-1)] 时，Captain shall prompt 提交说明作者:

> 读取任务文件及其引用的改动和上下文，遵循项目约定，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。
> 标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。
> type 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。
> 标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。
> 标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。
> 正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。
> 不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。
> 表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。
> 输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。
> 只生成文本，不暂存文件，不执行 git commit，不 amend，不得通过执行 Git 提交来代替输出说明。
> 成功生成时，返回完整代码块；任务文件或引用的输入无法读取、或资料不足以生成说明时，说明具体限制。
> > <boss-input>

Results:
- `generated`: 成功生成提交说明。Output shall include `message: <完整代码块字符串>`。
- `unable`: 任务文件或引用的输入无法读取、或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`。

### flow-6

`flow` 应只有生成提交说明这一个工作动作 [[flow-5](#flow-5)]，不增加额外审查或修改代码的阶段。

## 验证

### flow-7

如果 Boss 已用普通文本提供任务文件的绝对路径 [[flow-1](#flow-1)]，当生成提交说明的请求开始时，运行应展示以下成功与失败用例矩阵：

- 成功生成：提交说明作者收到提示 [[flow-5](#flow-5)]；流程以“已生成”结束，将包含完整代码块的 `message` 字符串原样交给调用者 [[flow-2](#flow-2)]。
- 任务文件无法读取：提交说明作者收到提示 [[flow-5](#flow-5)]；流程以“无法生成”结束，将说明具体限制的 `reason` 字符串原样交给调用者 [[flow-3](#flow-3)]。
- 引用的输入无法读取：提交说明作者收到提示 [[flow-5](#flow-5)]；流程以“无法生成”结束，将说明具体限制的 `reason` 字符串原样交给调用者 [[flow-3](#flow-3)]。
- 资料不足以生成说明：提交说明作者收到提示 [[flow-5](#flow-5)]；流程以“无法生成”结束，将说明具体限制的 `reason` 字符串原样交给调用者 [[flow-3](#flow-3)]。
- 全部用例：流程只生成文本，不暂存文件，不执行 git commit，不 amend，不通过执行 Git 提交代替输出说明 [[flow-4](#flow-4)]，且只有一个工作动作，不增加额外审查或修改代码的阶段 [[flow-6](#flow-6)]。
