# flow: 根据改动生成提交说明

## 意图

在用户要求“写提交说明”“commit message”“/commit”或“/caveman-commit”时，读取用户提供的改动及项目约定，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。
流程在生成说明或说明无法生成的具体限制后结束。

Roles:
- 提交说明作者

## 外部行为

### flow-1

Boss 应用普通文本提供任务文件的绝对路径。

### flow-2

当提交说明作者成功生成说明 [[flow-6](#flow-6)] 时，`flow` 应以“已生成”结束，将 `message` 字符串原样交给调用者，内容为完整代码块。

### flow-3

当任务文件或引用的输入无法读取、或资料不足以生成说明 [[flow-6](#flow-6)] 时，`flow` 应以“无法生成”结束，将说明具体限制的 `reason` 字符串原样交给调用者。

### flow-4

`flow` 应只生成文本，不暂存文件，不执行 git commit，不 amend，不得通过执行 Git 提交来代替输出说明 [[flow-6](#flow-6)]。

### flow-5

当用户输入 stop caveman-commit 或 normal mode 时，`flow` 应在本次采用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交 [[flow-4](#flow-4)] [[flow-6](#flow-6)]。

## 内部行为

### flow-6

当 Boss 提供任务文件的绝对路径 [[flow-1](#flow-1)] 时，Captain shall prompt 提交说明作者:

> 读取 Boss 用普通文本提供的任务文件绝对路径所指的任务文件及其引用的改动和上下文，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。
> 只生成文本，不暂存文件，不执行 git commit，不 amend；不得通过执行 Git 提交来代替输出说明。
> 标题依次包含 type、可省略的括号 scope、冒号及空格、imperative summary；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。
> type 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。
> 标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。
> 标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。
> 正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。
> 不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。
> 表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。
> 输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。
> 成功生成时返回完整代码块；任务文件或引用的输入无法读取、或资料不足以生成说明时，说明具体限制。
> > <boss-input>

Results:
- `generated`: 已成功生成提交说明。Output shall include `message: <完整代码块字符串>`。
- `unavailable`: 任务文件或引用的输入无法读取，或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`。

### flow-7

`flow` 应只有一个工作动作 [[flow-6](#flow-6)]，不增加额外审查或修改代码的阶段。

### flow-8

提交说明作者应在生成说明 [[flow-6](#flow-6)] 时使标题使用 <type>(<scope>): <imperative summary>，scope 可省略，破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。

### flow-9

提交说明作者应在生成说明 [[flow-6](#flow-6)] 时使 type 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert，使用 add、fix、remove 等祈使表达，不用 added、adds、adding，冒号后大小写遵循项目约定。

### flow-10

提交说明作者应在生成说明 [[flow-6](#flow-6)] 时使标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。

### flow-11

提交说明作者应在生成说明 [[flow-6](#flow-6)] 时遵循正文取舍规则：

- 标题已经清楚时省略正文。
- 非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。
- 破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。

### flow-12

提交说明作者应在生成说明 [[flow-6](#flow-6)] 时使正文按 72 个字符折行，列表符号用 -，关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。

### flow-13

提交说明作者应在生成说明 [[flow-6](#flow-6)] 时遵循表达限制：

- 不写 This commit does X、I、we、now、currently 等赘述。
- 不写 As requested by，适用时用 Co-authored-by trailer。
- 不加 AI 归因，除非用户自己的规则要求对应 trailer。
- 不用 emoji，除非项目约定要求。
- scope 已说明文件时不再重复文件名。

### flow-14

提交说明作者应在生成说明 [[flow-6](#flow-6)] 时表达为什么需要这个改动，避免机械复述差异，没有证据的信息不编造。

## 验证

### flow-15

给定任务文件及引用的改动和上下文可读取且资料充足，当 Boss 用普通文本提供任务文件绝对路径 [[flow-1](#flow-1)] 时，运行应展示成功生成说明的用例矩阵：

- 所有用例：提交说明作者收到完整提示 [[flow-6](#flow-6)]；只有一个工作动作，无额外审查或修改代码阶段 [[flow-7](#flow-7)]；只生成文本，不暂存、不 commit、不 amend [[flow-4](#flow-4)]；以“已生成”结束，完整代码块字符串 message 原样交给调用者 [[flow-2](#flow-2)]。
- 普通改动：标题格式、type、祈使表达及冒号后大小写遵循规定 [[flow-8](#flow-8)] [[flow-9](#flow-9)]，标题长度和结尾符合规定 [[flow-10](#flow-10)]，标题清楚时省略正文 [[flow-11](#flow-11)]。
- 有非显而易见的原因、迁移说明或关联 Issue 的改动：正文取舍符合规定 [[flow-11](#flow-11)]，正文折行、列表符号及 Issue 或 PR 位置符合规定 [[flow-12](#flow-12)]。
- 破坏性变更、安全修复、数据迁移或撤销旧提交：始终有正文 [[flow-11](#flow-11)]，破坏性变更使用 ! 并写明 BREAKING CHANGE [[flow-8](#flow-8)]。
- 各项目约定及用户 trailer 规则：表达限制和相应例外得到遵守 [[flow-13](#flow-13)]，说明表达改动原因且不编造无证据信息 [[flow-14](#flow-14)]。

### flow-16

给定任务文件无法读取、引用的输入无法读取或资料不足以生成说明，当 Boss 提供任务文件绝对路径 [[flow-1](#flow-1)] 时，运行应展示提交说明作者收到提示 [[flow-6](#flow-6)] 后以“无法生成”结束，将说明具体限制的 reason 字符串原样交给调用者 [[flow-3](#flow-3)]，且不以执行 Git 提交代替输出 [[flow-4](#flow-4)]。

### flow-17

给定本次任务资料足以生成说明，当用户输入 stop caveman-commit 或 normal mode 时，运行应展示提交说明作者收到提示 [[flow-6](#flow-6)]，本次采用正常详细提交说明风格且只生成文本、不操作 Git 提交 [[flow-5](#flow-5)]，成功后将完整代码块字符串 message 原样交给调用者并以“已生成”结束 [[flow-2](#flow-2)]。
