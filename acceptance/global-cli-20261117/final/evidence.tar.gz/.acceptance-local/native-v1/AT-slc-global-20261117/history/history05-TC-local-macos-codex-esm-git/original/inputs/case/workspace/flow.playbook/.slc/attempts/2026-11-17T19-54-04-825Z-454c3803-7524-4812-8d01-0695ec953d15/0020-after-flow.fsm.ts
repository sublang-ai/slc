import { setup, assign, fromPromise } from 'xstate';

export type MachineInput = { bossInput?: string };
export type MachineOutput = { message: string } | { reason: string };
export type PendingBossQuestion = {
  questionId: 'writeMessage'; resumeStateId: 'writeMessage'; sourceItem: 'flow-6';
  asker: { kind: 'role'; roleId: '提交说明作者' }; question: string;
};
export type PlayerInput = {
  stateId: 'writeMessage'; role: '提交说明作者'; sourceItem: 'flow-6';
  prompt: string; bossInput: string; result: Record<string, string>;
  pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
};
export type PlayerOutput =
  | { guard: 'generated'; message: string }
  | { guard: 'unavailable'; reason: string }
  | { guard: 'needsBossReply'; question: string };
type Context = {
  bossInput: string; pendingBossQuestion?: PendingBossQuestion | null; bossReply?: string | null;
  terminalOutput?: MachineOutput; lastError?: { name: string; message: string; stack?: string };
};
type Events =
  | { type: 'START'; bossInput: string }
  | { type: 'BOSS_INTERRUPT'; targetId: 'ready' | 'writeMessage' | 'failed'; bossInput?: string }
  | { type: 'BOSS_REPLY'; answer: string; questionId?: string };
export const concurrentRoleSets = [] as const;
const prompt = "读取 Boss 用普通文本提供的任务文件绝对路径所指向的任务文件及其引用的改动和上下文，然后完成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。\n只生成文本，不暂存文件，不执行 git commit，不 amend，不得通过执行 Git 提交来代替输出说明。\n任务文件或引用的输入无法读取、或资料不足以生成说明时，说明具体限制。\n> <boss-input>";
const result = {
  generated: '已成功生成提交说明。Output shall include `message: <完整代码块字符串>`。',
  unavailable: '任务文件或引用的输入无法读取、或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`。',
  needsBossReply: "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.",
};
function record(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
function output(event: unknown): Record<string, unknown> {
  return record(event) && record(event.output) ? event.output : {};
}
function errorValue(event: unknown): unknown { return record(event) ? event.error : undefined; }
function nonempty(value: unknown): value is string { return typeof value === 'string' && value.trim().length > 0; }
function clearBossReplyContext(context: Context): Context {
  const { pendingBossQuestion, bossReply, ...rest } = context;
  void pendingBossQuestion; void bossReply;
  return { ...rest, pendingBossQuestion: null, bossReply: null };
}
function bossInterrupts(ids: readonly ('ready' | 'writeMessage' | 'failed')[]) {
  return ids.map(id => ({
    target: '#' + id, reenter: true,
    guard: ({ context, event }: { context: Context; event: Events }) =>
      event.type === 'BOSS_INTERRUPT' && event.targetId === id &&
      (id !== 'writeMessage' || nonempty(event.bossInput ?? context.bossInput)),
    actions: ['clearBossReplyContext', 'interrupt'] as const,
  }));
}
function resumableStates(ids: readonly ['writeMessage']) {
  return ids.map(id => ({
    target: '#' + id,
    guard: ({ context, event }: { context: Context; event: Events }) =>
      event.type === 'BOSS_REPLY' && nonempty(event.answer) &&
      context.pendingBossQuestion?.resumeStateId === id &&
      (event.questionId === undefined || event.questionId === context.pendingBossQuestion.questionId),
    actions: 'rememberReply' as const,
  }));
}
const waitDescription = "Waiting for Boss to answer the acting agent's question.";
export const machine = setup({
  types: {} as { context: Context; events: Events; input: MachineInput; output: MachineOutput },
  actors: {
    player: fromPromise<PlayerOutput, PlayerInput>(async () => { throw new Error('player actor must be provided by the runner'); }),
  },
  actions: {
    'playbook.acceptedOutcome': (_args, _params: { source: string; target: string; acceptedOutcome: string }) => {},
    start: assign(({ event }) => ({ bossInput: event.type === 'START' ? event.bossInput : '' })),
    interrupt: assign(({ context, event }) => ({ bossInput: event.type === 'BOSS_INTERRUPT' ? event.bossInput ?? context.bossInput : context.bossInput })),
    clearBossReplyContext: assign(({ context }) => clearBossReplyContext(context)),
    rememberReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    setPendingBossQuestion: assign(({ context, event }) => ({
      ...clearBossReplyContext(context),
      pendingBossQuestion: {
        questionId: 'writeMessage' as const, resumeStateId: 'writeMessage' as const, sourceItem: 'flow-6' as const,
        asker: { kind: 'role' as const, roleId: '提交说明作者' as const }, question: output(event).question as string,
      },
    })),
    generated: assign(({ event }) => ({ terminalOutput: { message: output(event).message as string } })),
    unavailable: assign(({ event }) => ({ terminalOutput: { reason: output(event).reason as string } })),
    rememberError: assign(({ event }) => {
      const error = errorValue(event);
      return { lastError: error instanceof Error ? { name: error.name, message: error.message, ...(error.stack === undefined ? {} : { stack: error.stack }) } : { name: 'Error', message: String(error ?? 'Malformed actor output or Boss reply') } };
    }),
  },
}).createMachine({
  id: 'flow', initial: 'ready',
  context: ({ input }) => ({ bossInput: input?.bossInput ?? '' }),
  output: ({ context }) => {
    if (!context.terminalOutput) throw new Error('Missing terminal output');
    return context.terminalOutput;
  },
  on: { BOSS_INTERRUPT: bossInterrupts(['ready', 'writeMessage', 'failed']) },
  states: {
    ready: {
      id: 'ready', description: '等待任务文件路径。', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'ready', description: '等待任务文件路径。' } },
      on: { START: { guard: ({ event }) => nonempty(event.bossInput), target: 'writeMessage', actions: ['clearBossReplyContext', 'start'] } },
    },
    writeMessage: {
      id: 'writeMessage', description: '生成提交说明。', tags: ['playbook.busy'],
      meta: { playbook: { stateId: 'writeMessage', description: '生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({
          stateId: 'writeMessage', role: '提交说明作者', sourceItem: 'flow-6', prompt, result, bossInput: context.bossInput,
          ...(context.pendingBossQuestion ? { pendingBossQuestion: context.pendingBossQuestion } : {}),
          ...(typeof context.bossReply === 'string' ? { bossReply: context.bossReply } : {}),
        }),
        onDone: [
          { guard: ({ event }) => output(event).guard === 'generated' && nonempty(output(event).message), target: 'done', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'done', acceptedOutcome: 'generated' } }, 'generated', 'clearBossReplyContext'] },
          { guard: ({ event }) => output(event).guard === 'unavailable' && nonempty(output(event).reason), target: 'unable', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'unable', acceptedOutcome: 'unavailable' } }, 'unavailable', 'clearBossReplyContext'] },
          { guard: ({ event }) => output(event).guard === 'needsBossReply' && nonempty(output(event).question), target: 'awaitBossReply', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'writeMessage', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } }, 'setPendingBossQuestion'] },
          { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] },
        ],
        onError: { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply', description: waitDescription, tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'awaitBossReply', description: waitDescription } },
      on: {
        BOSS_REPLY: [...resumableStates(['writeMessage']), { target: 'failed', actions: ['rememberError', 'clearBossReplyContext'] }],
        START: { guard: ({ event }) => nonempty(event.bossInput), target: 'writeMessage', actions: ['clearBossReplyContext', 'start'] },
      },
    },
    failed: {
      id: 'failed', description: '执行错误，等待恢复。', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'failed', description: '执行错误，等待恢复。' } },
      on: { START: { guard: ({ event }) => nonempty(event.bossInput), target: 'writeMessage', actions: ['clearBossReplyContext', 'start'] } },
    },
    done: {
      id: 'done', type: 'final', description: '已生成',
      meta: { playbook: { stateId: 'done', description: '已生成', terminal: 'success' } },
    },
    unable: {
      id: 'unable', type: 'final', description: '无法生成',
      meta: { playbook: { stateId: 'unable', description: '无法生成', terminal: 'failure' } },
    },
  },
});
export default machine;
