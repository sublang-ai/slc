<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- SPDX-FileCopyrightText: 2026 Boboyang -->
# flow: 根据改动生成提交说明

## 意图

在用户要求“写提交说明”“commit message”“/commit”或“/caveman-commit”时，本工作流读取用户提供的改动及项目约定，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。
流程以“已生成”或“无法生成”结束。

Roles:
- 提交说明作者

## 外部行为

### flow-1

当用户要求“写提交说明”“commit message”“/commit”或“/caveman-commit”，Boss 应以普通文本提供任务文件的绝对路径。

### flow-2

当 `提交说明作者` 成功生成提交说明 [[flow-5](#flow-5)]，`flow` 应以“已生成”结束，将 message 字符串原样交给调用者，内容为完整代码块。

### flow-3

当任务文件或引用的输入无法读取、或资料不足以生成提交说明 [[flow-5](#flow-5)]，`flow` 应以“无法生成”结束，将 reason 字符串原样交给调用者，说明具体限制。

### flow-4

`flow` 应只生成文本，不暂存文件，不执行 git commit，不 amend，不得通过执行 Git 提交来代替输出说明 [[flow-5](#flow-5)]。

## 内部行为

### flow-5

当 Boss 用普通文本提供任务文件的绝对路径，Captain shall prompt 提交说明作者:

> 读取任务文件及其引用的改动和上下文，完成提交说明。
> 标题使用 \<type\>(\<scope\>): \<imperative summary\>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。
> type 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。
> 标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。
> 标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。
> 正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。
> 不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。
> 表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。
> 输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。
> > <任务文件绝对路径>

Results:
- `generated`: 成功生成提交说明。Output shall include `message: <完整代码块>`。
- `cannotGenerate`: 任务文件或引用的输入无法读取，或资料不足以生成提交说明。Output shall include `reason: <具体限制>`。

### flow-6

`flow` 应只有一个工作动作 [[flow-5](#flow-5)]，不增加额外审查或修改代码的阶段。

## 验证

### flow-7

给定 Boss 已用普通文本提供任务文件的绝对路径 [[flow-1](#flow-1)]，当 `提交说明作者` 被提示完成提交说明 [[flow-5](#flow-5)] 并成功生成，`flow` 应以“已生成”结束，将 message 字符串原样交给调用者 [[flow-2](#flow-2)]，且全程只生成文本，不暂存文件，不执行 git commit，不 amend [[flow-4](#flow-4)]，不增加额外审查或修改代码的阶段 [[flow-6](#flow-6)]。

### flow-8

给定 Boss 已用普通文本提供任务文件的绝对路径 [[flow-1](#flow-1)]，当 `提交说明作者` 被提示完成提交说明 [[flow-5](#flow-5)] 后任务文件或引用的输入无法读取、或资料不足以生成提交说明，`flow` 应以“无法生成”结束，将说明具体限制的 reason 字符串原样交给调用者 [[flow-3](#flow-3)]。
