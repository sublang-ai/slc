// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: 2026 Boboyang
// Hand-linked under the complete slc/link.md (ordinary linking): the FSM's sole
// runtime-value placeholder token <任务文件的绝对路径> is outside the shared
// engine's ASCII placeholder grammar, so no materialize-link.mjs profile
// composes this playbook's standalone quoted relay; this module supplies the
// per-playbook quoted-relay composer override and shares every other strategy.
// FSM: "./flow.fsm.ts"; export: flowMachine; strategies: shared defaults with a CJK-token standalone quoted-relay composer.

import { flowMachine as machine } from "./flow.fsm.ts";
import {
  createXStatePlaybookRuntime, snapshotJsonValue,
  defaultComposePlayerPrompt,
  type PlaybookPlayerInput,
  type XStatePlaybookRuntimeConstruction,
  type XStatePlaybookRuntimeFactory,
  type XStatePlaybookRuntimeSpecV3,
} from '@sublang/playbook/xstate-runtime';
export type {
  PlayerResult,
  PlayerCallOptions,
  PlayerSessionStore,
  CaptainResult,
  CaptainCallOptions,
  JsonValue,
  NormalizedError,
  PlaybookCallRequest,
  PlaybookCallResult,
  PlaybookCallStart,
  PlaybookStateValue,
  PlaybookState,
  PlaybookPendingCall,
  PlaybookRunResult,
  PlaybookRuntime,
  PlaybookRuntimeFactory,
  PlaybookRuntimeSnapshot,
  PlaybookSession,
  PlaybookPorts,
  PlaybookTraceEvent,
  PlaybookTraceType,
  PlaybookControlReceipt,
  PlaybookControlView,
} from '@sublang/playbook/runtime';

export interface PlaybookRuntimeOptions {}
export type PlaybookHostCapabilities = XStatePlaybookRuntimeConstruction<
  PlaybookRuntimeOptions, { readonly authority: object }
>['hostCapabilities'];

const OPTION_SCHEMA = {} as const;
const INPUT_MAPPING = {} as const;
const RESUMABLE_STATE_IDS: ReadonlySet<string> = new Set([
  "composing"
]);
const UNFINISHED_FINAL_STATE_IDS: ReadonlySet<string> = new Set([
  "cannotGenerate"
]);
const VERBATIM_PAYLOAD_FIELDS: ReadonlySet<string> = new Set([]);
export function validateOptions(value: unknown): PlaybookRuntimeOptions {
  const captured = snapshotJsonValue(value === undefined ? {} : value, "FLOW runtime options");
  if (captured === null || typeof captured !== 'object' || Array.isArray(captured)) {
    throw new TypeError("FLOW runtime options must be an object");
  }
  const fields = captured as Readonly<Record<string, unknown>>;
  for (const key of Object.keys(captured)) {
    if (!Object.hasOwn(OPTION_SCHEMA, key)) throw new TypeError("FLOW runtime options." + key + ' is not declared');
  }
  for (const [key, schema] of Object.entries(OPTION_SCHEMA) as [string, { type: string; required: boolean }][]) {
    if (!Object.hasOwn(captured, key)) {
      if (schema.required) throw new TypeError("FLOW runtime options." + key + ' is required');
    } else if (typeof fields[key] !== schema.type || (schema.type === 'number' && !Number.isFinite(fields[key]))) {
      throw new TypeError("FLOW runtime options." + key + ' must be a ' + schema.type);
    }
  }
  return captured as unknown as PlaybookRuntimeOptions;
}
// Standalone quoted-relay composer: one callback-based pass over the original
// template substitutes the CJK placeholder token the shared engine's ASCII
// placeholder grammar cannot match. A quoted relay line `> <token>` whose value
// is empty is omitted, a multi-line value is quoted line by line, replacement
// text is literal and never reenters substitution, and the original PlayerInput
// remains unchanged. The token charset extends the shared grammar with Unicode
// letters so <任务文件的绝对路径> binds while the commit-message-format
// metavariables <type>, <scope>, and <imperative summary> stay literal text.
function composePlayerPrompt(input: PlaybookPlayerInput, _identity?: unknown, resuming = false): string {
  const fields = input as unknown as Readonly<Record<string, unknown>>;
  const mapping: Readonly<Record<string, string>> = { "任务文件的绝对路径": "任务文件的绝对路径" };
  const body = input.prompt.replace(
    /^> <(#|[\p{L}_$][\p{L}\p{N}_$-]*)>(\r?\n|$)|<(#|[\p{L}_$][\p{L}\p{N}_$-]*)>/gmu,
    (match: string, quoted: string | undefined, ending: string | undefined, inline: string | undefined): string => {
      const token = quoted ?? inline!;
      const field = Object.hasOwn(mapping, token) ? mapping[token]! : (token === '#' ? 'irNumber' : token.replace(/-([A-Za-z0-9_$])/g, (_match: string, next: string) => next.toUpperCase()));
      const value = fields[field];
      if (typeof value !== 'string') return match;
      if (quoted === undefined) return value;
      if (value === '') return '';
      return value.split(/(\r?\n)/).map((part, index) => index % 2 === 0 && part !== '' ? '> ' + part : part).join('') + (ending ?? '');
    },
  );
  // The shared composer supplies only the continuation prefix; rendered values
  // never reenter substitution and the original PlayerInput remains unchanged.
  return defaultComposePlayerPrompt({ ...input, prompt: '' }, mapping, resuming) + body;
}
const runtimeSpec = {
  composePlayerPrompt,
  ...{
  "label": "FLOW",
  "compat": {
    "artifactSchema": 3,
    "runtimeAbi": 1
  },
  "entryEvent": {
    "type": "START",
    "textField": "任务文件的绝对路径",
    "contextField": "任务文件的绝对路径"
  },
  "bossEvents": [],
  "roleStates": {
    "composing": {
      "role": "提交说明作者",
      "label": "提交说明作者读取任务文件及其引用的改动和上下文，完成提交说明。"
    }
  },
  "outcomeAuthority": {
    "governedPlayerStates": {
      "composing": {
        "message": {
          "fields": {
            "message": "semantic"
          },
          "repositoryDisposition": "unchanged"
        },
        "reason": {
          "fields": {
            "reason": "semantic"
          },
          "repositoryDisposition": "unchanged"
        },
        "needsBossReply": {
          "fields": {
            "question": "presentation"
          },
          "repositoryDisposition": "unchanged"
        }
      }
    }
  },
  "placeholderFields": {
    "任务文件的绝对路径": "任务文件的绝对路径"
  },
  "transitionEventFields": [
    "任务文件的绝对路径",
    "answer",
    "questionId"
  ],
  "controlContextFields": [
    "任务文件的绝对路径"
  ]
},
  snapshotOptions: validateOptions,
  machineInput: (options: PlaybookRuntimeOptions) => Object.fromEntries(
    Object.entries(INPUT_MAPPING).filter(([, key]) => options[key as keyof PlaybookRuntimeOptions] !== undefined)
      .map(([field, key]) => [field, options[key as keyof PlaybookRuntimeOptions]]),
  ),
  verbatimPayloadFields: VERBATIM_PAYLOAD_FIELDS,
  resumableStateIds: RESUMABLE_STATE_IDS,
  unfinishedFinalStateIds: UNFINISHED_FINAL_STATE_IDS,
} satisfies XStatePlaybookRuntimeSpecV3<PlaybookRuntimeOptions>;

export const _internal = {
  composePlayerPrompt,
  RESUMABLE_STATE_IDS,
  UNFINISHED_FINAL_STATE_IDS,
  VERBATIM_PAYLOAD_FIELDS,
};
const createPlaybookRuntime: XStatePlaybookRuntimeFactory<
  XStatePlaybookRuntimeConstruction<PlaybookRuntimeOptions, PlaybookHostCapabilities>, 3
> = createXStatePlaybookRuntime<PlaybookRuntimeOptions, PlaybookHostCapabilities>(machine, runtimeSpec);
export default createPlaybookRuntime;
