# flow: 根据改动生成提交说明

## 意图

在用户要求“写提交说明”“commit message”“/commit”或“/caveman-commit”时，读取用户提供的改动及项目约定，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。
流程在已生成提交说明或无法生成时结束。

Roles:
- 提交说明作者

## 外部行为

### flow-1

Boss 应用普通文本提供任务文件的绝对路径。

### flow-2

`flow` 应只生成文本，不暂存文件，不执行 git commit，不 amend，不得通过执行 Git 提交来代替输出说明 [[flow-5](#flow-5)]。

### flow-3

当提交说明作者成功生成说明 [[flow-5](#flow-5)] 时，`flow` 应以“已生成”结束，将 message 字符串原样交给调用者，其内容为完整代码块。

### flow-4

当任务文件或引用的输入无法读取、或资料不足以生成说明 [[flow-5](#flow-5)] 时，`flow` 应以“无法生成”结束，将 reason 字符串原样交给调用者，说明具体限制。

## 内部行为

### flow-5

当 Boss 提供任务文件的绝对路径 [[flow-1](#flow-1)] 时，Captain shall prompt 提交说明作者:

> 读取 Boss 用普通文本提供的任务文件绝对路径所指的任务文件及其引用的改动和上下文，然后完成提交说明。
> 生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。
> 只生成文本，不暂存文件，不执行 git commit，不 amend。
> 标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。
> type 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。
> 标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。
> 标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。
> 正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。
> 不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。
> 表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。
> 输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。
> 成功生成时，返回 message 字符串，内容为完整代码块。
> 任务文件或引用的输入无法读取、或资料不足以生成说明时，返回 reason 字符串说明具体限制。
> 不得通过执行 Git 提交来代替输出说明。
>
> > <boss-intent>

Results:
- `generated`: 成功生成提交说明。Output shall include `message: <完整代码块字符串>`。
- `unable`: 任务文件或引用的输入无法读取，或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`。

### flow-6

`flow` 应只有一个工作动作 [[flow-5](#flow-5)]，不增加额外审查或修改代码的阶段。

### flow-7

提交说明作者应在生成提交说明 [[flow-5](#flow-5)] 时使用标题格式 <type>(<scope>): <imperative summary>，scope 可省略，破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。

### flow-8

提交说明作者应在生成提交说明 [[flow-5](#flow-5)] 时遵守 type 和表达约定：

- type 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert。
- 使用 add、fix、remove 等祈使表达，不用 added、adds、adding。
- 冒号后大小写遵循项目约定。

### flow-9

提交说明作者应在生成标题 [[flow-5](#flow-5)] 时尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。

### flow-10

提交说明作者应在生成提交说明 [[flow-5](#flow-5)] 时按以下规则选择是否保留正文：

- 标题已经清楚时省略正文。
- 非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。
- 破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。

### flow-11

提交说明作者应在生成正文 [[flow-5](#flow-5)] 时按 72 个字符折行，列表符号用 -，关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。

### flow-12

提交说明作者应在生成提交说明 [[flow-5](#flow-5)] 时遵守以下措辞和归因规则：

- 不写 This commit does X、I、we、now、currently 等赘述。
- 不写 As requested by，适用时用 Co-authored-by trailer。
- 不加 AI 归因，除非用户自己的规则要求对应 trailer。
- 不用 emoji，除非项目约定要求。
- scope 已说明文件时不再重复文件名。

### flow-13

提交说明作者应在生成提交说明 [[flow-5](#flow-5)] 时表达为什么需要这个改动，避免机械复述差异，没有证据的信息不编造。

### flow-14

当用户输入 stop caveman-commit 或 normal mode 时，提交说明作者应在本次生成提交说明 [[flow-5](#flow-5)] 时改用正常详细提交说明风格，同时仍只生成可直接粘贴的代码块文本，不操作 Git 提交 [[flow-2](#flow-2)]。

## 验证

### flow-15

如果 Boss 已用普通文本提供可读取且资料充分的任务文件绝对路径 [[flow-1](#flow-1)]，当用户请求生成提交说明时，运行应展示成功生成的端到端流程：

- Captain 向提交说明作者交付完整提示 [[flow-5](#flow-5)]，只有一个工作动作，没有额外审查或修改代码阶段 [[flow-6](#flow-6)]。
- 输出标题符合格式、type、祈使表达、项目大小写约定、长度及结尾规则 [[flow-7](#flow-7)] [[flow-8](#flow-8)] [[flow-9](#flow-9)]。
- 正文的有无、折行、列表及 Issue 或 PR 位置符合规则 [[flow-10](#flow-10)] [[flow-11](#flow-11)]。
- 措辞、归因及改动原因符合规则且不编造没有证据的信息 [[flow-12](#flow-12)] [[flow-13](#flow-13)]。
- 流程以“已生成”结束，将完整代码块 message 原样交给调用者 [[flow-3](#flow-3)]，只生成文本，不暂存文件、不执行 git commit、不 amend [[flow-2](#flow-2)]。

### flow-16

如果 Boss 已提供任务文件路径 [[flow-1](#flow-1)]，当提交说明作者处理生成请求时，运行应展示以下外部可见的情况矩阵：

| 情况 | 断言 |
| --- | --- |
| 任务文件无法读取 | 向提交说明作者交付提示 [[flow-5](#flow-5)]，以“无法生成”结束，原样返回说明具体限制的 reason [[flow-4](#flow-4)]。 |
| 引用的输入无法读取 | 向提交说明作者交付提示 [[flow-5](#flow-5)]，以“无法生成”结束，原样返回说明具体限制的 reason [[flow-4](#flow-4)]。 |
| 资料不足以生成说明 | 向提交说明作者交付提示 [[flow-5](#flow-5)]，以“无法生成”结束，原样返回说明具体限制的 reason [[flow-4](#flow-4)]。 |
| 输入 stop caveman-commit 且资料充分 | 向提交说明作者交付提示 [[flow-5](#flow-5)]，本次使用正常详细提交说明风格并输出可直接粘贴的代码块 [[flow-14](#flow-14)]，以“已生成”结束并原样返回 message [[flow-3](#flow-3)]。 |
| 输入 normal mode 且资料充分 | 向提交说明作者交付提示 [[flow-5](#flow-5)]，本次使用正常详细提交说明风格并输出可直接粘贴的代码块 [[flow-14](#flow-14)]，以“已生成”结束并原样返回 message [[flow-3](#flow-3)]。 |

