// Independent, read-only acceptance of a completed native archive.
// A preliminary harness `passed` is insufficient without this evidence check.
import { readFile, readdir, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import * as path from 'node:path';

export async function checkNativeEvidence(directory, expectedCase, toolchainFile) {
  const hash = bytes => createHash('sha256').update(bytes).digest('hex');
  const json = async file => JSON.parse(await readFile(file, 'utf8'));
  const result = await json(path.join(directory, 'result.json'));
  if (result.caseId !== expectedCase || result.status !== 'passed' || result.compilation.exitCode !== 0)
    throw Error('No successful native execution for the expected TC');
  const native = result.platform === 'win32' ? path.win32 : path.posix;
  const normalize = value => {
    const resolved = native.resolve(value);
    return result.platform === 'win32' ? resolved.toLowerCase() : resolved;
  };
  const artifact = path.join(directory, 'workspace', 'flow.playbook');
  const attempts = path.join(artifact, '.slc', 'attempts');
  const names = await readdir(attempts);
  if (names.length !== 1) throw Error('Cold execution archive count differs from one');
  const attempt = path.join(attempts, names[0]);
  const bytes = await readFile(path.join(attempt, 'events.jsonl'));
  const events = bytes.toString('utf8').trim().split('\n').map(JSON.parse);
  if (hash(bytes) !== result.gates.processEvidence.eventsSHA256) throw Error('Audit stream digest differs from the executed record');
  const invocation = events.find(event => event.kind === 'invocation-start')?.data;
  if (!invocation || JSON.stringify(invocation.argv) !== JSON.stringify(['playbook', 'flow.md'])) throw Error('Unexpected actual compiler invocation');
  const remoteArtifact = native.join(invocation.cwd, 'flow.playbook');
  const remoteAttempt = native.join(remoteArtifact, '.slc', 'attempts', names[0]);
  const localSnapshot = remoteFile => {
    const rel = native.relative(remoteAttempt, remoteFile);
    if (rel === '..' || rel.startsWith('..' + native.sep) || native.isAbsolute(rel)) throw Error('Check snapshot escapes its invocation');
    return path.join(attempt, ...rel.split(native.sep));
  };
  const toolchainBytes = await readFile(toolchainFile);
  const toolchain = JSON.parse(toolchainBytes);
  if (toolchain.platform !== result.platform || toolchain.node !== result.node ||
      toolchain.compiler.buildIdentity !== invocation.compiler.buildIdentity)
    throw Error('Actual compiler/toolchain identity does not match the archived invocation');
  for (const name of ['typescript', '@types/node', '@sublang/spex']) {
    const tool = toolchain.tools[name];
    const rel = tool && native.relative(toolchain.prefix, tool.root);
    if (!tool || rel === '..' || rel.startsWith('..' + native.sep) || native.isAbsolute(rel))
      throw Error('Compiler tool is not from the acquired installation: ' + name);
  }
  const manifestBytes = await readFile(path.join(artifact, 'build-manifest.json'));
  if (hash(manifestBytes) !== result.gates.manifestSHA256) throw Error('Manifest digest mismatch');
  const manifest = JSON.parse(manifestBytes), accepted = new Map();
  for (const file of manifest.files) {
    const location = path.resolve(artifact, ...file.path.split('/'));
    const rel = path.relative(path.join(directory, 'workspace'), location);
    if (rel === '..' || rel.startsWith('../') || path.isAbsolute(rel)) throw Error('Accepted artifact escapes workspace');
    const digest = hash(await readFile(location));
    if (digest !== file.sha256) throw Error('Accepted executable differs: ' + file.path);
    accepted.set(normalize(native.resolve(remoteArtifact, file.path)), { ...file, digest });
  }
  const entryReport = await json(path.join(directory, 'independent-entry-check.stdout.log'));
  if (entryReport.schema !== 'sublang.slc.check.v1' || entryReport.status !== 'verified' ||
      !Array.isArray(entryReport.findings) || entryReport.findings.length || result.gates.entryCheck.exitCode !== 0)
    throw Error('Independent entry check did not report verified');

  // Validate every captured revision, including failed mechanical rounds.
  let snapshotCount = 0;
  for (const event of events) {
    const items = event.kind === 'file-snapshot'
      ? [{ ...event.data, file: native.resolve(remoteArtifact, event.data.snapshot) }]
      : event.kind === 'agent-target-revision'
        ? [{ ...event.data, file: native.resolve(remoteAttempt, event.data.snapshot) }]
        : event.kind === 'checker-start'
          ? (event.data.snapshots ?? []).map(item => ({ ...item, file: item.snapshot })) : [];
    for (const item of items) {
      if (hash(await readFile(localSnapshot(item.file))) !== item.sha256)
        throw Error('Missing or changed revision snapshot: ' + item.file);
      snapshotCount++;
    }
  }

  // Ordered complete start -> report -> finish chains, tied to exact arguments.
  const open = [], completed = [];
  for (const [index, event] of events.entries()) {
    if (event.kind === 'checker-start') {
      const chain = { job: event.data.job, args: event.data.args, start: event, startIndex: index };
      const snapshots = event.data.snapshots;
      if (!Array.isArray(snapshots)) throw Error('Checker has no input snapshot list');
      for (const arg of chain.args.filter(value => typeof value === 'string')) {
        if (!snapshots.some(item => normalize(item.path) === normalize(arg)))
          throw Error('Checker input has no captured bytes: ' + arg);
      }
      open.push(chain);
    } else if (event.kind === 'checker-report') {
      const chain = open.find(item => item.job === event.data.job && !item.report);
      if (!chain) throw Error('Checker report has no preceding input/start: ' + event.data.job);
      chain.report = event;
      chain.reportIndex = index;
    } else if (event.kind === 'checker-finish') {
      const position = open.findIndex(item => item.job === event.data.job && JSON.stringify(item.args) === JSON.stringify(event.data.args));
      if (position < 0) throw Error('Checker finish has no matching captured input/start: ' + event.data.job);
      const [chain] = open.splice(position, 1);
      if (!Number.isFinite(event.data.elapsedMs) || event.data.elapsedMs < 0) throw Error('Checker lacks elapsed time');
      chain.finish = event;
      chain.finishIndex = index;
      chain.verified = !event.data.error && Array.isArray(event.data.findings) && event.data.findings.length === 0;
      if (chain.verified && !chain.report) throw Error('Verified checker lacks its complete report: ' + chain.job);
      if (!chain.report && !event.data.error) throw Error('Checker has neither a report nor an explicit failed-process cause');
      completed.push(chain);
    }
  }
  if (open.length) throw Error('Unfinished checker input/start records remain');
  const evidence = {};
  for (const job of ['fsm', 'continuation', 'linked', 'lifecycle']) {
    const requiredKinds = job === 'linked' ? ['fsm', 'linked'] : job === 'lifecycle' ? ['fsm', 'entry'] : ['fsm'];
    const chain = completed.findLast(item => item.job === job && item.verified && requiredKinds.every(kind => {
      const file = [...accepted.entries()].find(([, value]) => value.kind === kind);
      return file && item.start.data.snapshots.some(snapshot => normalize(snapshot.path) === file[0] && snapshot.sha256 === file[1].digest);
    }));
    if (!chain) throw Error('No complete successful ' + job + ' check of the final accepted bytes');
    if (job === 'lifecycle' && !['initialize', 'dispose'].every(operation =>
      chain.report.data.observations.some(value => value.operation === operation && value.status === 'passed')))
      throw Error('Final lifecycle report omits initialize/dispose');
    evidence[job] = { start: chain.startIndex, report: chain.reportIndex, finish: chain.finishIndex,
      inputs: chain.start.data.snapshots.map(({ path, sha256 }) => ({ path, sha256 })) };
  }
  return { schema: 'slc.native-evidence-check.v1', status: 'verified', caseId: expectedCase,
    executionFinishedAt: result.finishedAt, checkedAt: new Date().toISOString(), snapshots: snapshotCount,
    checkerChains: completed.length, finalGates: evidence, toolchainSHA256: hash(toolchainBytes),
    eventsSHA256: hash(bytes), manifestSHA256: hash(manifestBytes) };
}

if (process.argv[1] && import.meta.url === new URL('file://' + path.resolve(process.argv[1])).href) {
  const [directory, expectedCase, toolchain, output] = process.argv.slice(2);
  try {
    const result = await checkNativeEvidence(directory, expectedCase, toolchain);
    await mkdir(path.dirname(output), { recursive: true });
    await writeFile(output, JSON.stringify(result, null, 2));
    console.log(JSON.stringify({ caseId: expectedCase, status: result.status, snapshots: result.snapshots }));
  } catch (error) {
    console.error(String(error.stack ?? error));
    process.exitCode = 1;
  }
}
