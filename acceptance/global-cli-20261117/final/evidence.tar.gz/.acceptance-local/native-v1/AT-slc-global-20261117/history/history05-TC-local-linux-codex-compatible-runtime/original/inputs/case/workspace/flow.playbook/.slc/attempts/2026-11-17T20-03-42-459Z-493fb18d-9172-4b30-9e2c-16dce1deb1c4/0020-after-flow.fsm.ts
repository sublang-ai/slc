import { setup, assign, fromPromise } from 'xstate';

export type MachineInput = { bossInput?: string };
export type PendingBossQuestion = {
  questionId: 'generate'; resumeStateId: 'generate'; sourceItem: 'flow-6';
  asker: { kind: 'role'; roleId: '提交说明作者' }; question: string;
};
export type PlayerOutput =
  | { guard: 'generated'; message: string }
  | { guard: 'unavailable'; reason: string }
  | { guard: 'needsBossReply'; question: string };
export type PlayerInput = {
  stateId: 'generate'; sourceItem: 'flow-6'; role: '提交说明作者'; prompt: string;
  bossInput: string;
  result: { generated: string; unavailable: string; needsBossReply: string };
  pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
};
export type MachineOutput = { message: string } | { reason: string };
type NormalizedError = { name: string; message: string; stack?: string };
type Context = {
  bossInput: string; pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
  terminalOutput?: MachineOutput; lastError?: NormalizedError;
};
type JumpableStateId = 'ready' | 'generate' | 'failed';
export type MachineEvent =
  | { type: 'START'; bossInput: string }
  | { type: 'BOSS_INTERRUPT'; targetId: JumpableStateId }
  | { type: 'BOSS_REPLY'; answer: string; questionId?: string };
export const concurrentRoleSets = [] as const;
const prompt = "读取 Boss 用普通文本提供的任务文件绝对路径所指的任务文件及其引用的改动和上下文，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n只生成文本，不暂存文件，不执行 git commit，不 amend；不得通过执行 Git 提交来代替输出说明。\n标题依次包含 type、可省略的括号 scope、冒号及空格、imperative summary；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。\n成功生成时返回完整代码块；任务文件或引用的输入无法读取、或资料不足以生成说明时，说明具体限制。\n> <boss-input>";
const result = {
  generated: '已成功生成提交说明。Output shall include `message: <完整代码块字符串>`。',
  unavailable: '任务文件或引用的输入无法读取，或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`。',
  needsBossReply: "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.",
};
function record(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function actorOutput(event: unknown): PlayerOutput | undefined {
  if (!record(event) || !record(event.output)) return undefined;
  const o = event.output;
  if (o.guard === 'generated' && typeof o.message === 'string' && o.message.trim()) return { guard: 'generated', message: o.message };
  if (o.guard === 'unavailable' && typeof o.reason === 'string' && o.reason.trim()) return { guard: 'unavailable', reason: o.reason };
  if (o.guard === 'needsBossReply' && typeof o.question === 'string' && o.question.trim()) return { guard: 'needsBossReply', question: o.question };
  return undefined;
}
function clearBossReplyContext(context: Context): Context {
  delete context.pendingBossQuestion;
  delete context.bossReply;
  return { ...context };
}
function normalizeError(event: unknown): NormalizedError {
  const error = record(event) ? event.error : undefined;
  if (error instanceof Error) return { name: error.name, message: error.message, ...(typeof error.stack === 'string' ? { stack: error.stack } : {}) };
  return { name: 'Error', message: typeof error === 'string' ? error : 'Malformed actor output or Boss reply.' };
}
function bossInterrupts(ids: readonly JumpableStateId[]) {
  return ids.map(id => ({
    target: `#${id}`,
    reenter: true,
    guard: ({ context, event }: { context: Context; event: MachineEvent }) => event.type === 'BOSS_INTERRUPT' && event.targetId === id && (id !== 'generate' || (typeof context.bossInput === 'string' && !!context.bossInput.trim())),
    actions: 'clearBossReplyContext' as const,
  }));
}
function resumableStates(ids: readonly ['generate']) {
  return ids.map(id => ({
    target: `#${id}`,
    guard: ({ context, event }: { context: Context; event: MachineEvent }) => event.type === 'BOSS_REPLY' && typeof event.answer === 'string' && !!event.answer.trim() && context.pendingBossQuestion?.resumeStateId === id && (event.questionId === undefined || event.questionId === context.pendingBossQuestion.questionId),
    actions: 'rememberBossReply' as const,
  }));
}
export const machine = setup({
  types: {
    context: {} as Context, events: {} as MachineEvent,
    input: {} as MachineInput, output: {} as MachineOutput,
  },
  actors: {
    player: fromPromise<PlayerOutput, PlayerInput>(async () => { throw new Error('player actor must be provided by the runner'); }),
  },
  actions: {
    'playbook.acceptedOutcome': (_args, _params: { source: string; target: string; acceptedOutcome: string }) => {},
    clearBossReplyContext: assign(({ context }) => clearBossReplyContext(context)),
    start: assign(({ context, event }) => {
      if (event.type !== 'START') return {};
      clearBossReplyContext(context);
      delete context.terminalOutput;
      delete context.lastError;
      return { ...context, bossInput: event.bossInput };
    }),
    rememberBossReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    setPendingBossQuestion: assign(({ context, event }) => {
      const o = actorOutput(event);
      if (o?.guard !== 'needsBossReply') return {};
      const next = clearBossReplyContext(context);
      next.pendingBossQuestion = { questionId: 'generate', resumeStateId: 'generate', sourceItem: 'flow-6', asker: { kind: 'role', roleId: '提交说明作者' }, question: o.question };
      return next;
    }),
    rememberTerminal: assign(({ context, event }) => {
      const o = actorOutput(event);
      const next = clearBossReplyContext(context);
      if (o?.guard === 'generated') next.terminalOutput = { message: o.message };
      if (o?.guard === 'unavailable') next.terminalOutput = { reason: o.reason };
      return next;
    }),
    rememberError: assign(({ context, event }) => ({ ...clearBossReplyContext(context), lastError: normalizeError(event) })),
  },
  guards: {
    validEntry: ({ event }) => event.type === 'START' && typeof event.bossInput === 'string' && !!event.bossInput.trim(),
    generated: ({ event }) => actorOutput(event)?.guard === 'generated',
    unavailable: ({ event }) => actorOutput(event)?.guard === 'unavailable',
    needsBossReply: ({ event }) => actorOutput(event)?.guard === 'needsBossReply',
  },
}).createMachine({
  id: 'flow', initial: 'ready',
  context: ({ input }) => ({ bossInput: input?.bossInput ?? '' }),
  output: ({ context }) => {
    if (!context.terminalOutput) throw new Error('No terminal result');
    return context.terminalOutput;
  },
  on: { BOSS_INTERRUPT: bossInterrupts(['ready', 'generate', 'failed']) },
  states: {
    ready: {
      id: 'ready', description: '等待 Boss 提供任务文件绝对路径。', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'ready', description: '等待 Boss 提供任务文件绝对路径。' } },
      on: { START: { guard: 'validEntry', target: '#generate', actions: 'start' } },
    },
    generate: {
      id: 'generate', description: '提交说明作者根据任务文件生成提交说明。', tags: ['playbook.busy'],
      meta: { playbook: { stateId: 'generate', description: '提交说明作者根据任务文件生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({ stateId: 'generate', sourceItem: 'flow-6', role: '提交说明作者', prompt, result, bossInput: context.bossInput,
          ...(context.pendingBossQuestion ? { pendingBossQuestion: context.pendingBossQuestion } : {}),
          ...(context.bossReply !== undefined ? { bossReply: context.bossReply } : {}),
        }),
        onDone: [
          { guard: 'generated', target: '#generated', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'generate', target: 'generated', acceptedOutcome: 'generated' } }, 'rememberTerminal'] },
          { guard: 'unavailable', target: '#unavailable', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'generate', target: 'unavailable', acceptedOutcome: 'unavailable' } }, 'rememberTerminal'] },
          { guard: 'needsBossReply', target: '#awaitBossReply', actions: [{ type: 'playbook.acceptedOutcome', params: { source: 'generate', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } }, 'setPendingBossQuestion'] },
          { target: '#failed', actions: 'rememberError' },
        ],
        onError: { target: '#failed', actions: 'rememberError' },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question.", tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question." } },
      on: { BOSS_REPLY: [...resumableStates(['generate']), { target: '#failed', actions: 'rememberError' }], START: { guard: 'validEntry', target: '#generate', actions: 'start' } },
    },
    failed: {
      id: 'failed', description: '执行发生错误，等待 Boss 恢复。', tags: ['playbook.parked'],
      meta: { playbook: { stateId: 'failed', description: '执行发生错误，等待 Boss 恢复。' } },
      on: { START: { guard: 'validEntry', target: '#generate', actions: 'start' } },
    },
    generated: { id: 'generated', type: 'final', description: '已生成', meta: { playbook: { stateId: 'generated', description: '已生成', terminal: 'success' } } },
    unavailable: { id: 'unavailable', type: 'final', description: '无法生成', meta: { playbook: { stateId: 'unavailable', description: '无法生成', terminal: 'failure' } } },
  },
});
export default machine;
