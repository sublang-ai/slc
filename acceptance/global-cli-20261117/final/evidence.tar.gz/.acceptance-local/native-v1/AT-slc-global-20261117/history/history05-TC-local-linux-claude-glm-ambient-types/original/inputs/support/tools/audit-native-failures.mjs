// Read-only audit of unsuccessful native acceptance runs. Never invokes a model,
// compiler, shell, or provider, and never writes to the evidence being audited.
import { readFile, readdir, lstat, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { gunzipSync } from 'node:zlib';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';

const COHORT = 'd98865e1b2463092844cbcafd454209a37941b2f94639ad690bd27c49fae56b2';
const SOURCE = 'af0a67466cfb4d5efb79caee263ee433ebc6a9fc7090cd6fbb071a1a998ab969';
const PHASES = ['text2gears.md', 'optimize.md', 'prefix.md', 'gears2fsm.md', 'link.md'];
const PARENTS = ['empty', 'commonjs', 'esm-git', 'compatible-runtime', 'missing-runtime', 'conflicting-runtime', 'ambient-types', 'spaces-chinese'];
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const assert = (condition, message) => { if (!condition) throw Error(message); };
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
async function exists(file) {
  try { await lstat(file); return true; } catch (error) { if (error.code === 'ENOENT') return false; throw error; }
}
function quota(text) {
  const match = String(text).match(/API Error: Request rejected \(429\)\s*·\s*\[1308\]\[([^\]]+)\]/);
  const reset = match?.[1].match(/限额将在\s*(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s*重置/);
  if (!match || !/已达到\s*5\s*小时的使用上限/.test(match[1]) || !reset) return null;
  // Deliberately omit provider request IDs and all unrelated log text.
  return { httpStatus: 429, providerCode: '1308', periodHours: 5, resetAtLiteral: reset[1],
    resetTimezone: 'not stated in provider message', message: match[0] };
}

export async function auditFailedNativeCase({ root, caseId, indexEntry, evidenceDirectory, toolchainFile }) {
  const coordinates = caseId.match(/^TC-local-(macos|linux|windows)-(claude-glm)-(.+)$/);
  assert(coordinates && PARENTS.includes(coordinates[3]), 'Not an expected Claude/GLM failure coordinate');
  const [, osName, , parent] = coordinates;
  const platform = { macos: 'darwin', linux: 'linux', windows: 'win32' }[osName];
  const native = platform === 'win32' ? path.win32 : path.posix;
  const normalize = value => {
    let resolved = native.resolve(value);
    if (platform === 'darwin' && (resolved === '/tmp' || resolved.startsWith('/tmp/'))) resolved = '/private' + resolved;
    return platform === 'win32' ? resolved.toLowerCase() : resolved;
  };
  const same = (a, b) => normalize(a) === normalize(b);
  const within = (base, target) => {
    const rel = native.relative(normalize(base), normalize(target));
    return rel !== '..' && !rel.startsWith('..' + native.sep) && !native.isAbsolute(rel);
  };
  const directory = evidenceDirectory ?? path.join(root, 'evidence', osName === 'windows' ? 'native-complete-05' : 'native-05', 'formal-' + caseId);
  const evidence = new Map();
  const load = async file => {
    const bytes = await readFile(file);
    evidence.set(path.relative(root, file).split(path.sep).join('/'), { sha256: hash(bytes), size: bytes.length });
    return bytes;
  };
  const json = async file => JSON.parse((await load(file)).toString('utf8'));
  const readText = async file => (await load(file)).toString('utf8');
  const result = await json(path.join(directory, 'result.json'));
  const configPath = path.join(root, 'evidence/native-configs-05', 'formal-' + caseId + '.json');
  const configBytes = await load(configPath), config = JSON.parse(configBytes);
  const match = await json(path.join(root, '.acceptance-local/native-v1/AT-slc-global-20261117/match/match-sc2-v5/result.json'));
  assert(match.bindings[path.relative(root, configPath).split(path.sep).join('/')] === hash(configBytes), 'Configuration differs from registered match binding');
  assert(result.caseId === caseId && result.platform === platform && result.parent === parent && result.layer === 'local', 'Raw native coordinate mismatch');
  assert(config.caseId === caseId && config.backend === 'claude-glm' && config.parent === parent && config.expectedPlatform === platform, 'Configuration coordinate mismatch');
  assert(result.status === 'failed' && result.compilation.exitCode !== 0 && result.compilation.signal === null, 'Run is not an ordinary failed native compilation');
  assert(indexEntry?.caseId === caseId && indexEntry.status === 'execution-failed', 'Index does not preserve its original execution-failed state');
  assert(indexEntry.compilationExitCode === result.compilation.exitCode && indexEntry.transportExitCode !== 0, 'Index/native failure exit mismatch');
  const harnessBytes = await load(path.join(root, 'tools/native-case-v5.mjs'));
  assert(hash(harnessBytes) === match.bindings['tools/native-case-v5.mjs'] && result.harnessSHA256 === hash(harnessBytes), 'Actual failed run is not the registered native harness');
  const cohortBytes = await load(path.join(root, 'evidence/candidate-cohort-04/frozen-cohort.json'));
  assert(hash(cohortBytes) === COHORT && result.cohortSHA256 === COHORT, 'Frozen candidate cohort mismatch');
  const cohort = JSON.parse(cohortBytes);
  assert(hash(await load(path.join(root, 'inputs/flow.md'))) === SOURCE && result.sourceSHA256 === SOURCE, 'Frozen Source identity mismatch');
  assert(result.cliSHA256 === config.expectedCliSHA256 && result.cliSHA256 === cohort.packages['@sublang/slc'].files['dist/cli.js'], 'Installed CLI digest differs from cohort');

  const compile = await json(path.join(directory, 'compile.json'));
  assert(equal(compile, result.compilation), 'Compilation receipt differs from raw result');
  assert(compile.args.length === 3 && same(compile.args[0], config.cli) && equal(compile.args.slice(1), ['playbook', 'flow.md']) && same(compile.cwd, result.child), 'Not the expected real installed CLI invocation');
  assert(Number.isFinite(compile.elapsedMs) && compile.elapsedMs >= 0 && Date.parse(compile.finishedAt) >= Date.parse(compile.startedAt), 'Invalid completed compilation timings');
  const stdoutBytes = await load(path.join(directory, 'compile.stdout.log'));
  const stderrBytes = await load(path.join(directory, 'compile.stderr.log'));
  assert(hash(stdoutBytes) === compile.stdoutSHA256 && hash(stderrBytes) === compile.stderrSHA256, 'Captured process stream digest mismatch');
  const stderrQuota = quota(stderrBytes.toString('utf8'));
  assert(stderrQuota, 'Actual compiler stderr lacks the explicit HTTP429/1308 five-hour-quota message');

  const workspace = path.join(directory, 'workspace'), artifact = path.join(workspace, 'flow.playbook');
  const names = await readdir(path.join(artifact, '.slc/attempts'));
  assert(names.length === 1, 'Failure is not a single cold invocation archive');
  const attempt = path.join(artifact, '.slc/attempts', names[0]);
  const eventsBytes = await load(path.join(attempt, 'events.jsonl'));
  const events = eventsBytes.toString('utf8').trim().split('\n').map(JSON.parse);
  const select = kind => events.map((event, index) => ({ ...event, index })).filter(event => event.kind === kind);
  const starts = select('invocation-start'), finishes = select('invocation-finish');
  assert(starts.length === 1 && finishes.length === 1 && starts[0].index < finishes[0].index && finishes[0].data.ok === false, 'Missing failed invocation boundary');
  const invocation = starts[0].data, finish = finishes[0].data;
  assert(equal(invocation.argv, ['playbook', 'flow.md']) && same(invocation.cwd, result.child), 'Archived invocation is not this native CLI/workspace');
  const remoteArtifact = native.join(invocation.cwd, 'flow.playbook');
  const remoteAttempt = native.join(remoteArtifact, '.slc/attempts', names[0]);
  const mapFile = (remote, remoteBase, localBase) => {
    assert(within(remoteBase, remote), 'Evidence file escapes its recorded origin');
    return path.join(localBase, ...native.relative(normalize(remoteBase), normalize(remote)).split(native.sep));
  };
  const sourceFile = path.join(workspace, 'flow.md');
  assert(hash(await load(sourceFile)) === SOURCE, 'Actual archived workflow Source differs');
  const attemptResult = await json(path.join(attempt, 'result.json'));
  assert(equal(attemptResult, finish) && attemptResult.ok === false, 'Failed attempt result differs from invocation-finish');
  assert(quota(JSON.stringify(attemptResult.diagnostics)), 'Failed invocation diagnostics do not retain quota evidence');

  const toolchainPath = toolchainFile ?? path.join(root, 'evidence/preflight', 'toolchain-' + osName + '-05.json');
  const toolchain = await json(toolchainPath);
  assert(toolchain.platform === platform && toolchain.node === result.node && equal(toolchain.compiler, invocation.compiler), 'Actual toolchain/compiler identity differs from pre-Agent invocation');
  assert(same(toolchain.prefix, config.toolchainPrefix), 'Toolchain record belongs to another installation');
  for (const name of ['typescript', '@types/node', '@sublang/spex']) {
    const tool = toolchain.tools[name];
    assert(tool && within(toolchain.prefix, tool.root) && within(tool.root, tool.entry) && /^[a-f0-9]{64}$/.test(tool.entrySHA256), 'Compiler tool root/identity is not installation-owned: ' + name);
  }
  assert(invocation.compiler.package === '@sublang/slc' && invocation.compiler.version === cohort.packages['@sublang/slc'].version, 'Wrong producing compiler');
  for (const [name, frozen] of Object.entries(cohort.packages)) {
    const pkg = result.installedPackages[name];
    assert(pkg?.version === frozen.version && config.expectedVersions[name] === frozen.version && within(toolchain.prefix, pkg.root), 'Wrong recorded acquired package: ' + name);
    assert(pkg.verifiedPackedFiles === Object.keys(frozen.files).length && pkg.tarballSHA256 === frozen.tarballSHA256, 'Packed-file verification record missing: ' + name);
  }
  for (const name of ['playbook', 'xstate']) assert(within(toolchain.prefix, result.selected[name].root), 'Selected runtime root escapes acquired installation');
  assert(equal(invocation.environment, result.selected), 'Invocation runtime pair differs from the native identity');
  assert(invocation.configuration.selection.agent === 'claude-code' && invocation.configuration.selection.model === 'glm-5.3' && result.environment.SLC_AGENT === 'claude-code' && result.environment.SLC_MODEL === 'glm-5.3', 'Actual Agent/model is not the configured GLM backend');
  assert(result.environment.ANTHROPIC_BASE_URL === 'https://open.bigmodel.cn/api/anthropic', 'Wrong recorded GLM endpoint');
  for (const name of ['@openai/codex-sdk', '@anthropic-ai/claude-agent-sdk']) assert(result.sdkIdentities[name] && within(toolchain.prefix, result.sdkIdentities[name].root), 'SDK is not from acquired installation');
  assert(result.nativeRuntime.state === 'present' && within(toolchain.prefix, result.nativeRuntime.path) && /^[a-f0-9]{64}$/.test(result.nativeRuntime.sha256), 'Selected native executable is not installation-owned');
  const nativeVersion = await json(path.join(directory, 'native-version.json'));
  const nativeStdout = await load(path.join(directory, 'native-version.stdout.log'));
  const nativeStderr = await load(path.join(directory, 'native-version.stderr.log'));
  assert(nativeVersion.exitCode === 0 && nativeVersion.stdoutSHA256 === hash(nativeStdout) && nativeVersion.stderrSHA256 === hash(nativeStderr), 'Native --version receipt is incomplete');
  assert(nativeStdout.toString('utf8').trim() === result.nativeRuntime.version && Date.parse(nativeVersion.finishedAt) <= Date.parse(compile.startedAt), 'Native version was not recorded before compilation');
  const preflights = select('agent-preflight'), calls = select('agent-call');
  assert(calls.length > 0 && preflights.length > 0 && starts[0].index < preflights[0].index && preflights[0].index < calls[0].index, 'No actual pre-Agent SDK/native readiness evidence');
  for (const event of preflights) {
    const p = event.data;
    assert(p.available === true && p.agent === 'claude-code' && p.native.state === 'present' && same(p.native.path, result.nativeRuntime.path) && p.installed.some(item => item.package === '@anthropic-ai/claude-agent-sdk' && item.version === result.sdkIdentities['@anthropic-ai/claude-agent-sdk'].version), 'Actual SDK/native preflight differs from recorded acquisition');
  }
  assert(calls.every(event => event.data.agent === 'claude-code' && event.data.model === 'glm-5.3' && same(event.data.cwd, invocation.cwd)), 'Actual Agent call selection/workspace differs');

  const phaseStarts = select('phase-start'), phaseReturns = select('phase-return');
  assert(phaseStarts.length > 0 && phaseStarts.length <= PHASES.length && phaseStarts.length === phaseReturns.length, 'Incomplete attempted-phase boundaries');
  const phases = [];
  for (let i = 0; i < phaseStarts.length; i++) {
    const start = phaseStarts[i], returned = phaseReturns[i], target = start.data.target ?? start.data.linked;
    assert(native.basename(start.data.definitionPath) === PHASES[i], 'Attempted phases do not form the real pipeline prefix');
    assert(start.index < returned.index && (i === 0 || phaseReturns[i - 1].index < start.index) && same(returned.data.target, target), 'Phase result is not ordered against its actual input/target');
    assert(Number.isFinite(returned.data.elapsedMs) && returned.data.elapsedMs >= 0, 'Phase lacks actual elapsed time');
    assert(returned.data.value.status === (i === phaseStarts.length - 1 ? 'error' : 'ok'), 'Failure is not the final attempted phase');
    phases.push({ phase: PHASES[i].replace('.md', ''), status: returned.data.value.status, startEvent: start.index,
      returnEvent: returned.index, startedAt: start.at, returnedAt: returned.at, elapsedMs: returned.data.elapsedMs, target });
  }
  const failedPhase = phaseReturns.at(-1), phaseQuota = quota(JSON.stringify(failedPhase.data.value.diagnostics));
  assert(phaseQuota && failedPhase.index < finishes[0].index, 'Final failed phase does not retain the quota cause');
  const quotaAgentEvents = select('agent-event').filter(event => event.data.type === 'error' || event.data.type === 'done').filter(event => quota(JSON.stringify(event.data.payload)));
  assert(quotaAgentEvents.length > 0 && quotaAgentEvents.some(event => event.index > phaseStarts.at(-1).index && event.index < failedPhase.index), 'No actual terminal Agent error corroborates quota classification');
  assert(quotaAgentEvents.every(event => quota(JSON.stringify(event.data.payload)).resetAtLiteral === stderrQuota.resetAtLiteral) && phaseQuota.resetAtLiteral === stderrQuota.resetAtLiteral, 'Provider reset text is inconsistent across process/phase/Agent records');

  let snapshotCount = 0;
  const sourceSnapshots = [];
  for (const event of events) {
    const items = event.kind === 'file-snapshot'
      ? [{ ...event.data, remote: native.resolve(remoteArtifact, event.data.snapshot) }]
      : event.kind === 'agent-target-revision'
        ? [{ ...event.data, remote: native.resolve(remoteAttempt, event.data.snapshot) }]
        : event.kind === 'checker-start' ? (event.data.snapshots ?? []).map(item => ({ ...item, remote: item.snapshot })) : [];
    for (const item of items) {
      const file = mapFile(item.remote, remoteAttempt, attempt);
      assert(hash(await load(file)) === item.sha256, 'Missing or changed attempted-revision snapshot: ' + path.basename(file));
      if (same(item.path, native.join(invocation.cwd, 'flow.md'))) sourceSnapshots.push({ path: path.relative(root, file), sha256: item.sha256 });
      snapshotCount++;
    }
  }
  assert(sourceSnapshots.length > 0 && sourceSnapshots.every(item => item.sha256 === SOURCE), 'No frozen actual Source snapshot');
  for (const remote of finish.outputs) assert(await exists(mapFile(remote, invocation.cwd, workspace)), 'Retained successful partial output is missing');
  const checkerStarts = select('checker-start'), checkerFinishes = select('checker-finish');
  assert(checkerStarts.length === checkerFinishes.length, 'Incomplete reached checker boundaries');
  const pendingChecks = [];
  for (const event of events) {
    if (event.kind === 'checker-start') pendingChecks.push({ ...event.data, report: false });
    if (event.kind === 'checker-report') {
      const check = pendingChecks.find(item => item.job === event.data.job && !item.report);
      assert(check, 'Reached checker report lacks preceding start'); check.report = true;
    }
    if (event.kind === 'checker-finish') {
      const position = pendingChecks.findIndex(item => item.job === event.data.job && equal(item.args, event.data.args));
      assert(position >= 0, 'Reached checker finish lacks matching start');
      const [check] = pendingChecks.splice(position, 1);
      assert(check.report || event.data.error, 'Reached checker lacks report or explicit failure cause');
    }
  }
  assert(pendingChecks.length === 0, 'Reached checker remained open');
  assert(result.gates === null && !select('entry-lifecycle').some(event => event.data.findings?.length === 0), 'Failed run contains an accepted entry/lifecycle claim');
  const noAccepted = ['flow.mjs', 'flow.ts', 'flow.playbook/build-manifest.json', 'flow.playbook/.slc/builds'];
  for (const item of noAccepted) assert(!await exists(path.join(workspace, item)), 'Failed cold run has an accepted entry/manifest/history: ' + item);
  assert(result.parentUnchanged === true && equal(result.parentBefore, result.parentAfter) && equal(result.ancestryBefore, result.ancestryAfter), 'Parent/ancestor identity changed during failed compilation');

  let capture = null;
  if (osName === 'windows') {
    const archiveFile = path.join(root, 'evidence/native-complete-05', 'formal-' + caseId + '.json.gz');
    const archiveBytes = await load(archiveFile), container = JSON.parse(gunzipSync(archiveBytes));
    const receipt = JSON.parse((await readText(path.join(root, 'evidence/windows-collection-05', caseId + '.stdout'))).trim());
    assert(hash(archiveBytes) === receipt.archiveSHA256 && container.caseId === caseId && container.collectionComparisons.length === 0, 'Windows native capture/short-gzip provenance is incomplete');
    let capturedFiles = 0;
    for (const [name, record] of Object.entries(container.files)) {
      if (record.kind !== 'file') continue;
      const location = path.resolve(directory, name), rel = path.relative(directory, location);
      assert(rel !== '..' && !rel.startsWith('../') && !path.isAbsolute(rel), 'Captured file escapes evidence copy');
      const bytes = Buffer.from(record.base64, 'base64');
      assert(hash(bytes) === record.sha256 && hash(await load(location)) === record.sha256, 'Windows complete capture file digest mismatch: ' + name);
      capturedFiles++;
    }
    capture = { archive: path.relative(root, archiveFile), archiveSHA256: hash(archiveBytes), capturedFiles, originalArchiveDifferences: 0 };
  }
  return { schema: 'slc.native-failure-case-audit.v1', caseId, auditStatus: 'failure-evidence-verified', acceptancePassed: false,
    original: { indexStatus: indexEntry.status, nativeStatus: result.status, compilerCause: attemptResult.cause,
      compilationExitCode: compile.exitCode, transportExitCode: indexEntry.transportExitCode },
    independentCause: { category: 'environment', kind: 'provider-quota', ...stderrQuota,
      classificationDiffersFromOriginal: attemptResult.cause?.category !== 'environment', originalRecordsModified: false },
    coordinates: { platform, osName, parent, backend: 'claude-code', model: 'glm-5.3', endpoint: result.environment.ANTHROPIC_BASE_URL },
    compilation: { startedAt: compile.startedAt, finishedAt: compile.finishedAt, elapsedMs: compile.elapsedMs, executable: compile.executable, args: compile.args },
    identities: { cohortSHA256: COHORT, harnessSHA256: result.harnessSHA256, sourceSHA256: SOURCE, sourceSnapshots,
      compiler: invocation.compiler, packages: result.installedPackages, selectedRuntime: { playbook: { root: result.selected.playbook.root, version: result.selected.playbook.version, contentHash: result.selected.playbook.contentHash },
        xstate: { root: result.selected.xstate.root, version: result.selected.xstate.version, contentHash: result.selected.xstate.contentHash } },
      tools: toolchain.tools, sdks: result.sdkIdentities, native: result.nativeRuntime },
    attemptedPhases: phases, failedPhase: phases.at(-1).phase, notReachedPhases: PHASES.slice(phases.length).map(item => item.replace('.md', '')),
    partialSuccessfulOutputs: finish.outputs, reachedCheckerJobs: checkerFinishes.map(event => ({ job: event.data.job, findings: event.data.findings?.length ?? null, error: Boolean(event.data.error) })),
    quotaEvidence: { stderr: path.relative(root, path.join(directory, 'compile.stderr.log')), phaseReturnEvent: failedPhase.index,
      invocationFinishEvent: finishes[0].index, agentTerminalEvents: quotaAgentEvents.map(event => ({ event: event.index, at: event.at, type: event.data.type })) },
    absence: { acceptedEntry: true, acceptedManifest: true, acceptedBuildHistory: true, lifecycleAcceptance: true },
    snapshotCount, parentUnchanged: true, capture, evidenceDirectory: path.relative(root, directory),
    evidenceFiles: Object.fromEntries([...evidence.entries()].sort(([a], [b]) => a.localeCompare(b))) };
}

export async function auditNativeFailures(root, onlyCase) {
  root = await realpath(root);
  const indexPath = path.join(root, 'evidence/evidence-audit-05/index.json');
  const indexBytes = await readFile(indexPath), index = JSON.parse(indexBytes);
  const expected = new Set(['macos', 'linux', 'windows'].flatMap(os => ['codex', 'claude-glm'].flatMap(backend => PARENTS.map(parent => `TC-local-${os}-${backend}-${parent}`))));
  assert(Object.keys(index.cases).length === 48 && Object.keys(index.cases).every(cid => expected.has(cid)) && index.notExecutedOrNotComplete.length === 0, 'Input index is not the completed fixed 48-coordinate matrix');
  const failed = Object.entries(index.cases).filter(([cid, item]) => item.status === 'execution-failed' && (!onlyCase || cid === onlyCase));
  assert(failed.length > 0 && (!onlyCase || failed.length === 1), 'No matching unsuccessful native case');
  const cases = {};
  for (const [caseId, indexEntry] of failed) {
    try { cases[caseId] = await auditFailedNativeCase({ root, caseId, indexEntry }); }
    catch (error) { cases[caseId] = { caseId, auditStatus: 'failure-evidence-incomplete', acceptancePassed: false, error: String(error.stack ?? error) }; }
  }
  const complete = Object.values(cases).every(item => item.auditStatus === 'failure-evidence-verified');
  return { schema: 'slc.native-failure-evidence-audit.v1', auditStatus: complete ? 'complete' : 'incomplete', acceptancePassed: false,
    auditedAt: new Date().toISOString(), auditorSHA256: hash(await readFile(fileURLToPath(import.meta.url))),
    index: { path: path.relative(root, indexPath), sha256: hash(indexBytes), at: index.at,
      verifiedCompilationCount: Object.values(index.cases).filter(item => item.status === 'verified').length,
      unsuccessfulCompilationCount: Object.values(index.cases).filter(item => item.status === 'execution-failed').length },
    scope: 'Read-only verification and independent classification of unsuccessful native runs; no compilation/provider calls, no raw-record changes, no acceptance pass, no formal history import.',
    checkedCases: failed.length, failureEvidenceVerified: Object.values(cases).filter(item => item.auditStatus === 'failure-evidence-verified').length, cases };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const args = process.argv.slice(2), rootFlag = args.indexOf('--root'), caseFlag = args.indexOf('--case');
    const root = rootFlag >= 0 ? args[rootFlag + 1] : path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
    const report = await auditNativeFailures(root, caseFlag >= 0 ? args[caseFlag + 1] : undefined);
    process.stdout.write(JSON.stringify(report, null, 2) + '\n');
    if (report.auditStatus !== 'complete') process.exitCode = 1;
  } catch (error) { console.error(String(error.stack ?? error)); process.exitCode = 1; }
}
