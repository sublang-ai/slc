import { setup, assign, fromPromise } from 'xstate';

export type MachineInput = { taskFilePath?: string };
export type MachineOutput = { message: string } | { reason: string };
export type PendingBossQuestion = {
  questionId: 'generate'; resumeStateId: 'generate'; sourceItem: 'flow-5';
  asker: { kind: 'role'; roleId: '提交说明作者' }; question: string;
};
export type PlayerInput = {
  stateId: 'generate'; sourceItem: 'flow-5'; role: '提交说明作者';
  prompt: string; taskFilePath: string; result: Record<'generated' | 'unable' | 'needsBossReply', string>;
  pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
};
export type PlayerOutput =
  | { guard: 'generated'; message: string }
  | { guard: 'unable'; reason: string }
  | { guard: 'needsBossReply'; question: string };
type Context = {
  taskFilePath: string; pendingBossQuestion?: PendingBossQuestion; bossReply?: string;
  terminalOutput?: MachineOutput; lastError?: { name: string; message: string; stack?: string };
};
type JumpId = 'ready' | 'generate' | 'failed';
export type MachineEvent =
  | { type: 'GENERATE'; taskFilePath: string }
  | { type: 'BOSS_INTERRUPT'; targetId: JumpId }
  | { type: 'BOSS_REPLY'; answer: string; questionId?: string };
export const concurrentRoleSets = [] as const;
const prompt = "读取任务文件及其引用的改动和上下文，生成简洁、准确、强调改动意图的 Conventional Commits 提交说明。\n标题使用 <type>(<scope>): <imperative summary>；scope 可省略；破坏性变更按 Conventional Commits 用 ! 标记并写明 BREAKING CHANGE。\ntype 只选 feat、fix、refactor、perf、docs、test、chore、build、ci、style、revert；使用 add、fix、remove 等祈使表达，不用 added、adds、adding；冒号后大小写遵循项目约定。\n标题尽量不超过 50 个字符，硬上限 72 个字符，不以句号结束。\n标题已经清楚时省略正文；非显而易见的原因、破坏性变更、迁移说明或关联 Issue 才需要正文。破坏性变更、安全修复、数据迁移、撤销旧提交始终有正文，不压缩成只有标题。\n正文按 72 个字符折行；列表符号用 -；关联 Issue 或 PR 放在最后，例如 Closes #42、Refs #17。\n不写 This commit does X、I、we、now、currently 等赘述；不写 As requested by，适用时用 Co-authored-by trailer；不加 AI 归因，除非用户自己的规则要求对应 trailer；不用 emoji，除非项目约定要求；scope 已说明文件时不再重复文件名。\n表达为什么需要这个改动，避免机械复述差异；没有证据的信息不编造。\n输出可直接粘贴的代码块。用户输入 stop caveman-commit 或 normal mode 时，本次改用正常详细提交说明风格，同时仍只生成文本，不操作 Git 提交。\n成功生成时，返回 message 字符串，内容为完整代码块。任务文件或引用的输入无法读取、或资料不足以生成说明时，返回 reason 字符串说明具体限制。\n\n> <task-file-path>";
function record(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
function output(event: unknown): Record<string, unknown> | undefined {
  return record(event) && record(event.output) ? event.output : undefined;
}
function actorError(event: unknown): unknown {
  return record(event) ? event.error : undefined;
}
function validText(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}
function accepted(event: unknown, guard: string, field: string): boolean {
  const value = output(event);
  return value?.guard === guard && validText(value[field]);
}
function clearBossReplyContext(context: Context): Context {
  delete context.pendingBossQuestion;
  delete context.bossReply;
  return { ...context };
}
function setPendingBossQuestion(context: Context, event: unknown): Context {
  const value = output(event);
  if (!value || typeof value.question !== 'string') return context;
  return {
    ...clearBossReplyContext(context),
    pendingBossQuestion: { questionId: 'generate', resumeStateId: 'generate', sourceItem: 'flow-5',
      asker: { kind: 'role', roleId: '提交说明作者' }, question: value.question },
  };
}
function bossInterrupts(ids: readonly JumpId[]) {
  return ids.map(id => ({
    target: `#${id}`, reenter: true,
    guard: ({ context, event }: { context: Context; event: MachineEvent }) =>
      event.type === 'BOSS_INTERRUPT' && event.targetId === id &&
      (id !== 'generate' || validText(context.taskFilePath)),
    actions: 'clearReply' as const,
  }));
}
function resumableStates(ids: readonly ['generate']) {
  return ids.map(id => ({
    target: `#${id}`,
    guard: ({ context, event }: { context: Context; event: MachineEvent }) =>
      event.type === 'BOSS_REPLY' && validText(event.answer) &&
      context.pendingBossQuestion?.resumeStateId === id &&
      (event.questionId === undefined || event.questionId === context.pendingBossQuestion.questionId),
    actions: 'rememberReply' as const,
  }));
}
function metadata(stateId: string, description: string) {
  return { playbook: { stateId, description } };
}
const entry = {
  target: '#generate',
  guard: 'validEntry', actions: 'startTask',
} as const;
export const machine = setup({
  types: {
    context: {} as Context, events: {} as MachineEvent,
    input: {} as MachineInput, output: {} as MachineOutput,
  },
  actors: {
    player: fromPromise<PlayerOutput, PlayerInput>(async () => {
      throw new Error('player actor must be provided by the runner');
    }),
  },
  guards: {
    validEntry: ({ event }) => event.type === 'GENERATE' && validText(event.taskFilePath),
    generated: ({ event }) => accepted(event, 'generated', 'message'),
    unable: ({ event }) => accepted(event, 'unable', 'reason'),
    needsBossReply: ({ event }) => accepted(event, 'needsBossReply', 'question'),
  },
  actions: {
    'playbook.acceptedOutcome': (_, _params: { source: string; target: string; acceptedOutcome: string }) => {},
    startTask: assign(({ event }) => event.type === 'GENERATE' ? { taskFilePath: event.taskFilePath } : {}),
    clearReply: assign(({ context }) => clearBossReplyContext(context)),
    askBoss: assign(({ context, event }) => setPendingBossQuestion(context, event)),
    rememberReply: assign(({ event }) => event.type === 'BOSS_REPLY' ? { bossReply: event.answer } : {}),
    saveMessage: assign(({ event }) => {
      const value = output(event);
      return value && typeof value.message === 'string' ? { terminalOutput: { message: value.message } } : {};
    }),
    saveReason: assign(({ event }) => {
      const value = output(event);
      return value && typeof value.reason === 'string' ? { terminalOutput: { reason: value.reason } } : {};
    }),
    malformed: assign({ lastError: () => ({ name: 'InvalidResult', message: 'Malformed player output or Boss reply.' }) }),
    rememberError: assign(({ event }) => {
      const error = actorError(event);
      return { lastError: error instanceof Error
        ? { name: error.name, message: error.message, ...(error.stack ? { stack: error.stack } : {}) }
        : { name: 'ActorError', message: String(error) } };
    }),
  },
}).createMachine({
  id: 'flow', initial: 'ready',
  context: ({ input }) => ({ taskFilePath: input?.taskFilePath ?? '' }),
  output: ({ context }) => {
    if (!context.terminalOutput) throw new Error('No terminal output');
    return context.terminalOutput;
  },
  on: { BOSS_INTERRUPT: bossInterrupts(['ready', 'generate', 'failed']) },
  states: {
    ready: {
      id: 'ready', description: '等待提交说明任务。', tags: 'playbook.parked',
      meta: metadata('ready', '等待提交说明任务。'),
      on: { GENERATE: entry },
    },
    generate: {
      id: 'generate', description: '生成提交说明。', tags: 'playbook.busy',
      meta: { playbook: { stateId: 'generate', description: '生成提交说明。', role: '提交说明作者' } },
      invoke: {
        src: 'player',
        input: ({ context }): PlayerInput => ({
          stateId: 'generate', sourceItem: 'flow-5', role: '提交说明作者', prompt,
          taskFilePath: context.taskFilePath,
          ...(context.pendingBossQuestion ? { pendingBossQuestion: context.pendingBossQuestion } : {}),
          ...(context.bossReply !== undefined ? { bossReply: context.bossReply } : {}),
          result: {
            generated: '已成功生成提交说明。Output shall include `message: <完整代码块字符串>`.',
            unable: '任务文件或引用的输入无法读取，或资料不足以生成说明。Output shall include `reason: <说明具体限制的字符串>`.',
            needsBossReply: "The acting agent's prose surfaces a clarifying question for Boss that the agent cannot answer alone. Output shall include `question: <verbatim question text from the acting agent's prose>`.",
          },
        }),
        onDone: [
          { guard: 'generated', target: '#generated', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'generate', target: 'generated', acceptedOutcome: 'generated' } },
            'saveMessage', 'clearReply',
          ] },
          { guard: 'unable', target: '#unable', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'generate', target: 'unable', acceptedOutcome: 'unable' } },
            'saveReason', 'clearReply',
          ] },
          { guard: 'needsBossReply', target: '#awaitBossReply', actions: [
            { type: 'playbook.acceptedOutcome', params: { source: 'generate', target: 'awaitBossReply', acceptedOutcome: 'needsBossReply' } },
            'askBoss',
          ] },
          { target: '#failed', actions: ['malformed', 'clearReply'] },
        ],
        onError: { target: '#failed', actions: ['rememberError', 'clearReply'] },
      },
    },
    awaitBossReply: {
      id: 'awaitBossReply', description: "Waiting for Boss to answer the acting agent's question.", tags: 'playbook.parked',
      meta: metadata('awaitBossReply', "Waiting for Boss to answer the acting agent's question."),
      on: {
        BOSS_REPLY: [...resumableStates(['generate']), { target: '#failed', actions: ['malformed', 'clearReply'] }],
        GENERATE: { ...entry, actions: ['clearReply', 'startTask'] },
      },
    },
    failed: {
      id: 'failed', description: '执行错误，等待 Boss 恢复。', tags: 'playbook.parked',
      meta: metadata('failed', '执行错误，等待 Boss 恢复。'),
      on: { GENERATE: { ...entry, actions: ['clearReply', 'startTask'] } },
    },
    generated: {
      id: 'generated', type: 'final', description: '已生成',
      meta: { playbook: { stateId: 'generated', description: '已生成', terminal: 'success' } },
    },
    unable: {
      id: 'unable', type: 'final', description: '无法生成',
      meta: { playbook: { stateId: 'unable', description: '无法生成', terminal: 'failure' } },
    },
  },
});
export default machine;
