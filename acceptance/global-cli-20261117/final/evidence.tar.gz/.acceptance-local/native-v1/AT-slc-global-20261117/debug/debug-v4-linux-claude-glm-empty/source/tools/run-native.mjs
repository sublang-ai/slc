// Transport wrapper: the tested compiler always runs on the named native OS.
import {spawn} from 'node:child_process';
import {readFile,writeFile,mkdir,cp} from 'node:fs/promises';
import {join,dirname} from 'node:path';
const root='/Users/boboyang/work/sublang.ai/slc-global-delivery-20261117';
const [mode,cid]=process.argv.slice(2);if(!['debug','formal'].includes(mode)||!/^TC-local-(macos|linux|windows)-(codex|claude-glm)-[a-z-]+$/.test(cid))throw Error('Explicit native case required');
const os=cid.split('-')[2],label=mode+'-'+cid,configPath=join(root,'evidence/native-configs-04',label+'.json'),cfg=JSON.parse(await readFile(configPath,'utf8'));
let stdout='',stderr='';async function run(executable,args){const child=spawn(executable,args,{stdio:['ignore','pipe','pipe']});child.stdout.on('data',d=>stdout+=d);child.stderr.on('data',d=>stderr+=d);return new Promise(r=>{child.on('error',e=>r({exitCode:null,error:String(e)}));child.on('close',(exitCode,signal)=>r({exitCode,signal}));});}
const started=new Date().toISOString(),tick=performance.now();let result;
if(os==='macos')result=await run(process.execPath,[join(root,'tools/native-case.mjs'),configPath]);
else {
 const host=os==='linux'?'bobo@192.168.1.17':'boboy@192.168.1.30',remote='slc-global-delivery-20261117/tools/'+label+'.json';
 const copied=await run('scp',['-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',configPath,host+':'+remote]);
 if(copied.exitCode!==0)result=copied;
 else {
 let command;
 if(os==='linux')command='export PATH="$HOME/slc-global-delivery-20261117/tools/node-v25.5.0-linux-x64/bin:$PATH"; node "$HOME/slc-global-delivery-20261117/tools/native-case.mjs" "$HOME/'+remote+'"';
 else {const ps="$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new();$env:PATH=$HOME+'\\slc-global-delivery-20261117\\tools\\node-v25.5.0-win-x64;'+$env:PATH; & ($HOME+'\\slc-global-delivery-20261117\\tools\\node-v25.5.0-win-x64\\node.exe') ($HOME+'\\slc-global-delivery-20261117\\tools\\native-case.mjs') ($HOME+'\\"+remote.replaceAll('/','\\')+"'); exit $LASTEXITCODE";command='powershell.exe -NoProfile -NonInteractive -EncodedCommand '+Buffer.from(ps,'utf16le').toString('base64');}
 result=await run('ssh',['-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',host,command]);
 const dest=join(root,'evidence/native-04');await mkdir(dest,{recursive:true});
 const collected=await run('scp',['-r','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',host+':slc-global-delivery-20261117/evidence/native-04/'+label,dest+'/']);if(collected.exitCode!==0)result={...result,collectionFailure:collected};
 }
}
const out=join(root,'evidence/native-transport-04');await mkdir(out,{recursive:true});await writeFile(join(out,label+'.stdout.log'),stdout);await writeFile(join(out,label+'.stderr.log'),stderr);await writeFile(join(out,label+'.json'),JSON.stringify({mode,caseId:cid,nativeOS:os,startedAt:started,finishedAt:new Date().toISOString(),elapsedMs:Math.round(performance.now()-tick),...result},null,2));if(process.env.ACCEPTANCE_EVIDENCE_DIR){const attachment=join(process.env.ACCEPTANCE_EVIDENCE_DIR,'native-case');try{await cp(join(root,'evidence/native-04',label),attachment,{recursive:true});}catch(error){await writeFile(join(process.env.ACCEPTANCE_EVIDENCE_DIR,'collection-error.txt'),String(error));result.collectionFailure=String(error);}await cp(join(out,label+'.json'),join(process.env.ACCEPTANCE_EVIDENCE_DIR,'transport.json'));}
process.stdout.write(stdout);process.stderr.write(stderr);process.exitCode=result.exitCode===0&&!result.collectionFailure?0:1;
