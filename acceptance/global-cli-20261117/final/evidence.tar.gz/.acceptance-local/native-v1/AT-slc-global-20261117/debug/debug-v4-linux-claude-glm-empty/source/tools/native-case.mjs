import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { cp, mkdir, readFile, writeFile, readdir, lstat, readlink, realpath, symlink } from 'node:fs/promises';
import { dirname, join, resolve, relative } from 'node:path';
import { homedir, platform, release, arch } from 'node:os';
import { pathToFileURL } from 'node:url';
const config=JSON.parse(await readFile(process.argv[2],'utf8'));
const cohortDigest='d98865e1b2463092844cbcafd454209a37941b2f94639ad690bd27c49fae56b2';
const frozenSource='af0a67466cfb4d5efb79caee263ee433ebc6a9fc7090cd6fbb071a1a998ab969';
const osName={darwin:'macos',linux:'linux',win32:'windows'}[process.platform];
const parents=['empty','commonjs','esm-git','compatible-runtime','missing-runtime','conflicting-runtime','ambient-types','spaces-chinese'];
if(!['local','registry'].includes(config.layer)||!['codex','claude-glm'].includes(config.backend)||!parents.includes(config.parent))throw Error('Unknown acceptance variant');
const expectedCase=`TC-${config.layer==='local'?'local':'registry-smoke'}-${osName}-${config.backend}-${config.parent}`;
if(config.caseId!==expectedCase||config.expectedPlatform!==process.platform)throw Error('TC identity or required native platform mismatch');
if(config.layer==='registry'&&!['empty','commonjs'].includes(config.parent))throw Error('Unexpected registry smoke variant');
if(!config.expectedVersions||!config.expectedCliSHA256||!config.toolchainPrefix||['@sublang/slc','@sublang/cligent','@sublang/playbook'].some(name=>typeof config.expectedVersions[name]!=='string'))throw Error('Frozen candidate identity required');

const sha=b=>createHash('sha256').update(b).digest('hex');
const privateRoot=resolve(homedir(),'.cache/slc-global-delivery-20261117');
const out=resolve(config.output); await mkdir(out,{recursive:true});
const parent=resolve(config.work);await mkdir(parent,{recursive:true});
if((await readdir(parent)).length)throw Error('Refusing nonempty fixture directory '+parent);
const cli=resolve(config.cli);const req=createRequire(cli);
const physicalCli=await realpath(cli),prefix=await realpath(config.toolchainPrefix);
const cliRelative=relative(prefix,physicalCli);
if(cliRelative==='..'||cliRelative.startsWith('..\\')||cliRelative.startsWith('../')||resolve(prefix,cliRelative)!==physicalCli)throw Error('CLI escapes candidate installation');
if(sha(await readFile(cli))!==config.expectedCliSHA256)throw Error('Installed CLI does not match frozen candidate');
const cohortBytes=await readFile(config.cohort);if(sha(cohortBytes)!==cohortDigest)throw Error('Untrusted candidate cohort');
const cohort=JSON.parse(cohortBytes);
const installedPackages={};
for(const [name,version] of Object.entries(config.expectedVersions)){
 let entry;
 if(name==='@sublang/slc')entry=physicalCli;else if(name==='@sublang/cligent'){for(const base of req.resolve.paths(name)??[]){try{const path=join(base,name,'package.json');const info=JSON.parse(await readFile(path,'utf8'));if(info.name===name){entry=path;break;}}catch(error){if(error.code!=='ENOENT')throw error;}}if(!entry)throw Error('Missing installed Cligent');}else entry=req.resolve('@sublang/playbook/artifact-environment');
 let directory=dirname(entry);
 for(;;){
  try{const pkg=JSON.parse(await readFile(join(directory,'package.json'),'utf8'));if(pkg.name===name){if(pkg.version!==version)throw Error('Wrong candidate version '+name);installedPackages[name]={version:pkg.version,root:await realpath(directory)};break;}}catch(error){if(!['ENOENT','ENOTDIR'].includes(error.code))throw error;}
  const next=dirname(directory);if(next===directory)throw Error('Cannot locate installed '+name);directory=next;
 }
 const rel=relative(prefix,installedPackages[name].root);if(rel==='..'||rel.startsWith('../')||rel.startsWith('..\\'))throw Error('Package escapes acquired tree '+name);
}

for(const [name,pkg] of Object.entries(installedPackages)){
 const frozen=cohort.packages[name];if(!frozen||pkg.version!==frozen.version)throw Error('Version outside frozen cohort '+name);
 for(const [file,digest] of Object.entries(frozen.files)){const actual=sha(await readFile(join(pkg.root,file)));if(actual!==digest)throw Error('Installed packed bytes differ: '+name+'/'+file);}
 pkg.verifiedPackedFiles=Object.keys(frozen.files).length;pkg.tarballSHA256=frozen.tarballSHA256;
}
const envService=await import(pathToFileURL(req.resolve('@sublang/playbook/artifact-environment')).href);
const selected=await envService.inspectArtifactEnvironment();
const copyOptions=source=>({recursive:true,filter:p=>!relative(source,p).split(/[\\/]/).includes('node_modules')});
const put=async(path,value)=>{await mkdir(dirname(path),{recursive:true});await writeFile(path,value);};
if(['commonjs','spaces-chinese'].includes(config.parent))await put(join(parent,'package.json'),'{"type":"commonjs"}\n');
if(config.parent==='esm-git'){
 await put(join(parent,'package.json'),'{"type":"module"}\n');
 if(config.gitTemplate){await cp(join(config.gitTemplate,'.git'),join(parent,'.git'),{recursive:true});await put(join(out,'fixture-git.json'),JSON.stringify({operation:'copy actual git-init fixture',source:config.gitTemplate}));}else await invoke('git',['init','--quiet'],parent,process.env,'fixture-git');
}
if(config.parent==='missing-runtime')await put(join(parent,'package.json'),JSON.stringify({type:'commonjs',dependencies:{'@sublang/playbook':'999.0.0',xstate:'0.0.0'}}));
if(config.parent==='conflicting-runtime'){
 await put(join(parent,'package.json'),'{"type":"commonjs","dependencies":{"xstate":"0.0.0","@sublang/playbook":"0.0.0"}}');
 for(const name of ['xstate','@sublang/playbook']){
  await put(join(parent,'node_modules',name,'package.json'),JSON.stringify({name,version:'0.0.0',main:'index.js'}));
  await put(join(parent,'node_modules',name,'index.js'),"throw Error('PARENT RUNTIME MUST NOT LOAD');");
 }
}
if(config.parent==='compatible-runtime'){
 await put(join(parent,'package.json'),JSON.stringify({type:'module',dependencies:{'@sublang/playbook':selected.playbook.version,xstate:selected.xstate.version}}));
 await cp(selected.playbook.root,join(parent,'node_modules/@sublang/playbook'),copyOptions(selected.playbook.root));
 await cp(selected.xstate.root,join(parent,'node_modules/xstate'),copyOptions(selected.xstate.root));
 const ownerRequire=createRequire(join(selected.playbook.root,'package.json'));
 const packageInfo=JSON.parse(await readFile(join(selected.playbook.root,'package.json'),'utf8'));
 for(const name of Object.keys(packageInfo.dependencies)){
  if(name==='xstate')continue;
  let located=dirname(ownerRequire.resolve(name));
  for(;;){
   try{if(JSON.parse(await readFile(join(located,'package.json'),'utf8')).name===name)break;}catch{}
   const next=dirname(located);if(next===located)throw Error('Unable to locate fixture dependency '+name);located=next;
  }
  const destination=join(parent,'node_modules',name);await mkdir(dirname(destination),{recursive:true});
  await symlink(located,destination,process.platform==='win32'?'junction':'dir');
 }
 const parentEngine=await import(pathToFileURL(join(parent,'node_modules/@sublang/playbook/src/xstate-runtime.js')).href);
 if(parentEngine.RUNTIME_ABI!==selected.runtimeAbi)throw Error('Compatible parent fixture is not operational');
 // Parent contains distinct physical runtime code, never an alias of the selected pair.
}
if(config.parent==='ambient-types'){
 await put(join(parent,'package.json'),'{"type":"commonjs"}');
 await put(join(parent,'tsconfig.json'),JSON.stringify({compilerOptions:{module:'CommonJS',target:'ES5',types:['broken-parent-type'],noEmit:true},include:['**/*']}));
 await put(join(parent,'node_modules/@types/broken-parent-type/index.d.ts'),'declare const contradictory: NEVER_DECLARED_PARENT_TYPE;');
}
const child=join(parent,config.parent==='spaces-chinese'?'空 工作目录':'child');
for(let directory=parent;;directory=dirname(directory)){if(directory!==parent&&['empty','spaces-chinese','missing-runtime'].includes(config.parent)){try{await lstat(join(directory,'package.json'));throw Error('Unexpected ancestor project manifest '+directory);}catch(error){if(error.code!=='ENOENT')throw error;}}if(dirname(directory)===directory)break;}
const before=await inventory(parent);
await mkdir(child);
if((await readdir(child)).length)throw Error('Child was not empty');
const source=await readFile(config.source);if(sha(source)!==frozenSource)throw Error('Input differs from frozen workflow definition');await writeFile(join(child,'flow.md'),source);
const cleanEnv={...process.env};for(const key of Object.keys(cleanEnv))if(key.startsWith('SLC_'))delete cleanEnv[key];
const env={...cleanEnv,XDG_CONFIG_HOME:join(privateRoot,'xdg-config'),SLC_AGENT:config.backend==='claude-glm'?'claude-code':'codex',SLC_MODEL:config.backend==='claude-glm'?'glm-5.3':'gpt-6.1-sol',SLC_SUBAGENT_MODEL:'inherit',SLC_STALL_TIMEOUT:'900',SLC_PIPELINE_PATH:child,SLC_COVERAGE_MAX_INVOCATIONS:'8',SLC_COVERAGE_MAX_ATTEMPTS:'64',SLC_COVERAGE_MAX_DURATION_MS:'300000'};
for(const k of Object.keys(env))if(k.startsWith('SLC_REVIEWER_'))delete env[k];
if(config.backend==='claude-glm'){
 for(const key of Object.keys(env))if(key.startsWith('ANTHROPIC_')||['CLAUDE_CODE_OAUTH_TOKEN','CLAUDE_CODE_USE_BEDROCK','CLAUDE_CODE_USE_VERTEX','CLAUDE_CODE_USE_FOUNDRY'].includes(key))delete env[key];
 const dir=join(privateRoot,'claude-config');await mkdir(dir,{recursive:true});await put(join(dir,'settings.json'),'{}');
 Object.assign(env,{CLAUDE_CONFIG_DIR:dir,ANTHROPIC_AUTH_TOKEN:(await readFile(join(privateRoot,'secrets/glm-token'),'utf8')).trim(),ANTHROPIC_BASE_URL:'https://open.bigmodel.cn/api/anthropic',ANTHROPIC_MODEL:'glm-5.3',ANTHROPIC_DEFAULT_OPUS_MODEL:'glm-5.3',ANTHROPIC_DEFAULT_SONNET_MODEL:'glm-5.3',ANTHROPIC_DEFAULT_HAIKU_MODEL:'glm-5.3'});
}else {for(const key of ['OPENAI_API_KEY','CODEX_API_KEY','CODEX_ACCESS_TOKEN'])delete env[key];if(!config.codexHome)throw Error('Isolated Codex login home required');env.CODEX_HOME=resolve(config.codexHome);}
const identity={cohortSHA256:cohortDigest,schema:'slc.native-case.v1',caseId:config.caseId,layer:config.layer,platform:platform(),osRelease:release(),arch:arch(),node:process.version,sourceSHA256:sha(source),selected,cli,installedPackages,cliSHA256:sha(await readFile(cli)),environment:Object.fromEntries(Object.entries(env).filter(([k])=>k.startsWith('SLC_')||['ANTHROPIC_BASE_URL','ANTHROPIC_MODEL','CODEX_HOME','CLAUDE_CONFIG_DIR','XDG_CONFIG_HOME'].includes(k))),parent:config.parent,child,emptyBeforeCopy:true,parentBefore:before};
await put(join(out,'identity.json'),JSON.stringify(identity,null,2));
const compilation=await invoke(process.execPath,[cli,'playbook','flow.md'],child,env,'compile');

let gates=null, failure=null;
if(compilation.exitCode===0){
 try{
 const entry=join(child,'flow.mjs');const manifest=await envService.validateArtifactManifest(entry);
 if(!manifest)throw Error('Missing accepted managed manifest');
 const check=await invoke(process.execPath,[cli,'check','entry',entry,join(child,'flow.playbook/flow.fsm.ts')],child,env,'independent-entry-check');
 if(check.exitCode!==0)throw Error('Independent entry init/dispose failed');
 const rootNames=await readdir(child);
 if(rootNames.some(n=>['package.json','package-lock.json','tsconfig.json','node_modules','.git'].includes(n)))throw Error('Unexpected root project/Git file');
 const links={};for(const name of ['xstate','@sublang/playbook'])links[name]=await realpath(join(child,'flow.playbook/node_modules',name));
 if(links.xstate!==selected.xstate.root||links['@sublang/playbook']!==selected.playbook.root)throw Error('Actual runtime link differs from selected pair');
 gates={manifestSHA256:sha(await readFile(join(child,'flow.playbook/build-manifest.json'))),entrySHA256:sha(await readFile(entry)),files:manifest.files,links,rootNames,entryCheck:check};
 }catch(e){failure=String(e.stack||e);}
}
const after=await inventory(parent,child);const parentUnchanged=JSON.stringify(before)===JSON.stringify(after);
if(!parentUnchanged)failure=(failure||'')+' Parent fixture changed';
if(sha(await readFile(join(child,'flow.md')))!==frozenSource)failure=(failure||'')+' Source changed during compile or independent check';
const result={...identity,compilation,parentAfter:after,parentUnchanged,gates,failure,status:compilation.exitCode===0&&gates&&!failure?'passed':'failed',finishedAt:new Date().toISOString()};
try{await cp(child,join(out,'workspace'),{recursive:true,dereference:false,filter:path=>!relative(child,path).split(/[\\/]/).includes('node_modules')});await put(join(out,'archive-method.json'),JSON.stringify({excluded:'runtime node_modules links only',reason:'replay reconstructs the recorded owned links through the public environment service; native Windows archive does not require symlink privileges',originalWorkspace:child,links:gates?.links??null}));}catch(error){result.status='failed';result.failurePhase='evidence-archive';result.failure=String(error.stack||error);}
await put(join(out,'result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({caseId:config.caseId,status:result.status,elapsedMs:compilation.elapsedMs,exitCode:compilation.exitCode,failure}));
process.exitCode=result.status==='passed'?0:1;
async function inventory(dir,excluded){
 const records={};
 async function visit(path){if(path===excluded)return;const info=await lstat(path);const key=relative(dir,path).replaceAll('\\','/');if(info.isSymbolicLink())records[key]={link:await readlink(path)};else if(info.isDirectory())for(const name of (await readdir(path)).sort())await visit(join(path,name));else records[key]={sha256:sha(await readFile(path)),size:info.size};}
 await visit(dir);return records;
}
async function invoke(executable,args,cwd,environment,name){
 const start=new Date().toISOString(),tick=performance.now();let stdout='',stderr='';const childProcess=spawn(executable,args,{cwd,env:environment,stdio:['ignore','pipe','pipe']});
 childProcess.stdout.on('data',c=>stdout+=c);childProcess.stderr.on('data',c=>stderr+=c);
 const outcome=await new Promise(resolve=>{childProcess.once('error',e=>resolve({exitCode:null,error:String(e)}));childProcess.once('close',(exitCode,signal)=>resolve({exitCode,signal}));});
 // Provider credentials are read only into env. Redact any unexpected process echo.
 const secrets=Object.entries(environment).filter(([k,v])=>/TOKEN|PASSWORD|SECRET|API_KEY/.test(k)&&v?.length>12).map(([,v])=>v);
 for(const secret of secrets){stdout=stdout.replaceAll(secret,'[REDACTED]');stderr=stderr.replaceAll(secret,'[REDACTED]');}
 await put(join(out,name+'.stdout.log'),stdout);await put(join(out,name+'.stderr.log'),stderr);
 const record={executable,args,cwd,startedAt:start,finishedAt:new Date().toISOString(),elapsedMs:Math.round(performance.now()-tick),...outcome,stdoutSHA256:sha(stdout),stderrSHA256:sha(stderr)};
 await put(join(out,name+'.json'),JSON.stringify(record,null,2));return record;
}
