# Compiler implementation v3 / execution-readiness re-review

- Acceptance ID: `AT-slc-global-20261117`。Independent Reviewer: `/root/slc_impl_review`。
- 结论：**needs_revision**。当前 Source 中仍有三个已实证的 P1；SC3 的具体化及 native-case 的多项冻结身份检查是有效进展，但不能据此开始授予正式 native/registry/CI 通过。
- 这是实现与执行前设计复核，不是正式执行/需求交付复审。只写本意见；未改任何产品代码或规格、未发起付费 Agent、未把 LAN registry 作为公共发布的替代通过证据。
- 原始依据：两仓库 AGENTS.md 与 `verification-72/-73/-74/-79/-80`、`standalone-compilation`、`artifact-environment`、`delivery-acceptance`；冻结 baseline/TEST-METHOD，以及 app-delivery-acceptance-native 的独立设计边界要求。

## 本次实际运行的源码版本

没有仅凭当前 dist 的存在或时间戳声称实测最新源码。用 `/tmp/slc-v3-freeze.mjs` 将本轮读取的 SLC **全部 src TypeScript** 转译到 `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-DCCAvF/dist`，从原安装树解析依赖；独立反例导入该目录的 `isolated-check.js / verification-worker.js / verify-coverage.js`。原始文件摘要在 `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-DCCAvF/source-identity.json`。使用的是安装中的 TypeScript 的 transpileModule，未变更产品目录。终稿时与 live src 比较的变化文件为 `['managed-compilation.ts', 'verify-coverage.ts']`。

这份临时快照用于小型实际 checker 行为，**不是完整 distributable**：一次探索性的完整 runSlc 因快照未生成 `.d.ts` verifier-support 文件而遇到 `hash.d.ts ENOENT`，归为复现环境缺项，不是产品失败，也不用于本意见的通过证明。下列四组直接 checker 复现不依赖该缺项且均实际执行。

## S1 · P1：reserved-key 过滤不证明 nonempty witness.input 为 Source 所允许

位置：`slc/src/verify-coverage.ts` 的 `readCoverageWitnesses`（约 6004–6028 行）和 makeActor 的 `input: { ...coverageMachineInput(machine), ...publicInput }`（约 1070 行）。

旧 `input.enabledPlaybooks` 反例已拒绝，但仍允许任意其它 JSON 启动参数。生成 FSM 自身可以把重命名或嵌套选项映射为 catalog/私有状态；没有独立 Source option-validator 时，字段黑名单与 merge compiler defaults 都不能建立权限来源。

**实际反例** `/tmp/slc-v3-renamed-witness.mjs`：与 v2 相同，只有 literal `configured-child` 被声明，guard 还错误要求 `undeclared-child`。本次将初始化改为 `input.startupSettings?.allowedChildren?.map(id => ({id})) ?? input.enabledPlaybooks`，witness 改为 `{input:{startupSettings:{allowedChildren:['configured-child','undeclared-child']}},events:[]}`。当前源码检查仍是 **baseline 四项 findings → witness []**。没有覆写任何保留顶层 key，也没有私有跳转；伪造的 authority 通过了当前初始化代码。

这违反 `verification-74` 的 Source-permitted startup options / never fabricated enabled targets。顶层字段重命名不是纯增加等价样本：它进入黑名单以外的真实实现分支，且实际把违反契约的结果接受了。

**最小合法边界建议**：本轮没有独立、可追溯到 Source 的启动选项契约时，仅允许缺省/空 `input`；对任何 nonempty witness.input 明确返回 **unverified: unsupported Source-permitted startup-option proof**，不宣称 artifact 语义错误。继续允许本次已有依据的 events-only 合法绝对路径初始 replay，保留 compiler-owned host input。不要为了让 witness 通过而发明 domain defaults、允许任意字段，或把同一生成 FSM 自声明的 validator 当独立 Source 证据。未来确有 Source-derived trusted contract 时再验证非空切片，并记录契约及允许值的 provenance。

应保留 malformed JSON/private authority 的具体 artifact finding 与 unsupported-permission-proof 的 unverified 区别；不要简单让一个 generic catch 把所有不支持的输入包装成“invalid artifact”。

## S2 · P1：候选普通 IPC 消息会冒充完成的独立 lifecycle 报告

位置：`slc/src/isolated-check.ts:129-145`、`verification-worker.ts:246-250`。

父进程只接一次 message，任意不含 truthy error 的对象都走 `end(undefined,value.findings)`；缺少 findings 时 `resolve(result ?? [])` 把它转为成功。被检查候选和 checker 又共享可见的 `process.send`。

**实际反例** `/tmp/slc-v3-ipc.mjs`：候选 entry 顶层正常发送 `process.send({kind:'runtime-loaded'})`，factory 明确 `throw Error('constructor must fail')`。当前源码 `isolatedCheck('lifecycle',...)` 返回 **[]**；删除同一候选的普通 IPC 行后，返回 **artifact: entry lifecycle failed: constructor must fail**。第二次对照证明并非候选本身可初始化，第一次是抢先消息触发 checker 成功并终止子进程。临时根 `.../T/slc-v3-ipc-IEYFeV/`。

这破坏 `verification-72/-79` 的独立当前字节检查及实际初始化/释放证明，可能导致 manifest 把根本未完成的 lifecycle 标为 passed。

最小修订：协议必须严格验证 job、schema、findings/errors 的数据类型和完成阶段，未知/缺字段消息不得成功；同时让候选不可取得 checker IPC capability，例如报告器在加载候选前闭包捕获原始 send 并从候选可见 process 移除该能力。仅加一个候选同样能发送的公开 envelope 不足以建立独立来源。必须有上述额外普通消息 + 必失败 factory 的控制反例，确认不可能提前通过。

## S3 · P1：native permission 安全性不能外推到 engines >=23.6 的全部范围

位置：`slc/src/isolated-check.ts:56-60`、`verification-worker.ts` 的网络 monkeypatch、`slc/package.json` 的 `node: >=23.6`。

Node 25.5 的本机测试确实能拒绝 direct network，但旧版本的权限资源能力不同；现有 wrapper 只替换 net.connect/createConnection，未覆盖原生 `new net.Socket().connect()`，也未在候选 import 前检查所需 native network restriction 是否存在。

**实际对照** `/tmp/slc-v3-network.mjs`：仅启动本机 `127.0.0.1` 临时服务，不向外部服务发请求。候选 init 通过 `new Socket().connect()` 写 `BUSINESS_WRITE`。

- Node **v25.5.0**：返回 `artifact: entry lifecycle failed: connect ERR_ACCESS_DENIED ... --allow-net ...`；loopback service received **[]**。
- Node **v23.6.0**（仍符合声明的最低版本）：同一源码快照/同一反例，lifecycle findings **[]**；loopback service 实际收到 **['BUSINESS_WRITE']**。临时根 `.../T/slc-v3-network-UdEq8o/`。

为排除机器上不明 Node 来源，本次从 Node 官方 distribution 下载 exact darwin-arm64 v23.6.0 并对照官方 [SHASUMS256](https://nodejs.org/dist/v23.6.0/SHASUMS256.txt) 校验，archive SHA 为 `764857a0ab3cb956f16baeb05f89007d9ee1d9daa70c98d45005da0a35e769a0`；二进制位于 `/tmp/slc-v3-node23/node-v23.6.0-darwin-arm64/bin/node`。这里结论以真实双版本行为为准，并未根据最新版 [Node permission 文档](https://nodejs.org/api/cli.html#--allow-net) 推定旧版也具有同样资源。

修订要求：在任何候选加载前 feature-preflight 所需 native 权限资源；缺少可证明的网络禁止能力则返回 environment/unverified 并给出实际 runtime/remedy，不能继续宣称 safe lifecycle。若改 Node 支持范围，需 spec/package/docs 同步后再验收。正式矩阵当前选择 Node25.5，不能掩盖产品仍对更宽 declared supported runtime 作出的安全初始化承诺。

## 已修与已独立通过的有限范围

1. **原 I1 direct filesystem mutation 在 Node25.5 已修**：`/tmp/slc-v3-native-writes.mjs` 实际分别在 construct/init/dispose 调 `writeFileSync(Source)`，三者均为 artifact restricted finding，Source 均保留 `original Source`；同样入口的 inert control findings=[]。临时根 `.../T/slc-v3-native-writes-igP6FL/`。protected watcher 的新增源码也已打开核对。主 Agent 的 `/tmp/slc-init-write-fixed16.log` 另提供完整 runSlc 无 latest 的开发证据；本次独立通过限上述当前源码直接 lifecycle 检查，不扩大为全流程正式通过。
2. **原 I2 的固定顶层 authority 反例已修**：已读 `/tmp/slc-witness-fixed16.log` 和永久测试；当前 blacklist 能拒绝 enabledPlaybooks/context 等字段，但不等同 S1 的 Source permission 已成立。
3. 旧 v2 已确认的 CommonJS closure/freshness/actual importer pair 与 `-o` 结论未在本轮被新证据推翻；本轮没有重新授予全量包回归通过。

## SC3 v3 设计与 harness 的单独结论

已实际读 `evidence/design/SC3.json` 的 15 条 TC 及 `REVISION-v3.md`。v2 的泛化四条已拆为可操作的具体前状态/动作/预期；旧 TC→新 TC 的映射已记录且没有重标实际执行。这解决了 v2 D1 的主要设计形态缺陷。

- `TC-gates-types/pair/cjs`、`TC-source-returns`、`TC-public-path`、`TC-init-required`、`TC-occupied`、`TC-markers`、`TC-reuse`、`TC-rollback`、`TC-layout`、`TC-archives` 的当前自然语言范围能从 baseline/spec/TEST-METHOD 推出；**只确认设计依据与边界，不确认它们已有匹配实现或已调试通过**。
- `TC-witness-authority` 仍应以本次已知失败补上 renamed/nested nonempty input、unsupported Source-proof 的分类及 events-only 正控；否则 exact reserved-key 修复能全过其当前具体样例而违反原承诺。
- `TC-init-effects` 应补 ordinary/伪造 IPC 不能替代真实报告，以及 declared runtime boundary 的直接 network mutation 控制；这两种已实际失败，原文件写入/host-port 样例不能等价覆盖。
- `TC-budget` expected 明确包括 canceled/crashed 的独立分类，但 action 仅写 small→large budget 与 invalid artifact；请显式安排取消/崩溃的触发操作和清理观察面，或引用已绑定的实际验证项，不能只在 expected 里声明覆盖。
- 因此设计仍有上述具体需修订范围（revision_target: design），其余不能被本轮 blanket 判为执行 passed。SC1/SC2/SC4 仍是既有 v2，`REVISION-v3.md` 也明确 executable bindings/formal reviews pending；本次没有撤销 v2 对其未完成绑定/独立复审的待办。

`native-case.mjs` 已补有效的 TC OS/layer/backend/parent 绑定、frozen Source SHA、三包版本/CLI SHA/树内 root 校验、隔离配置，以及独立 lifecycle 之后才做 Source/parent 复核和归档。独立运行 `/tmp/slc-v3-wrong-tc.json`（Windows TC 在本机）已在任何编译前被 `TC identity or required native platform mismatch` 拒绝，v2 对这一具体问题可以关闭。

但终稿读取的 harness **仍只有 top-level cli.js digest + package versions**，没有完整 packed-file baseline anchor/比较；修改其它 dist JS 而保持 cli.js/version 不变不会被这些身份 guard 独立拒绝。主 Agent 已明确该 anchor 正在添加，本意见将其列为执行准备待完成，**不是假定它已生效**。所有 candidate packed files 的独立冻结摘要、实际 installed bytes 校验及 native SDK/组件来源证据完善并匹配后，才能给相应 implementation readiness 通过。还需实际 npm/native shell/SDK/native runtime provenance；不能仅靠输入的 expectedVersions 表来证明其来自指定候选。

## 发布与运行证据边界

当前声明候选版本为 SLC `0.23.0-rc.3` / Playbook `19.1.0-rc.3` / Cligent `0.40.0-rc.2`；实际文件摘要在下方。公共候选发布/merge 被未补丁 development picomatch audit 阻塞这一事实已按交接保留，本轮没有替代安全判断、放宽 gate 或授予公共 registry/CI 通过。LAN registry 的 isolated production acquisition 可另记有限替代证据，不能把它描述为公共发布/完整交付通过。Source regressions、pins refresh 和同版正式矩阵仍未在本意见中判绿。

## 精确内容摘要

终稿读取 UTC：2026-11-17T18:51:45.371181+00:00。

- `slc/src/isolated-check.ts`: `4dbc6318bf0e67d32523353a1d02f858347e0257b048cb4654caee595f6a4262`
- `slc/src/verification-worker.ts`: `e4c6c18bf7f066ffc32dafd5042d86e71447afbfca2e5bdf5a274413f96eafd0`
- `slc/src/managed-compilation.ts`: `72df4e15438742185536928c151bc759ab05264542a6d3bbe2d89079f58bf4ed`
- `slc/src/verify-coverage.ts`: `37637d844baca897c96844e8cd25efc06254308fac0415c1fd29182c69507c09`
- `slc/src/compilation-audit.ts`: `e2d1aec811f684c29b05cbf1233dc549b373c403d872c9bb92b6720d296f3be5`
- `slc/src/compiler-identity.ts`: `11bdd778f6e4f7b75f326c50abc293930ec18a887d1923b9288b932efe70ebfb`
- `slc/src/check-report.ts`: `54b96644f9842e80804165e8d4b04c1c9d63be92544427c5c140f24f652fb555`
- `slc/src/runner.ts`: `a67bced329f17eda9b78669689da9a310c3a476e9268e1ce8bbde86a300eaf9f`
- `slc/src/verify.ts`: `defe855341d17d0aa675b1146f74e1733df2583b5e6d0dec80c325462f3228a2`
- `slc/package.json`: `2f80ba5036064f47742739f67b30006ad5c69fa4abcd4b665e953162116ec706`
- `playbook/src/artifact-environment.ts`: `f1b73e750fe2bdec93d9573ca9c75138b5d822a774572d613b2f6bd708899eba`
- `playbook/src/artifact-files.ts`: `b39a38aec508378e8110f70fa0017a68dfcb78578a8e42f01bc70ca1fd5e43e3`
- `playbook/src/fresh-artifact.ts`: `aee23ee42db8740968c59375fc519da88e2f20bfcebb6fdf005cf2cd54018c72`
- `playbook/package.json`: `e50ffe66edd9fb4913c37a786537f466c6adbfb3822e2fb28b554eb15f104f84`
- `cligent/package.json`: `61cdb43d9b6264cea60599c40374f6c542d165006303a1a3df63181afb060ede`
- `slc-global-delivery-20261117/tools/native-case.mjs`: `93bc3c2be4419393f8fb9713ea6aab80b9ed69f638316a67c24a70a55798d0be`
- `slc-global-delivery-20261117/TEST-METHOD.md`: `5611be87407ad0cc18e9f4ca5a4f09b49fc1c3a9ce31faff1feefeb71075acfe`
- `slc-global-delivery-20261117/evidence/design/SC3.json`: `ae39b5e32747029051750af07ae1fa992efbb996aa30de6371376737fb08a112`
- `slc-global-delivery-20261117/evidence/design/REVISION-v3.md`: `a5da69b49e23c3006a4c0c2ab528746d669b97bf55edd5b4693458d4d01278ac`

本次实际源码快照/反例文件：
- `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-DCCAvF/source-identity.json`: `0b5146ffce6e602ef2d80707a55c820cfa201b1db6bf19c484732b68517ccf04`
- `/tmp/slc-v3-renamed-witness.mjs`: `c79f9dd52bbe4197ce494b4b83cf12971fc2cc90ecb789acc7c0819337e93727`
- `/tmp/slc-v3-ipc.mjs`: `e929a6861bac374995805dc3e35e6b82dc851e5195288464975fe4d29620d072`
- `/tmp/slc-v3-network.mjs`: `9b330dafc0453379480eeaaf8b65e5bb8d939612250b08f957a1f64cd0ae6170`
- `/tmp/slc-v3-native-writes.mjs`: `9c3e651624250fec7a7be2aa811a4db235b8e96c3095479c36347e5269ef66e7`
