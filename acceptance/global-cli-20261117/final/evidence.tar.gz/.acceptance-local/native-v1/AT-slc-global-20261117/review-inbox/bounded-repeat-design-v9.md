# Bounded repeated-invocation design v9 — independent opinion

**设计方向可支持，最小修改边界明确；不授予实现、维护 demo、rc9 包或正式验收通过。** 应允许有限预算内真实重放的重复 invocation，保留真实初始路径/guard/context/transition 证明和现有预算。不能为保持先前假证明而恢复solver context，也不能把合法有限循环一概当unsupported。

本轮只读现有源码、spec和真实rc8失败收据，未改产品、spec或生成产物，未构建、未运行新反例或测试。下列TDD是应执行的设计要求，不是已通过证据。

## 已核对的实际失败范围

`evidence/commands/slc-final-rc8-full.json` exit1、inputsUnchanged=true；对应逐测试JSON为2083 total、2069pass、12fail、2pending。失败集中在public retained-bundle completion，夹具来自原维护EN/ZH demo，调用真实dist/cli.js，不是直接source helper。因此先前2081-source-green若当时调用旧dist，不能证明重建rc8的CLI completion通过；保留原始记录并限定实际输入是正确处理。

这里存在两类不能混同的finding：多数default8/64失败带unsupported repeated-invocation path；**EN/ZH主要正控已显式选12/256/900000，但其implementChange onDone arm1只报exhausted12-invocation depth和256-attempt**。所以删除重复禁令是合理必要补偿，尚未证明足以关闭所有12项。需要真实轨迹核实维护demo的合法循环长度、分支选择和所选预算；不应事先宣布所有失败同源或修后必绿。

## 禁令及现有有限终止点

当前`searchCoverageEntry` successor loop（verify-coverage.ts:3168–3187）在既有深度门之后构造visited=[root,...steps.next]，对非questionWait的任何已出现node.next直接加入unsupported repeated-invocation path。这按invocation节点身份去重，没有区分前次counter0和后次counter1/2的真实不同context，故会截断真实有限自循环或A→B→A。

无需以此禁令作为无限运行保障：

- 3054：while queue非空且attempts<maxAttempts；3069起每次实际replay记一次attempt；目标检查后需重新构造prefix时3087–3094再记一次，不能绕过或漏记。
- 3170：`path.steps.length + (path.witness?.events.length ?? 0) + 1 >= maxInvocations`时不生成下一prefix，报告具体selected invocation limit。允许revisit后仍使用同一表达式，不重置steps或删掉历史节点。当前语义包含witness公共事件成本，不能借修复顺手改预算定义。
- 132–150：coverageCheckpoint/coverageYield检查每次独立run的deadline和signal；2970起搜索及replay保持yield，局部guard探测另有原probe限制。maxDurationMs及caller更短deadline仍适用。
- 3202和外层run finally：每轮actor.stop及全run actor集合清理仍在；不能为重用循环状态保留后台actor或跳过清理。
- 每次prefix是根到当前的实际重放；不是让同一actor无界循环。新增候选path的steps增长有界，每个target的尝试次数有界，队列即使增长也只能在现有有限attempt/depth/duration约束下被处理。

## 最小安全实现建议

在Spec先确认“有限真实循环”后，仅移除visited/includes的普通重复节点硬拒绝及其unsupported消息。保留深度门、attempt收费、family轮转/target continuation现有调度、output候选顺序、guard与context固定、真实prefix重放、native权限和报告来源验证。不新增loop-unlimited开关，不提高默认/上限预算，不删防御guard，不改生成FSM/GEARS以迎合checker。

`replayCoveragePath`（2835–2967）已经提供关键安全门：先要求实际pending invocation与step.node匹配；清pending，设置expected=step.next后才complete真实脚本结果；下次推进又要有新的pending且actual atState(expected)。同叶非reenter只有context/action变化而没有新调用时，不会凭“仍在同一状态”继续重放。应保留并通过TDD验证这一点。

末端`probeNonPreemptiveActor`仍要求所选结果的真实completion/target，self-target还须authored reenter:true及本次新增source/arm/event/reenter微步；root interrupt仍要求实际root微步。允许repeated prefix不等于允许省略这些terminal proof，也不允许私有snapshot/context替换。

**不建议先引入context-fingerprint dedup。** 仅node key去重正是这次错误。JSON(context)会漏descriptor、prototype、actor/lifecycle/ordered-history差别；只抽某些字段也可能把合法两条前缀合并。现有预算足以提供有限性；若实际性能证据后来要求优化，应单独定义等价关系并保留反例，不与本修复捆绑。

## Spec修正应保留的合同

verification-6当前明确写“without repeating an invocation except successive canonical question…”；若要允许一般有限循环，必须先改这句，不应先偷改实现。建议表述的语义：允许有实际新invocation发生的有限revisit/self-reentry/多节点循环，每次计入同一个maxInvocations、maxAttempts、maxDurationMs；仅当前真实初始/前驱轨迹可贡献证明；预算耗尽或未发现路线为unverified，不据此证明Source有错。

verification-11补回归夹具：真实counter两次重入才可达到后续arm；不增长counter、死entry、非重入同叶不能被伪造通过。它当前没有另一处显式一般revisit硬禁令，应作为与6一致的回归要求更新，不必扩大到任意控制流形式的完备性承诺。verification-62/73/74中的有限上限、分类、无context patch和实际观测保持。

## 最小TDD与补证

先红后绿的最小fixture：初始真实work counter0，loop结果在counter<2时执行authored reenter:true并assign counter+1；第三次真实invocation在counter2接受finished并达到实际后继。trace必须观察真实counter0→1→2及两个done-event self-reentries，不能只断言findings=[]。这会精准触发原visited禁令。

同一fixture的独立负控至少包括：counter不增长（或完成guard矛盾）、真实初始entry恒假；非reenter版本不发生新的invocation；足够/不足maxInvocations与小maxAttempts、短deadline对照。负控要求未证实/耗尽时明确unverified并点名selected limits，不能为通过改成artifact defect或删除guard。保留本次v8 dead-START/context-patch及root-final无微步反例，防回归。

然后在**新dist**而非旧dist上跑：全部12项completion，原维护EN/ZH actualNodeCLI --complete和其现有emitted suites/独立runtime检查；保持Source/GEARS/FSM字节断言、错误composer、protected mutation、actual partial-write等断言，不跳过失效负控。维护fixture确需更长真实路径时，应明确记录其实际最短已观察轨迹与所选支持预算；不能把预算加大本身称为checker语义修复。

还需覆盖：一个A→B→A的真实循环，避免仅支持self形状；既有successive Boss reply循环保持；long-path/competing-prefix预算正负、producer/protected-consumer/retained/emitted相同政策、cancel/deadline实际actor清理，以及reference/self-equivalence。实现后按受影响范围做全套验证并重新生成checker身份/pins；本意见不声称这些已运行。

## 风险及证据边界

允许revisit会增大候选prefix集合，并可能使相同64次预算更早耗在合法/不推进循环上。现有调度含target-continuation优先，并非严格纯BFS；先保持其顺序与收费，若维护demo仍超限，依据具体trace另判断搜索公平性/候选爆炸，不能用“已删除ban”替代结果。duration与attempt仍是有限保护，不承诺所有理论可达路径都可被发现。

新checker executable改变会使冻结rc8以后的当前检查/重用证据受影响，应出新不可变候选（预期rc9），在收据中分开旧冷生成版本与新检查版本。禁止手改已生成workflow输出来制造通过，禁止将旧dist green替换成新构建green；rc8真实红灯保留。原生平台、发布/CI/merge是否重跑由后续影响判定与正式Judge负责，本设计意见不豁免任何gate。

记录UTC：2026-11-17T22:41:45.539920+00:00。

当前只读源码/fixture SHA-256：

- `slc/src/verify-coverage.ts`: `89cc65f555396ec3dc238a7e8bb2ee70a066b85ea052e0d7387745c0e57a5ab7`
- `slc/specs/packages/verification.md`: `dd8befb68b79aa57d49ef072cbfda3e839a35c97e4db0a25b4469ff06f32c5db`
- `slc/test/completion.test.ts`: `12e2e0e3cd67e46cef7288d618263761fd548a8ad14d0bd3fddc34ffdc8b654b`
- `slc/test/coverage-budget.test.ts`: `882cb93a0dff0dabccb79a16eedfc1f8a7d142ef11f591258f30a496f6f752fc`
- `slc/test/verify-coverage.test.ts`: `8c4d3920818cf190ec05530c802ce5eab71443caca0c906fff5a9c07446fe33c`
- `slc/demo/reference/workflow.playbook/workflow.fsm.ts`: `9a85555fa8ff56c04b69c0937dfca7a738dc7ff3cf4ef9cd5fb7467ab77accf0`
- `slc/demo/reference/workflow.zh.playbook/workflow.zh.fsm.ts`: `5670cac974fae8d9936cd1cb1d9301665f60e310df0b4b9d7c3ff19693fd6787`

rc8 full receipt SHA-256：`5015f065e706aa317c4c7cb61e4f6ef29f00449a8166d46f7df51c210dd794bf`。
