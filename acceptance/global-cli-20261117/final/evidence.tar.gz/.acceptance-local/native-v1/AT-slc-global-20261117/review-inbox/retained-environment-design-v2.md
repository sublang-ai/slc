# Retained current-environment 方法 v2 短复核

**主体修订通过只读实物复核；CLI入口有一个小遗漏须修正。**本轮范围仍是retained `--complete` 当前环境delta，不是Source-only新模型生成，不批准整批执行/发布/CI/合并。没有编辑产品/原档或调用付费Agent。

已逐项核对：

- 48份`retained-configs-12-v2`的6个独立历史anchor全部等于`history-matrix-05/<old-empty-TC>/inputs/case/result.json`的真实原字节SHA，48个work互异。
- native先比较priorBytes与配置独立anchor，将原bytes另存archive；FSM/linked baseline由prior.gates.files的确切kind+canonicalpath取得，源与复制后文件都必须等于旧accepted SHA，不再复制后自证。关闭v1主要缺口。
- 后置函数第4参数为独立expectedReceiptSHA；同时检查archived priorBytes、result历史SHA、恰好两个canonical路径/旧kind+hash、当前workspace。空baseline或不同历史bytes不再可过。
- toolchain.prefix须等于case记录prefix，当前CLI须为实际installedSLC的dist/cli.js且处于该prefix；原完整currentgate/snapshot/acceptedbytes/lifecycle链保持。
- 不再读取GLM任务token或私有networkprofile；backendMeaning明确只有configured selection和历史来源，provider调用为0。zeroAgent/phase0仍由事件审计强制，未拿它证明当前provider生成可用。
- v2 work/output/config分目录，v1历史未覆盖。

读取时MacCodex-commonjs v2 native结果已passed，actual CLI `--complete`耗时4987ms。原receipt字节等于独立anchor，两份retained baseline仍等于历史accepted FSM/linked SHA。这是初步样例观察，不是48项执行批准。

## 唯一必须修的小遗漏

`check-retained-evidence-v2.mjs`函数已加第4参数，但底部CLI仍解构4个argv并只传3参，因而正常命令行路径必然报“缺独立历史身份”。应把CLI接线改为显式五个参数，例如：

`directory expectedCase toolchain expectedReceiptSHA256 output`

并调用`checkRetainedEvidence(directory, expectedCase, toolchain, expectedReceiptSHA256)`。独立anchor须来自配置/history，不由待测result自己提供。此修正只影响后置工具入口，无需修改产品、重做生成或扩大场景；已import四参函数的调用方不受此漏接线影响。

原v1轻量措辞建议延续：审计输出/汇总明确retained身份和new-generation=false；原cohort04的30成功/18quota、当前6个真实cold单独保留，不用retained结果改写。v2去掉了GLM代理改写，但identity里仍保留`glmProxyBypassed`旧布尔，可删除或标为not-applicable以免误读；这不是provider测试，也不需要新探针。

CLI接线修正后，本次已读主体满足有限目的的设计要求；最终逐case仍需实际执行和后置校验，后续源码改变须绑定新摘要。

读取时间：2026-11-17T23:41:08.950756+00:00

- `tools/native-retained-case-v2.mjs`：`c9041c87712e5a2fa884e5149daef29145c122b771b6918e3dbd35508aacc7fb`
- `tools/run-retained-native-v2.mjs`：`74eeae4bd5322adb6a7e856ffea18775be606ea0d51c8129a10cbf129716350b`
- `tools/prepare-retained-matrix-v2.py`：`1f859c72babf18b26093da6b351f5e013e4ad5b7ae6d74a58fe8877a5520656f`
- `tools/check-retained-evidence-v2.mjs`：`5d72a29de395bb1b459d35f8d981bbe9d6caa686321ad25507f9f4e70b870253`
