# Compiler implementation v2 and pre-execution design review

- Acceptance: `AT-slc-global-20261117`。独立 Reviewer：`/root/slc_impl_review`。
- 本文件为早期实现复核及执行前设计复核，不是正式执行结果或需求级交付判定。未修改仓库、未启动付费 Agent；只读源码/specs/原始记录，并在临时目录调用真实 Node、SLC API/安装 CLI、Playbook 公共服务做小型反例。
- 依据：两仓库 AGENTS.md、`delivery-acceptance`、`standalone-compilation`、`verification`、`incremental-compilation`、`artifact-environment`；冻结 baseline-request.json、TEST-METHOD.md；独立 Reviewer 与自然语言用例设计 Skill 的原始要求。
- 设计版本：SC1–SC4 的 `design-sc*-v2`，definitions SHA-256 均为 `15e40cc1436119f3fbc6949406b2b048d93d1b3265aecb437b28684875f34d33`；已打开 case-design 对应收据，不能将其 `status: designed / missing:[]` 当作独立覆盖通过。
- 结论：**needs_revision**。最终读取时仍有下列 I1/I2 实现问题及 D1/D2 设计/实现缺口。此前闭包反例已在本轮反馈后修订并重新拒绝，详见后文。

## I1 · P1 · lifecycle 能改变受保护 Source 后仍发布成功

位置：`slc/src/managed-compilation.ts` 的 finalize/lifecycle 调用（最终读取约 122–140 行），以及 `verification-worker.ts` 生命周期分支。

初始化 probe 限制了注入的 repository/ports，但没有保护被加载候选自身通过 Node builtin 完成的文件写入；finalize 外围也没有把原始 Source/定义/依赖纳入 protected-path 前后核对。`businessExecution:false` 是主动写入日志的标志，不能独立证明没有副作用。

独立实测：`/tmp/slc-v2-init-write.mjs`。临时确定性 pipeline 经真实 `runSlc` 完成 text2gears/FSM/link/gates，linked factory 的 `async init()` 通过 `node:fs/promises.writeFile` 改写同次原始 `flow.md`。结果为 **ok:true**，`source after CHANGED BY INIT`，已发布 `build-manifest.json`，`.slc/latest=1`，builds 为 `[1]`。临时产物：`/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-history-2lGXiy/`。它是真实编译边界反例，performing executor 仅确定性提供文件，无 Agent、无外部业务操作。

这违反 `verification-79` 的安全初始化/无业务文件或外部服务变更，以及 protected inputs / `standalone-compilation-7` 的保护约定。失败不仅是“未观察副作用”：已实际丢失 Source 内容并接受成功。

修订要求：让候选 import/construction/init/dispose 的整个生命周期受原有 protected-input 保护约束，至少核对全部原始输入、语义输入、选定依赖和被接受候选；检测变更必须阻断 manifest/history publication，保留准确阶段与变化证据，并按保护契约恢复/保存被破坏输入。不要用 inert host ports 单独推断任意候选代码不可能写文件。

## I2 · P1 · coverage witness 可以伪造 host-owned enabled catalog 使错误路径通过

位置：`slc/src/verify-coverage.ts:1067`、`replayCoveragePath` 的 `path.witness?.input`（最终读取约 2891 行）、`readCoverageWitnesses`。

JSON shape 校验后，witness.input 直接整体代替 `coverageMachineInput(machine)`，没有区分 Source startup options 与 compiler/host authority 字段，也没有禁止补入未声明 enabled target。即使所有迁移都是实际运行，输入 authority 本身仍可能是伪造的。

独立实测：`/tmp/slc-v2-witness.mjs` 调真实 XState 与 `checkFsmCoverage`。机器仅有 literal `configured-child` 绑定，但前驱的错误 guard 额外要求 `enabledPlaybooks` 包含从未声明的 `undeclared-child`。无 witness 得到 4 项 reachable-entry/result/onDone 未证实 findings。添加公开 JSON witness，input.enabledPlaybooks 填入 `configured-child` 和 fabricated `undeclared-child` 后，结果变为 **[]**。未改 guard、未跳私有状态；问题恰是 witness 把不可授权的 host catalog 当成合法启动选项。

原始依据 `verification-74` 明文要求 Source-permitted startup options、genuine public events，并禁止 fabricated enabled targets/private state。本反例改变了与判定直接相关的动作前 authority 状态，不是可选等价样例。

修订要求：witness 仅覆盖经 Source/实际 option validator 证明允许的启动参数；保留由 compiler/host 生成的 catalog/self/session 等 authority 输入，对冲突或越权字段拒绝。用本反例确认仍保留拒绝，同时合法绝对路径等用户选项继续可达，且 witness 与普通探测共享预算和实际迁移观察。

## D1 · P2 · SC3 自然语言设计未落实会改变判定的前状态和操作

判断：**needs_revision, revision_target: design**。

`evidence/design/SC3.json` 中 TC-gates、TC-reuse、TC-source-returns、TC-compat 各自三项检查的 action 都是同一句泛化的“Execute the documented installed CLI or regression fixture…”；expected 逐个重复整个场景的三条判据。没有提供可照做的具体 fixtures、动作前状态、输入/操作和独立预期，也没有把 TEST-METHOD 的 deterministic regressions 分配给实际检查或登记缺口，当前 `gaps:{}` 因此无实质证明。

特别是 `TC-reuse` 未区分：旧 bundle 已接受/未接受、runtime root/content 变更、dangling/foreign path、generation 失败/取消、候选 init 失败、原 archive 删除；`TC-compat` 未具体列出 legacy `.ts`、already-in-artifact、supported ESM relocation 与 unsupported actual CommonJS scope 的预期。SC3-c2 的构造/init/dispose 与合法路径/伪造 catalog/有限预算边界也没有具体可复核输入。这些差异分别由 specs 和 TEST-METHOD 明确要求，能单独失败，不可用一个未指定 fixture 的通过覆盖。

反例：只执行一次正常 fresh bundle 的完整成功路径，或只检验 marker 缺失，同时不检验失败后 rollback、旧记录复用及实际 -o format；当前抽象 action/expected 没有指出缺少了哪次必须执行的操作，正常结果可被错误地分配到全部重复 obligations。I1/I2 正是当前有效的独立失败形态。

最低修订：为每种有依据的行为差异写具体前状态→操作→观察面/预期，明确由哪些 TC/check 覆盖；可以共享文件，但不能仅共享整个场景文字。未实现/未调试的变体逐项保留 gaps。SC1/SC4 的 registry install/provenance 同样需要补可核对的安装树/目标版本/CI head 比较操作，才可做其候选实现复审；本轮没有它们的实际自动断言材料，不能授予 implementation passed。

## D2 · P2 · native-case 的“通过”尚未绑定冻结输入和指定用例身份

判断：**needs_revision, revision_target: implementation**；涉及 SC2 48 条及 SC4 12 条 registry smoke。

`tools/native-case.mjs` 有真实 exitCode、manifest、独立 entry check、root 文件和 selected links 断言，这是有效基础；但 config.caseId/parent/backend/layer 未校验合法组合，实际平台/arch、sourceSHA256、CLI/candidate identity 只写进 JSON，没有与指定 TC、固定 definition digest 或预期候选比较。最终 status 仅由 exit0、gates 和 failure 决定。

可直接沿代码推出的反例：在 macOS 以 `caseId: TC-local-windows-codex-empty` 配置运行，或把 config.source 改成另一个能通过的工作流，现有 root/manifest/link 检查仍可全过并写 status=passed；记录中虽然能看见真实 platform/hash，但当前自动项没有第一处拒绝断言。TEST-METHOD 明确要求相同 frozen definition、指定 native platform 和 exact candidate。必须由该自动项断言，或在设计里明确分配给另一实际验证项，不能靠事后自行解释 broad `expected`。

另一个当前实际缺口：脚本只 hash 复制前 Source，parent inventory 排除了整个 child；独立 entry check 后也不重读 Source 或父 fixture 快照。因此 I1 的候选 init 改 Source 不能被脚本发现；独立 entry checker 发生在 parentAfter inventory 之后，它若改变父目录也不会被最终 parentUnchanged 观察到。

修订要求：冻结并校验 TC→OS/arch/backend/parent/layer/source/candidate 的映射；记录实际 npm 版本/native shell/实际 backend SDK/native runtime provenance；在所有校验动作之后复核原 Source 和父目录；对不匹配给明确 failed 或 blocked。3×2×8 和 3×2×2 的用例枚举本身与目标矩阵一致，但枚举不是这些身份断言的替代。

## 已独立确认的修复与非缺陷结果

1. **旧 F2 fresh derivation 已修复**：重跑 `/tmp/slc-review-derive.mjs`，依赖新增 extra state 后 `identicalPinsAfterChangedHelper:false`、`secondContainsExtra:true`，fresh module keys 与新 pins 一致。另 `.cts` 两次加载复现 `/tmp/slc-v2-cts.mjs` 得 1→2，没有重现陈旧 cache。
2. **旧 F3 lifecycle 分类已修复**：重跑 `/tmp/slc-review-history.mjs`，constructor throw 返回 `artifact: entry lifecycle failed: candidate constructor failed`，cause.category=artifact，未产生 history（ENOENT）。
3. **旧 F1 常规 require 收集已修复**；本轮最初又发现 `module.require` 和 nested foreign XState 的两个真实反例，已提前反馈。随后主 Agent 修订 collector/每 importer runtime-root 校验。重新执行 `/tmp/slc-v2-closure.mjs` 时 helper.cjs 已在清单，改值后被拒绝；`/tmp/slc-v2-shadow.mjs` 在 foreign `sub/node_modules/xstate` 处报 environment 并在 import 前拒绝。二者不作为最终仍未修的问题重复计算。
4. **实际 -o 边界符合已审范围**：`/tmp/slc-v2-relocated-ts.mjs module` 在 canonical bundle 外的独立 ESM folder/custom.ts 成功；该 custom.ts 实际存在，默认 flow.mjs 为 ENOENT，未发现新目录禁令。相同 `.ts` 代码置 CommonJS folder 时失败于真实 `Cannot use import statement outside a module`。另 `.mts` 与声明的 `.ts` 扩展不符时按既有 generic contract 拒绝；没有把它误报为 relocation 目录错误。成功临时根 `.../T/slc-history-aVYh1K/`，CommonJS 失败根 `.../T/slc-history-6nSdyu/`。这些是确定性实现验证，不是 native 三平台/真实 Agent 通过。

## Snapshot02 开发证据的独立核对

已读 `evidence/development/real-cli-codex-02/command.json/result.json`，以及对应 bundle manifest 和 attempt events/result。记录为真实安装 snapshot02 CLI，Codex，CommonJS + 中文空格目录，原 source SHA `af0a67466cfb4d5efb79caee263ee433ebc6a9fc7090cd6fbb071a1a998ab969`，exitCode=0，elapsedMs=464049；audit 有 5 次 agent-call、6 组 checker-start/finish，manifest 包含 phase-contracts、strict-typescript、entry-initialize-dispose 通过记录，attempt result.ok=true。

我又使用 snapshot02 自己的安装 CLI 执行 `check entry <actual flow.mjs> <actual flow.fsm.ts>`，独立进程返回 `{schema:"sublang.slc.check.v1",status:"verified",findings:[]}`。仅确认该旧冻结安装图的开发输出与 safe lifecycle 记录一致；未重新发 Agent 调用，也不把 audit 中的模型选择文字额外升级成独立 provider 认证结论。

`installed-snapshot-02/source-identity.json` 明确是三个本地 tarballs 加 coordinated override；因此它不是 SLC-only registry acquisition。当前 dirty sources 又有改动，本次真实 Codex 成功不能替代当前最终 candidate、Claude/GLM、Linux、native Windows、全父目录矩阵或 CI。旧 selfhost fixtures/release guard 和最终 regressions 尚在修订；本复核不宣称它们已绿，也不豁免失败。

## 精确版本与复核边界

最终源码读取 UTC：2026-11-17T17:37:00.115613+00:00。工作区正在被主 Agent修订；下列 SHA 只标识本意见终稿读取时的具体内容，后续改动使相关结论待重审。产品库 HEAD 保持 SLC `034c93105e54063388fd1050ffb1b8d97998b567` / Playbook `5403903f63342f8344d1524b5770af8ff198904d`，均有未提交修改；SHA 清单也包含实际执行的 dist/JS 以避免仅凭 TS 宣称实测版本。

- `slc/src/managed-compilation.ts`: `5b0dc56aa1cb9afe386394d80ed743a6ba52272897579127fb9b030ba0fc2148`
- `slc/src/runner.ts`: `49ff4b1d2db6236a567fc9fd4b16937588fd99eb4b7f9fb6a7bfd186701f99c4`
- `slc/src/verification-worker.ts`: `06c2ecaf07994aeeb24d72b5ac192aeef060edae5f041bc1e219e5a23677eb6f`
- `slc/src/isolated-check.ts`: `3df09da81d72cef71f723d094b6100129ad4b7e1d39e9af49afbc51e5e87380b`
- `slc/src/verify.ts`: `defe855341d17d0aa675b1146f74e1733df2583b5e6d0dec80c325462f3228a2`
- `slc/src/verify-coverage.ts`: `f0d43f8ac490b6b542ea31349f2333d53ce3d572752d120be2931883242f0047`
- `slc/src/entry-module.ts`: `00f291692ef2208ad79b75a97538d6dcf838d4f0a109e74d37bd933afb05ae67`
- `slc/src/verify-typescript.ts`: `4a5b824b10fd49e639d299e7b310f8a451c8205b75989a3ef738f111effcb4a6`
- `slc/src/compiler-identity.ts`: `6909e8c003070e1adc0414d9af2b429fbb511856cc8d6be0425b4c5c85c238af`
- `slc/src/check-report.ts`: `88192b2447a8b0e456d131dad5f59400e81707c30f09949876ffed9aa9574a88`
- `playbook/src/artifact-environment.ts`: `f1b73e750fe2bdec93d9573ca9c75138b5d822a774572d613b2f6bd708899eba`
- `playbook/src/artifact-files.ts`: `b39a38aec508378e8110f70fa0017a68dfcb78578a8e42f01bc70ca1fd5e43e3`
- `playbook/src/fresh-artifact.ts`: `aee23ee42db8740968c59375fc519da88e2f20bfcebb6fdf005cf2cd54018c72`
- `playbook/reference/sdlc/code.playbook/bin/provision.js`: `471a4092b6f144bdfa2499d98aac113bfc7cdd113b5c9171262262aad1f2bfb3`
- `playbook/src/artifact-environment.js`: `1f9c2dce7707734248bfab5ffd04a579ed2318d96ccd2d6f51e01afcd00b86c8`
- `playbook/src/artifact-files.js`: `3553903250789e192163cdea0f896b446364237720349d92c9aa1c0ffa7b9e59`
- `playbook/src/fresh-artifact.js`: `6239bca064c72cba9dd8609712617474cdfe37bfb04f0941262264f71b9f83e8`
- `slc/dist/runner.js`: `5e85a4dea5c14b4edfe633f816340eed0872d81e256493d262575e5dedea50c9`
- `slc/dist/verification-worker.js`: `dbc83549cf7d10fbb6681128172098f4ebb3c193ca6ae11b76526a924b32506a`
- `slc/dist/verify.js`: `f41e318b65e133a5d37571b55e4a678fe9495ea812cf84be135cd4298f928a51`
- `slc/dist/verify-coverage.js`: `029dc95d8f7fc2bf2e3ab80e61326ab75b139bcbf75b5f5bf48e24e7d9c7f88f`
- `slc-global-delivery-20261117/baseline-request.json`: `45e9e05dee13f84624640dc30c93790c790d64eccb7b237fefd5979be1cd1536`
- `slc-global-delivery-20261117/TEST-METHOD.md`: `5611be87407ad0cc18e9f4ca5a4f09b49fc1c3a9ce31faff1feefeb71075acfe`
- `slc-global-delivery-20261117/tools/native-case.mjs`: `2c016c45b356e27d30d95c3af10cdd0956854d2d47487dbbbf82867c129af789`
- `slc-global-delivery-20261117/evidence/design/SC1.json`: `2850dc29610c5925ab88f394b007b47cb272e82037d2abd9a66ae07d5098da94`
- `slc-global-delivery-20261117/evidence/design/SC2.json`: `4b0e7dd21e63eebefa86de3da93d12f9e0d5d85b653eacb9c49854cb259eadff`
- `slc-global-delivery-20261117/evidence/design/SC3.json`: `a97405ff776cc4b35ce01c0a2707b4cd7d23a635c681390912407dd84c3702aa`
- `slc-global-delivery-20261117/evidence/design/SC4.json`: `8e5182edf9e274ee901401aefb287db9bc1b65a58c4d1a9785edeeea39b3da4a`
