# AT-slc-global-20261117 native design / harness v4 独立复核

结论：**needs_revision（SC2 implementation；证据完整性也影响 SC4）**。SC2 的 48 个场景坐标与 SC3 v4 的 15 项回归设计均可由冻结需求及原规格推出，未扩大为业务执行或业务结果质量验收。当前 harness 有可使承诺不成立而仍报 passed 的来源/证据缺口，不能把 match 的 full、compiler v4 的缺陷关闭报告或进行中的任务转换为原生矩阵验收通过。

本次只读项目与证据，没有修改产品代码、规格或当前候选；只写本报告。评审范围是设计、harness 和已有负控，不批准公共发布、CI、合并，也不替代后续不同 fresh-context 执行 Reviewer。

## 基线与已读材料

- 冻结定义 `.acceptance/native-v1/AT-slc-global-20261117/definitions/000001.json`，R1 空子目录/实际 CLI/三平台，R2 本地功能与注册表安装分开，R3 完整证据/失败风险复核。
- `TEST-METHOD.md`；`/Users/boboyang/work/AGENTS.md`，Cligent/SLC/Playbook 的 AGENTS.md；SLC `delivery-acceptance.md`、`standalone-compilation.md`、`verification.md` 相关行为/验收条款；Playbook `artifact-environment.md`。
- `evidence/design/SC2.json`（design-sc2-v2：48 cases、192 obligation/check IDs），`SC3.json`（design-sc3-v4：15 cases/checks）。
- `.acceptance-local/native-v1/AT-slc-global-20261117/match/match-sc2-v4/result.json`：status matched、coverage full、**execution_status not_executed**。它只绑定 `native-case.mjs`；当前文件摘要仍与该绑定相符。
- `tools/native-case.mjs` 全部 144 行，`run-native.mjs` 全部 25 行，`make-native-configs.py` 全部 13 行；读入并程序核对全部 96 个 native-configs-04 JSON：48 坐标各 debug/formal 两份，backend/parent/platform/工作与输出标签一致，96 个 work 路径互异。
- `evidence/candidate-cohort-04/frozen-cohort.json`；两份已存在负控 stderr；补充读取 packed 实现中环境验证及 Cligent SDK/native 定位边界，以及已生成的 macOS empty case 档案，用来判断 harness 是否真正消费这些证据，非执行验收。

## 必测判据的来源及边界

| 判据 | 来源 | 设计判断 |
| --- | --- | --- |
| 3 native OS × Codex/Claude Code(GLM) × 8 父状态 = 48 个冷编译 | R1/SC2；delivery-acceptance-2/3/4 | 覆盖完整。missing 与 conflicting 拆开、Git 合入 ESM、空格中文合入 CommonJS，均是原约定具体化；无需为等价改名再新增用例。 |
| 仅安装 SLC；本地生产包与注册表自动闭包分层 | R2；delivery-acceptance-6/7 | 正当且必须分层。当前 local configs/本地候选运行不能自动充当 registry-install pass。 |
| 输入字节相同、只复制定义、新空子目录、不手建项目或手改生成工作流 | R1/SC2；delivery-acceptance-1/3；standalone-compilation-1/2 | 正当。:23、:93-95 保证新空目录和冻结输入；:106 真实 node+installed CLI，无 mock。 |
| 原生平台、实际 backend/model、SDK/native 来源 | delivery-acceptance-2/4/7；standalone-compilation-8；verification-83 | 正当。OS/TC 有直接断言，实际依赖来源和完整运行证据仍有下面缺口。 |
| .mjs、私有 ESM、两条直接 runtime links、真实初始化/释放 | standalone-compilation-2/4/5；artifact-environment-2/3/5；verification-79 | 正当。只进行安全生命周期，不要求发送业务 Boss turn、真实 Agent/effect dispatch 或检查提交说明质量。 |
| 父配置/依赖/Git不变、无项目根依赖 | SC2；delivery-acceptance-3；standalone-compilation-1/2/3；artifact-environment-4 | 正当；本地 fixture 快照已做，链接目标/更上层祖先保护不足。 |
| 失败、取消、未到达与被拒绝的工具操作不可变 pass；完整输入/产物/阶段/时间/退出归因 | R3/SC4；delivery-acceptance-5/8；standalone-compilation-8/10 | 正当；非零退出 fail closed 已做；过程证据完整性未成为 pass 条件。 |

SC3 各项也保持原承诺范围：types → verification-33 / standalone-3；pair → standalone-3 / artifact-environment-5；CJS fresh → verification-72 / artifact-environment-5/7；source-returns → verification-81/82；public-path、witness-authority → verification-74/77；budget → verification-62/63/73；init-effects、init-required → verification-72/79/80；occupied → artifact-environment-3/4；markers → artifact-environment-7；reuse → standalone-6；rollback → standalone-5/6 / artifact-environment-6；layout → standalone-11/12；archives → artifact-environment-5/7。真实 Socket、IPC、最低 Node 和取消/worker crash 控制是已承诺安全初始化/真实检查器 authority 的负控，不是业务执行质量加码。这里认可设计的来源，不宣称这些回归已执行通过。

## 已有断言第一拦截处与通过边界

| 错误反推（其余坐标正常） | 第一拦截处 / 当前边界 |
| --- | --- |
| 一个 native OS 或 TC/backend/parent 标签不符 | :13-16；expectedCase 由真实 process.platform 与 config backend/parent 构造，caseId/platform 不符立即拒绝。wrapper 在远端 native Node 执行，不以 SSH 发起主机代替目标 OS。 |
| 一份配置把 empty 改成另一父状态但保留 TC | :14-15 拦截。全部现有 configs 坐标一致；若以后同时修改标签和 fixture，须重新绑定配置并按48固定集合汇总，不能只数文件数。 |
| CLI 来自 checkout/不同安装前缀、CLI字节错误 | :25-29 canonical CLI/prefix、CLI SHA 和硬编码 cohort digest。 |
| 同版本 SLC helper 被改，而 cli.js不变 | :43-46 对冻结 packed files逐一哈希。已有 tampered-helper stderr 在 :45 拒绝 `@sublang/slc/dist/runner.js`；不止比较自报版本或 cli.js。 |
| 任一三包错版本或根目录逃出安装树 | :32-45；三包各自物理根、版本、独立文件清单检查。Cligent 263、Playbook 175、SLC 209 个冻结文件；frozen cohort 自身硬编码 SHA。只改等价名字不需要增样例。 |
| 子目录已非空、Source不同或编译期间被改 | :23、:94-95、:124 拒绝。 |
| 父 fixture普通文件或 .git文件被改 | :92、:122-123 对文件内容快照比较；子目录根新增项目/Git文件在 :115-116 拒绝。 |
| 编译/独立初始化检查非零、无 manifest、错 runtime link | :109-120、:125；非零 compile 即没有 gates；check非零或manifest/link拒绝不能报passed。 |
| archive复制失败或远程证据收集失败 | :126 将case改为failed；wrapper :21、:24-25使transport非零。 |
| 双边都错误地选择同一外部 XState/SDK | **没有独立拦截，见 F1。**链接与 selected比较不能证明 selected 是预期 acquired tree。 |
| 运行档案/必需phase或gate记录丢失，但运行代码可加载、entry check为零 | **没有完整性拦截，见 F2。**Playbook runtime loader按规格无需依赖档案；harness不能用其代替编译证据审计。 |

两个已有负控的结论仅限各自拦截路径：`tampered-helper.stderr` 与 `wrong-tc.stderr` 均为 Node v25.5.0 的拒绝。它们不证明 SDK来源、所有父状态、Windows junction或48个真实编译已通过。

## 必须修订

### F1 [P1] SC2 implementation：XState 与实际 SDK/native 没有独立 acquired-tree 身份约束

`native-case.mjs:32-46` 只冻结三包。`:49` 让环境服务自己选择 XState；`:118` 再把链接与同一 selected 比较。没有断言 selected.xstate.root 位于 toolchainPrefix、符合由预期安装图独立记录的版本/内容/物理根。若安装树中的 XState 缺失，而某个祖先 node_modules存在同版本兼容 XState，Node解析可以回落到祖先：三包所有packed文件检查仍通过，compiler与harness同时选中该外部XState，manifest与两条links都自洽，当前pass表达式仍可为真。这违反 standalone-compilation-3、delivery-acceptance-7 的安装树来源及无项目根依赖承诺。

实际 SDK/native 的情况需精确区分：已有 archived events.jsonl 确实记录 agent-preflight，例如 macOS Codex 的 SDK0.169.0与 native path，也有 agent-call/model；不能说完全没有这些证据。但 harness不读取它们、不检查选中SDK的canonical root/版本与native executable来源、不将其缺失或外部解析作为失败。Cligent自己的 package lookup 能向祖先寻找依赖；“available”或版本存在不是 intended acquired tree 的独立证据。完整三包锚点也不涵盖这些外部包内容。

修订边界：独立记录并核对预期 acquired tree 中 XState、选中实际 SDK/launcher/native的canonical身份；把运行中实际选择与该基准及TC backend/model比较。引用实际preflight记录并断言来源、存在性及必要版本，不能只再与另一个selected自报值比较。无需增加同义名称样例；应加入一个同版本外部依赖回退或错误根的实质负控。

### F2 [P1] SC2/SC4 implementation：pass不要求完整真实phase/gate与归因证据

`:111` 依赖 validateArtifactManifest；`:113-114` 仅要求独立entry命令退出零；`:119` 保存manifest.files；`:125` pass未验证manifest所指attempt/events/snapshot存在、所需phase真实executed、Agent调用实际backend、checker完成报告、gate检查对应当前文件hash与有序init/dispose。按 artifact-environment-5，runtime manifest validator特意不把Source/GEARS/log/checker档案作为运行依赖，且仅要求verification.checks非空、条目status passed；因此单个随意名称passed check，或缺失所有过程档案，并不一定被`:111`拒绝。独立entry check只能重证生命周期，不能重证Source producer/FSM/link阶段实际运行。

这不是已出现的macOS档案缺失：抽读其events共152条，含5组phase-start/return、agent-preflight/call、6组checker-start/report/finish、源与语义输入快照、validateOptions/construct/initialize/dispose有序pass；这些是可用证据。缺口是harness允许缺失/错绑时仍绿，导致未来“缓存或仅生成文件冒充冷执行”、错误backend或记录链断裂未被验收拦截。SC2设计与TEST-METHOD明确不允许这种替代。

修订边界：验收后处理必须读取当前attempt，检查必需phase/Agent调用/命名gate、完整checker报告、当前source/产物/语义输入hash、时间顺序与最终状态，交叉核对manifest/CLI/TC；缺档或未到达即失败或unverified。把这项审计加入正式实现与match绑定。可以继续保留runtime loader的“档案非运行依赖”正确行为，不应通过改变产品loader来补harness。

### F3 [P2] SC2 implementation：父快照没有覆盖链接依赖目标与相关祖先

`:129-132` 遇到symbolic link只记录链接字符串，不跟踪目标内容；compatible-runtime fixture的若干依赖恰由`:79` symlink/junction到真实安装树。若编译修改了这些目标中的依赖文件，parent before/after仍可相同。对fixture上层祖先，`:91` 仅在部分case检查package.json存在，不记录祖先配置/依赖/Git内容，也不验证“outside Git”或禁止祖先node_modules回退。因此“fixture范围普通文件不变”不能泛称“所有父依赖和祖先设置均保留、无根依赖”。

修订边界：记录并比较受本次测试影响的父runtime依赖实际目标身份，以及相关祖先配置/依赖/Git状态；对empty与规定outside-Git cases独立证明无祖先项目/依赖/Git前提。无需扫描无关整机内容；限定fixture及实际解析祖先/目标即可。

### F4 [P2] SC2 implementation：不可完整绑定 transport/config 与输出归属

match-sc2-v4只有native-case.mjs的bindings；真正执行的run-native.mjs、96 configs及cohort虽被阅读，却不都进入该match绑定。wrapper也未断言cfg.caseId等于其argv cid，native-case只检查config内部自洽。若一个TC的配置误贴了另一个自洽TC，case本体不会因wrapper指定的TC不同而拒绝；外部只按transport文件名或exit0汇总可能把另一TC当本TC通过。远端收集只看scp返回，不校验采集result.caseId/输入/脚本摘要与调度目标吻合。

修订边界：在wrapper运行前断言配置身份与argv，完成后核对result和传输目标；把执行闭包脚本与具体配置摘要绑定到记录，汇总固定48唯一坐标，重复或缺失不通过。首次fixture nonempty阻止同一work复用，但它不能替代输出归属检查。

## operations.debug与外部长任务证据边界

任务说明提到六份因300秒上限而blocked的receipts；本次独立读到的持久化debug result.json为两份（debug-v4-macos-codex-empty、debug-v4-linux-claude-glm-empty），原因都是`timeout must be 1 to 300 seconds`。不能把同一操作的request/pending/result多份文件当成多次独立执行。其余四份在当前读取范围内未定位，六份总量应附具体原始回执路径后再由执行Reviewer复核。

这些拒绝发生在工具接纳阶段，不证明原生编译失败或成功，也不证明运行超过300秒。外部真实长任务可作为external execution/history import的证据，但导入不等于operations.execute，不得重写这些blocked receipts。可接受的后续路径是：保留真实外部启动命令、native主机/进程/工具链身份、开始结束时间、退出/取消状态、候选/脚本/配置摘要、全部产物与日志；按history导入规则如实标明external；另一fresh-context Reviewer逐case复核原始执行与上述断言。独立复核不会追认从未发生的operations.execute。因首次执行已开始，若harness修订，应明确哪些证据可被独立后处理补审，哪些来源/fixture缺口需要新cold case，不覆盖或删除现有失败。

## 当前可授予的结论

- 可授予：48坐标设计成立；SC3各判据来源成立；现有三包完整packed-file锚点成立；两项已知负控按预期拒绝；当前matcher只声称未执行。
- 不可授予：完整native矩阵、本次全部SC3回归、registry依赖自动安装、公共npm发布、CI或合并通过。四项首次任务启动及Windows安装进行中均不能计为pass。
- 复核期间已出现macOS-codex-empty的passed case文件及Linux-codex-empty的failed case文件；这是需要后续执行复核的原始结果，不把它们纳入本报告的执行批准或用一个平台结果代表其余47个坐标。Linux非零不会被当前harness升级为passed。
- 以前compiler v4报告关闭的检查器缺陷不覆盖本报告F1–F4 native harness缺口；需修订后重绑定match，并以不同fresh-context Reviewer验收实际执行和每项交付证据。
