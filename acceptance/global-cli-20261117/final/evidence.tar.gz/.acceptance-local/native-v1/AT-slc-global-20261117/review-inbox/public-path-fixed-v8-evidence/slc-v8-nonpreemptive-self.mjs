import{readFileSync,writeFileSync}from'node:fs';import{createRequire}from'node:module';import{isAbsolute}from'node:path';
const require=createRequire('/Users/boboyang/work/sublang.ai/slc/package.json'),ts=require('typescript'); const{setup,assign,fromPromise,createMachine}=require('xstate');
const snap='/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-OlJXN5';const{checkFsmCoverage}=await import(snap+'/dist/verify-coverage.js');
const source=readFileSync('/Users/boboyang/work/sublang.ai/slc/test/standalone-witness.test.ts','utf8');const fn=ts.transpileModule(source.slice(source.indexOf('function machine('),source.indexOf("describe('public coverage")),{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
const out=[];
for(const reenter of[true,false]){
 const trace=[];const m=Function('setup','assign','fromPromise','isAbsolute',fn+';return machine;')(setup,assign,fromPromise,isAbsolute)(true,trace);const conf={...m.config,states:{...m.config.states,work:{...m.config.states.work,invoke:{...m.config.states.work.invoke,onDone:{target:'#work',reenter,guard:({event})=>event.output.guard==='ok'}}}}};const machine=createMachine(conf,m.implementations);
 const findings=await checkFsmCoverage({machine,coverageWitnesses:{schema:'sublang.slc.coverage-witnesses.v1',entries:[{events:[{type:'START',path:'/tmp/slc-witness/task.md'}]}]}},{coverage:{maxAttempts:8,maxInvocations:4,maxDurationMs:10000}});
 out.push({reenter,findings,trace});
}
console.log(JSON.stringify(out,null,2));writeFileSync('/tmp/slc-v8-nonpreemptive-self.json',JSON.stringify(out,null,2));
