# Cligent included-SDK implementation review v1

Acceptance: `AT-slc-global-20261117`. Decision: **needs_revision**. This is an early independent implementation review, not formal acceptance signoff.

Reviewed checkout: `/Users/boboyang/work/sublang.ai/cligent`, HEAD `0550600e989fc2f851b16ef055793f324a77311d`, seven-file working-tree diff against that committed specification baseline. SHA-256 of the reviewed seven-file `git diff 0550600 -- …` bytes: `a92b5248daad7bf3755f1d8d30097d48f0ab3dfe6d40fd4bf3bc32d102d05b59`.

I read the original workspace and Cligent AGENTS.md files, specs/meta.md, specs/map.md, specs/packages/package.md, the relevant tmux-play contracts including tmux-play-89 and tmux-play-201, DR-049, the frozen acceptance definition 000001.json, implementation files and the three development logs. Product/spec/test files were not modified, and no dependencies were installed.

## Confirmed implementation and verification defects

### P1 — Installed-layout probes still expect sibling SDKs, contradicting the newly owned SDK trees

Locations: `scripts/verify-distributable.mjs:1528`, `:1536`, `:1554`, `:1594`, `:1604`, `:1618`; introduced by ordinary dependencies at `package.json:134`–135.

Both the global and nested-strategy matrices still explicitly install `claudeSdkInstallSpec` and `codexSdkInstallSpec` beside Cligent. They then derive the expected SDK root from the outer prefix/consumer node_modules. With ordinary dependencies, global and nested installs give Cligent its own SDK dependencies under the Cligent package, and its adapter/runtime-version resolver checks that nearer tree. The Claude probe compares the physical resolved SDK root to the separately installed outer SDK root at verifier lines 904–916; the Codex probe also requires its selected executable to start with the outer SDK root at lines 1044–1056. Thus a correct new own-tree installation is rejected by stale fixture expectations (and separately installed roots prevent this matrix from proving the tarball-alone requirement at all).

This is a confirmed source-level fixture inconsistency; I did not execute the package-install matrix, so no actual failing install result is claimed. Rework these matrices to install only the tarball for the two included SDKs, locate expectations from Cligent's installed dependency owner, and keep the decoy/executable-isolation assertions. Source: package-105 and package-32.

### P1 — Packed missing-component and printed-repair verification was deleted rather than replaced

Locations: `scripts/verify-distributable.mjs:1655`–1656 and `:1678`–1700; deleted old block following the package-only global installation. `extractRepairCommand()` at `:1184` now has no caller.

The old package-free diagnostic probe and the installed launcher's failure, no-session/no-config, out-of-band-prefix, and actual printed-command repair flow are gone. The replacement comment says adapter fault fixtures exercise missing-runtime diagnostics. The existing fixtures are narrower: `src/__tests__/claude-code-adapter.test.ts:444` injects an SDK loader and synthetic package metadata; `src/__tests__/codex-adapter.test.ts:2386` injects a loader and synthetic launcher/native files; `src/app/tmux-play/launcher.test.ts:2941` and `:2992` inject adapter readiness. They do not remove an included SDK/native component from every reachable path of a real installed tarball, run the installed launcher selecting that adapter, execute its reported repair verbatim, and prove repair in the same selected tree.

A broken repair that installs only a sibling SDK while a damaged nearer copy remains selected can pass those fixtures. The replacement normal-install assertions also require only a Codex role and allow Claude to be absent; they do not assert both SDKs ready or absence of missing-SDK remedies. This violates the explicit new matrix in tmux-play-201 and weakens an existing public/runtime safety check. Add actual installed fault fixtures and restore executable printed-repair verification, while preserving the normal package-only success case.

### P1 — The production audit graph still excludes the newly included SDK stacks

Locations: `package-lock.json:64` (Claude `dev: true`), `:1046` (Codex SDK `dev: true`), and corresponding vendor/native entries; `scripts/verify-distributable.mjs:1366` uses the repository audit with `--omit=dev`.

The lock root now lists the SDKs as dependencies, but their resolved records remain development-only. Read-only `npm ls --omit=dev --package-lock-only --depth=0 --json` on the reviewed tree (npm 11.8.0) reported only the five previous runtime dependencies and excluded both SDKs. Therefore the retained repository production-audit path does not demonstrably audit the larger production graph shipped to consumers. A full-development audit is useful but does not establish that the isolated production candidate graph has been correctly classified or audited.

Do not remove the independently exact dev conformance pins required by package-12. Establish a production audit against the actual installed candidate graph, or another faithful production graph that includes both SDK stacks, and preserve the separate full-graph audit. No vulnerability is asserted here; this finding is the confirmed graph/verification omission. Source: package-103, package-13, and DR-049's increased production-audit scope.

### P2 — pnpm lock regeneration drops the existing audited matcher overrides

Locations: `pnpm-lock.yaml:7` (removed top-level overrides), `:1701`, `:1978`, `:2275`; retained declaration at `package.json:120`–125.

The diff deletes all four pnpm overrides and changes the three development matcher consumers from minimatch 11.0.3 to 10.2.6. This is unrelated to SDK placement and loses the existing exact substitutions required by package-35. The locally available pnpm 11.25.0 explicitly warns that `package.json`'s `pnpm.overrides` is no longer read; there is no repository pnpm-workspace.yaml. The resulting lock is therefore not preserving the declared policy. Restore effective overrides and regenerate consistently with the supported pnpm toolchain. I did not install dependencies or run an audit, so this does not claim any particular security advisory or frozen-install outcome.

### P2 — Public install documentation still promises the old optional-SDK contract

Locations: `README.md:20`–30 and `:202`–220 (unchanged files affected by this change).

README says all Agent SDKs are optional peers, instructs users to add Claude/Codex SDKs separately, and says global Cligent requires separately global SDKs in the same tree. The new manifest deliberately guarantees acquisition of both stacks through Cligent, including nested ownership, making these directions materially false. Update local/global installation instructions and distinguish included SDK installation, remaining OpenCode/CLI prerequisites, native-host support and authentication. Source: package-33 and DR-049. Also update any verification that merely checks for old optional-peer wording rather than the new contract.

## Checks and positive observations

- Manifest placement is correct: Claude `>=0.3.321` and Codex `>=0.159.1` are ordinary dependencies; only OpenCode remains an optional peer, and optional/bundled dependency declarations were not introduced.
- Independently exact SDK development targets remain in package.json. Runtime descriptor values and compatibility ownership have not changed; only the legacy `peer` kind documentation was clarified. The open upper bounds and existing supported/tested distinction are preserved.
- The verifier retains exact runtime dependency shape, remaining optional-peer absence, optional/bundled-dependency guards, Node floor imports/help, TypeScript declaration consumption, protocol surface checks, SDK authority/decoy isolation probes and both audit invocations. These retained source checks were not treated as execution evidence.
- Existing development evidence consists only of `cligent-dev-install.log` (255 packages added), `cligent-build.log` (build command completed without recorded error), and `cligent-sdk-floors.log` (one file, two metadata tests passed). The metadata tests assert root manifest/lock ranges; they do not validate a packed production tree.
- Reviewer read-only check `node node_modules/typescript/bin/tsc --noEmit -p config/tsconfig.test.json` exited 0. This config intentionally excludes regular *.test.ts files, so it makes no claim about typechecking sdk-peer-floors.test.ts. `git diff 0550600 --check` exited 0.

## Pending evidence, not inferred failures

There is no supplied `test:distributable` execution log, isolated packed production install/readiness output, complete conformance/audit result, effective pnpm override regression result, or real branch-prerelease registry install result for this candidate. The global/nested matrix has not been run by this reviewer because dependency installation was outside the assigned read-only scope. The normal package-only global harness also stubs both tmux and glow (verifier lines 1110–1150), so it is not the real-glow formal acceptance harness specified by tmux-play-201 even if it later passes.

The requested macOS, Linux and native Windows SLC installation/compiler matrix, real Codex owner-login calls, and Claude/GLM calls require independent same-candidate evidence. None of those results can be inferred from a local build or floor tests. Their absence is an acceptance evidence gap, not proof of an SDK distribution runtime failure. The separate spex-playbook Skill remains out of scope.
