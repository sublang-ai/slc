# Explicit host input fixed — scoped source review for planned rc11

**限定复审 passed：本轮发现的P1 cached-input污染及P2稀疏数组复制变形已独立关闭，原有脚本授权正负控保持。范围内未保留P1/P2。** 这是拟rc11/cohort12的修订源码意见，不是已构建/冻结包或整体交付通过。

按用户最新优先级，修复后只执行原两反例和原六项授权控制，没有扩展额外探索或长回归。只读产品；临时源转译/脚本和自己的报告可写，未构建产品、未发Agent调用。

## 原始发现及关闭

P1：coverageMachineInput原WeakMap返回同一可变input供多次seed/replay。callerInput={counter:0}、真实initializer执行input.counter++，普通actor只counter1且START guard>=2不通过；旧checker依次见1、2…10并返回[]。caller原对象没变不能证明各actor input隔离。旧dist和独立source快照均真实复现，原JSON/源码已归档。

修订缓存只保存不暴露的framework template。freshMachineInput每次重新snapshot私有caller data、复制顶层framework值，并为catalog每个entry创建新对象，seed和actual replay共用这条fresh路径。独立同反例现在返回三个state-specific remains unproved；有限caller counter观察均1，原caller仍0，独立actor仍ready/counter1。早期静态context枚举没有callerInput时产生NaN，JSON表示null；该观察不被错误算成“污染”或迫使改产品，关键是不得出现caller初始化后的有限counter>=2。

P2：旧copy只用ownkeys count===array.length+1判断dense。values=[1];length=2;extra=2的keys正好[0,length,extra]而被接受，复制后length变1，checker可错误证明length===1，普通真实actor原length2留ready。

修订逐array key校验canonical非负安全整数索引且<原length，结合既有key count/descriptor限制拒绝extra补hole。独立同输入现TypeError coverage.machineInput，before-artifact拒绝；只有后续独立对照actor观察到原length2，未再发生错误接受或形状变换。

## 六项实际脚本授权控制

调用真实reviewArtifact、实际checker API、compiled-execution fidelity及engine contract；只对pin verdict/失败服务作明确负控注入。未改own artifact、Source、definition或pin文件。

| 控制 | 实际machineInput |
|---|---|
| owned pipeline + current verdict + exact definition/fidelity | 提供definition，SHA aaedd63cbb66fb857f033b1cdfa0c316ebf301f8e63cfca76967e3d28f6dbc80 |
| /tmp foreign同名完整copy，即使模拟current verdict | 不提供 |
| owned stale verdict | 不提供 |
| definition hash mismatch | 不提供 |
| compiled-execution fidelity拒绝 | 不提供 |
| 显式Source-fidelity拒绝 | 不提供 |

所有负控保留缺启动fixture的unverified；没有用后续gate失败追认前面授权。foreign正负比较包含实际相同FSM/GEARS/definition bytes及可用运行依赖，所以不能把单纯缺依赖当physical ownership拒绝。

脚本当前以physical canonical own pipelines/playbook、三种phase名、current pin provenance、精确definition path/hash和applicable无finding的compiled-execution合同为独立授权。已有Source finding也会在conformance前抑制输入。meta目录没有.text.md时日志仍可not-applicable；当前Spec85实际授权依据是current pinned definition/compiled-execution，而不是声称所有meta都有另一个已执行的Source-fidelity gate。普通domain workflow及artifact export不获得默认fixture。

## 证据与范围

最终独立Source快照Dj3owp，51模块逐文件与live源复算差异[]。两反例及六控制均重新执行，共8项窄检查；helper修正后的新测试全文/全套没有由本轮重复运行。

发现前那次standalone-host-input15/15通过保留在baseline证据中，说明原测试没有捕获两洞，不能把它改记成修订后suite通过。新修复必须由主流程后续build/冻结与相应delta结果绑定。

全部红/绿脚本、原始JSON、script bytes、source identity及SHA在host-input-rc10-independent-evidence。没有授予最终包安装矩阵、cold generation版本迁移、CI/npm发布、merge或整个SC3通过；这些不应阻止本次已按要求收窄的核心环境交付验证继续推进。

记录UTC：2026-11-17T23:29:34.441053+00:00。

终稿读取摘要：

- `slc/src/verify-coverage.ts`: `2eb5e0ad98d6303f783b5df1f0b5c807ebbad59b766876859ca8d3f7b5c81388`
- `slc/scripts/verify-artifacts.mjs`: `6b7b9bd37f572a2c8dd596fe91a0e903d1cd7da494104a581becd6bc00e812fd`
- `slc/specs/packages/verification.md`: `26388991505f5ded4426fb984888ea435269e0a61fc04f4b4a833adfea3d355a`
- `slc/test/standalone-host-input.test.ts`: `c58b5e58ffddc851fc564714ef5a87d6c109faf7a586540466742ac16c86ff1c`
- `slc/pipelines/playbook/link.slc/link.fsm.ts`: `1af2b2ab5c378ddc6617cfbc2173e01c4c5e4886e691e91f728115a2ab4223e4`
- `slc/pipelines/playbook/link.slc/link.playbook.ts`: `0b8602730bc60743b9a41e467d167cbaf74d8df8824fdc9c6e7c8978d8f59b60`
