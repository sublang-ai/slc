# Explicit caller machine input — scoped design opinion

**设计可支持，属于明确host职责的最小修正；本意见不是实现或新候选通过。** 不能改meta FSM删除definition guard，也不能回到“coverage:definition”或private-context恢复。显式checker调用方提供独立已知Source输入，经真实createActor({input})初始化，与artifact自声明coverageWitnesses.input是不同信任来源。

## 已核对的现有合同

- 原link.fsm.ts:93–96定义LinkMachineInput.definition为host-owned、immutable；282直接context=({input})=>({definition:input.definition})，START/interrupt guard检查该真实字段非空。
- linked link.playbook.ts:57–64的runtime options精确只有definition；snapshotOptions:88–107拒绝其他key，要求非空string。应同时核对公开validateOptions导出/实际factory调用链，而不只引用这个helper的名字。
- scripts/verify-artifacts.mjs当前133先做conformance/coverage，141之后才做compiled-execution fidelity，171之后Source fidelity；pin current分支目前只建立schema provenance，并没有自动授权任意definition输入。

因此当前缺definition的unverified是诚实结果。真实host拥有其请求中的definition不等于无参checker可猜出该值。

## 建议的职责边界

1. 公共checkFsmCoverage/checkGearsFsmArtifact可接收显式options.machineInput普通数据record，含义是**调用方拥有并为本次检查授权的真实startup fixture**，不是API声称已自动证明任意Source语义。模块导出的同名字段、runtime getter或artifact witness均不能自动变成该选项。
2. Validate options前于artifact/actor读取；拒绝proxy/accessor/function/custom/cyclic等非普通JSON数据，复制输入防止候选反向修改调用方原对象。保持有限字段/大小限制，非法input是明确调用/环境拒绝，缺真实required input仍unverified。
3. framework-owned coverageMachineInput catalog/self/state/authority值不可被caller数据覆盖。最窄第一版可拒绝已知host/private-key冲突；不要靠merge顺序静默接受冲突。definition是允许的独立普通Source字段；其它重命名/nested业务选项的授权由显式caller的独立Source合同负责，不从字段名推导许可。
4. 统一经真实createActor input传给initialization、entry/root guard seed、实际prefix和conformance+coverage的一次run；不在任何阶段变成restoredContext。per-call隔离，两个并发不同definition不得串值，所有预算/取消/报告协议不变。
5. artifact coverageWitnesses的nonempty input保持原拒绝/unverified；即使caller machineInput存在，也不能允许artifact witness覆盖或扩充它。events-only replay仍可以在本次已授权真实input上正常运行。
6. 普通CLI、emitters和任意domain artifact默认不提供这个值；不能按basename/字段名为一般required startup发明definition或其它值。独立review脚本仅在证明下述compiler-owned meta合同后显式提供。

## 独立review脚本的授权前置

需在coverage之前完成：当前pin verdict、pin记录的实际definition物理身份与所读字节hash、compiler-owned meta definition的Compiled execution合同、GEARS fidelity与Source fidelity、精确validated options/compiled-runtime输入合同。只允许预先明确的meta fixture，不能只因任意dir中碰巧有link.md、同名definition属性或生成FSM自己声明了validateOptions就启用。

当前脚本顺序是先coverage后fidelity，因此至少要将“允许提供input”的preflight独立前置。fidelity缺失、not-applicable、失败、pin stale或--definition选到别的文件时，不能先提供input再靠后面的报告追认。--definition覆盖值必须与current pin/所选host合同匹配或明确拒绝本fixture授权。

授权后值严格来自read(actual pinned definition)，经过公开validator/factory options合同，按原字节通过machineInput.definition送给actor；记录definition路径/hash、fixture来源及所选artifact/checker身份。无需将正文原样重复印进log。Source不是logger输出或artifact中自带definition快照。

## 最简单可行实现与必须补的测试

可把machineInput放进单次CoverageRun，由统一coverageMachineInput只合并允许的caller普通data并保留framework authority；这样所有existing初始化/驱动helper共享真实值，避免只改makeActor而静态guard seed仍用空值。公共conformance入口在创建run前的初始化路径和timeout estimator也需检查：无选项者不能偷偷读取旧run/store；估算器可保守处理缺input，不应产生伪证明。无须新增artifact可导出的fixture协议或generated-context修复。

至少红→绿：无input的原link仍unverified；实际current-pinned definition通过且观察initializer/entry真正读到同字节；空值/错误类型被公开validator拒绝；stale pin、fidelity不符、错误definition文件不得授权；caller input原对象未变；并发两个input隔离；framework authority冲突拒绝；artifact exported machineInput被忽略；nonempty witness仍拒绝；普通required-domain fixture不被自动救活。再跑实际静态gate及相关source/standalone/emitted边界。

已有committed meta emitted coverage suite使用自己的.slc-verify快照，不能把其旧支持库通过当成新API默认路径证明。若将来重生meta emitted suites，所需host fixture也要有同等独立来源，不能让通用emitter凭artifact猜值；本轮若只修review-script静态gate，应明确未给无fixture的默认emitter开后门。

## 不授予的结果

当前只读设计意见，不证明API实现正确，不证明static gate已绿或全部meta phases都有已授权fixture。API/executable变化需要新不可变候选（计划rc10/cohort11）；freeze10/rc9安装和旧实测保留实际版本，不能覆盖。没有新增cold call、发布、CI或merge授权。

记录UTC：2026-11-17T23:18:19.656614+00:00。

只读输入摘要：

- `slc/scripts/verify-artifacts.mjs`: `bdab3454eb3fc96b65a30ca28e77788397cb29be948bff89b5f777bbd81b99f0`
- `slc/src/verify-coverage.ts`: `0b9581a4b0566e2d30bb8ebc3f95651d415f6dd93c052b95865638da22c8a0f8`
- `slc/pipelines/playbook/link.slc/link.fsm.ts`: `1af2b2ab5c378ddc6617cfbc2173e01c4c5e4886e691e91f728115a2ab4223e4`
- `slc/pipelines/playbook/link.slc/link.playbook.ts`: `0b8602730bc60743b9a41e467d167cbaf74d8df8824fdc9c6e7c8978d8f59b60`
- `slc/specs/packages/verification.md`: `cac59a18e03a9b07b2dccf98c1d1ff11e72d53531955401140e4604cb8b217a1`
