# Final rc.6 classifier — narrow independent review

- Acceptance ID: `AT-slc-global-20261117`。Reviewer: `/root/slc_impl_review`。
- **结论：本轮窄范围 passed，无遗留 P1/P2。** 只覆盖 rc.5→rc.6 新增的已观察 SDK usage-limit / unexpected-status 环境消息识别及既有类别优先级。
- 未执行构建、未修改产品源码，未调用付费 Agent；未授予候选安装、冷生成矩阵、npmjs/公共发布、CI 或 merge 通过。

## 本次修正及独立控制

实际读取当前 `src/check-report.ts`，新增规则为行首锚定的 `You've hit your usage limit` 与 `unexpected status 401/403/429`，沿用 reason 列表的前导空白/`-` 处理。明确 native forbidden-side-effect、结构化类别、TS artifact、unverified 与 cancellation 的判据在 transport 启发式之前，没有回到任意子串匹配。

已读 `/tmp/slc-usage-regression-red103.log`：两条新增 fixture 原本都返回 artifact，断言 environment 失败；其它三条被筛选的既有 transport 用例通过。当前 selfhost.test.ts 保留这两个确定性 Agent error fixture，经真实 runSlc/interpreter 入口验证；没有将它们描述为新触发的真实 provider outage。

我的独立 `/tmp/slc-rc6-classifier-controls.mjs` 通过 Node 原生 TypeScript import **直接执行当前 src/check-report.ts**，不依赖可能过时的 dist，也没有运行 build。**16/16 控制通过**，包括：

- 两条实际消息、401/403/429 家族及 phase reason 的缩进/前导 `-` → environment。
- 已有 429 中文 quota 消息 → environment。
- 明确 artifact、TS2322、native permission finding 即使含新消息片段仍 → artifact。
- canceled / checker-failed / unverified 的明确类别仍保持其类别。
- 非消息开头的引用及非匹配数字不触发新增规则。对未覆盖的500等字符串，本次仅确认未扩展规则，不把旧默认分支视为所有未来服务错误的正确语义判断。

输出和实际源码摘要保存在 `/tmp/slc-rc6-classifier-controls.json`。

## 当前定向测试记录

已独立核对主 Agent 的 `slc-final-rc6-focused.json / stdout / inputs.json`：

- 4 test files，**79 passed**，exitCode 0，duration 59.93s。
- 涉及 selfhost、standalone-lifecycle、standalone-witness、standalone-return-contract。
- 收据 inputsUnchanged=true；我另逐项读取其 **727 个输入文件**，与当前字节摘要全部一致，输入清单本身 SHA 与 receipt.inputsSHA256 也一致。

这是对本次当前版本原始记录和输入一致性的独立核对；79 项由主 Agent运行，**没有称为我重新执行79项**。我的直接执行为上面的16项窄控制。

## rc.5 与 rc.6 包字节边界

已逐成员比较实际两份 tarball：209 文件中 **205 同字节**，无新增/删除；只改变：

```text
dist/check-report.js
dist/check-report.js.map
dist/check-report.d.ts.map
package.json
```

唯一可执行代码变更是 classifier。package.json 解析后仅 version 从 `0.23.0-rc.5` 改为 `0.23.0-rc.6`；actual rc.6 tarball 的 classifier JS 与当前 dist 同字节。generation/phase/prompts/checker/lifecycle/ABI 没有因这一修正变更。

rc.6 tarball SHA：`952e52d077171b31d052e6f80d42ecb1049367d9138b67b335276e971a4a1d33`；cohort07 SHA：`d29e30a43d5e373395d845d662cde642c0960b23bee8030507338c393ecd33f0`。其 PB19.1.0-rc.4 与 Cligent0.40.0-rc.2 的包身份沿用原冻结字节。

因此先前 classification-v5 的**有条件选择性影响分析**可按该窄增量继续使用：新增失效/补证范围是这些已观察 usage/auth 环境失败、当前 package/compiler identity 和安装/重验；不能把 rc.4/rc.5 冷观察改写为 rc.6 冷观察。需要当前版安装、真实 cold 桥接、要求内 current checks/reuse 和失败分支补证的边界没有被本次小补丁豁免。

## 已按原字节归档的旧报告

按交接要求，已复制且校验 source/destination SHA 相等：

1. `/tmp/slc-v5-recheck-rc4.json` → `evidence/development/reviews/slc-v5-recheck-rc4.json`。
2. `/tmp/slc-v5-old-cli-check-delta.json` → `evidence/development/reviews/slc-v5-old-cli-check-delta.json`。

这两个文件仍是先前 v5 评估中的 **29 份 rc.4 归档重验**、以及 **76 份 rc.4 Agent 工具 check 返回中6份非空 findings 对 rc.5 classifier 的类别差异评估**；未改写时间、版本或内容，不是新候选的运行记录。

本次另把这6份旧非空 findings交给当前 rc.6 classifier，categoryChanges 仍为 **0**，记录在新的 `/tmp/slc-rc6-classifier-controls.json` 中。该计算是 rc.6 源码推论的补充，**不是重新运行旧模型，也不是rc.6新冷编译证据**。

## 精确版本

终稿读取 UTC：2026-11-17T21:20:24.630156+00:00。

- `slc/src/check-report.ts`: `2b3aded603ff3b196f1a664c515b79574b0d453f8a7e6f34a3a80e352deabdc4`
- `slc/src/managed-compilation.ts`: `c7d0dba6021f8e731d0cee6c87dc2ddfd50e39d5ca68b700056d1023b9dacb09`
- `slc/test/selfhost.test.ts`: `5307c4ed06fab7cf1623fc0a07d368612906d7d628a6536a36ce680eb48590ff`
- `slc/package.json`: `d8adca10d03aa8aeaf78622396597105ce171ed485c74d21fbdd5d66c59353a9`
- `slc/dist/check-report.js`: `1143de5c9cf3c2d1cba0c588c31402a4b3934a2b6b2cbd39db450bc6d866244d`
- `slc-global-delivery-20261117/evidence/candidate-cohort-07/frozen-cohort.json`: `d29e30a43d5e373395d845d662cde642c0960b23bee8030507338c393ecd33f0`
- `slc-global-delivery-20261117/evidence/alternative-branch-registry/sublang-slc-0.23.0-rc.5.tgz`: `effaac36846956af35900cb5094f5f0cbf0a33cffd030531af2d091ed6faeb88`
- `slc-global-delivery-20261117/evidence/alternative-branch-registry/sublang-slc-0.23.0-rc.6.tgz`: `952e52d077171b31d052e6f80d42ecb1049367d9138b67b335276e971a4a1d33`
- `slc-global-delivery-20261117/evidence/commands/slc-final-rc6-focused.json`: `868e401ddbf736df2c9bedb5cfb8eea59ea8b42421c0166cf9568d51ca4cae2b`
- `slc-global-delivery-20261117/evidence/commands/slc-final-rc6-focused-inputs.json`: `d6886f157411a8769fe202706ee705bcc7051e4a076ce777c826f50d03ba2e54`
- `slc-global-delivery-20261117/evidence/commands/slc-final-rc6-focused.stdout`: `900fee6f6e7d467bf0d288be8a4da834e001bb662f56d961030e0395bc794932`
- `slc-global-delivery-20261117/evidence/development/reviews/slc-v5-recheck-rc4.json`: `b5d87aa6c4a1983e14d0e4ad9810469e452fda0e7da060aefdae178d95c8af5e`
- `slc-global-delivery-20261117/evidence/development/reviews/slc-v5-old-cli-check-delta.json`: `222e737d6ce75992d17a2f3fd2ff973cfcb9e8dd5e4053adffc3b8737bc73e02`

独立窄控制脚本 SHA：`6500c4cf5fc00e5b0275a9fc09939ecc8ee317dad453f01047ba2fe956c852ee`；其结果 SHA：`afc60d8252202ad1ee2ad4f7825d463c3bd88046220ac3db5c2b65876f4f3991`。
