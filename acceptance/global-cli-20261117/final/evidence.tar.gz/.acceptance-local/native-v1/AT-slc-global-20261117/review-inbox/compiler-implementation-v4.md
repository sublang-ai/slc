# Compiler implementation v4 — scoped independent re-review

- Acceptance: `AT-slc-global-20261117`。Reviewer: `/root/slc_impl_review`。
- **结论：本轮限定范围 passed。v3 的 S1/S2/S3 已独立关闭，SC3 design-v4 的相应补充覆盖有依据；本轮临时发现的 authenticated-report/audit-drain P2 也已修复并独立复测通过。最终范围内未保留 P1/P2。**
- 范围严格限 S1 非空 witness Source 许可、S2 checker IPC/完整报告、S3 Node/network 权限边界，及 SC3 v4 对应设计。没有评审尚未完成的完整 pack anchor，也没有授予未执行矩阵、公共发布、registry acquisition、CI、合并或整体交付通过。
- 只读产品源码/specs/设计与收据；仅在 `/tmp` 制作独立源码快照、反例和测试副本，产品目录未修改，未启动付费 Agent。

## 实际版本与执行方法

为避免旧 dist，本轮用 `/tmp/slc-v3-freeze.mjs` 从本次 live src 转译全部 51 个 TypeScript 模块到临时 dist。首次快照 `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-dOag0P` 用于原反例及 17 项定向检查；主 Agent 修复本轮新发现的 audit-drain race 后，重新冻结为 `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-MHrMod`，再跑原 race 反例和最终两组测试。终稿逐文件比对 live src 与最终 source-identity.json，变化列表为 `[]`。

测试副本只把原测试里的 `../src/isolated-check.js / verify-coverage.js / compilation-audit.js` import 重定向到该快照的 dist；没有修改测试的 inputs、assertions 或逻辑。依赖仍由当前安装树解析，Node 为 v25.5.0。本方法验证当前 checker 源码行为，**不是重新构建或安装可分发候选包的证据**。

最终 live `slc/package.json` 已变更为 `0.23.0-rc.4`；临时快照在该版本标记变更前复制的 package manifest 保留旧标记，但本轮直接 checker 反例/测试不依赖 package version，51 个实际执行的 src 模块与终稿 live 内容相同。不能据此声称 rc.4 tarball 或安装图通过。主 Agent 已说明 rc.3 的短时开发预检中止并保留记录；本意见没有把新代码结果追授给旧包。

## S1：nonempty witness.input 没有 Source proof 时保持 unverified — 通过

已读 `readCoverageWitnesses`、外层 cause 分类，以及修改后的 `verification-74` / DR-068。

- `/tmp/slc-v4-renamed-witness.mjs` 使用 v3 完全相同的错误 guard 和 `input.startupSettings.allowedChildren`。baseline 仍有四项真实未证实 findings，旧绕过现返回：`unverified: public coverageWitnesses: nonempty witness startup options require an independent Source-derived validation contract; public events-only replay remains available`，不再变成空 findings。
- 当前代码拒绝任意 nonempty 普通启动切片，未把 generated FSM 自声明当独立 Source 许可。reserved authority/非 JSON/private event 的 malformed 拒绝与“无独立选项证明”的 unverified 分类保持区分。
- 当前 permanent witness 测试包含合法 events-only absolute path 正控、五种 authority 字段负控、xstate internal event 负控及 renamed/nested nonempty input 负控，8 项在最终测试中实际通过。

因此关闭 v3 S1。本意见确认的是已选定的保守边界；不声称已经支持需要非空 startup-input proof 的任意工作流。

## S2：candidate IPC 不替代完整 checker 报告 — 通过

已核对 `isolated-check.ts` 的随机 per-run capability、schema/job/status/findings/observations 检查及 lifecycle initialize/dispose 完成判据；`verification-worker.ts` 在任何候选 import 前闭包捕获 report sender，移除 artifact-visible process.send，token 不写进环境或暴露的候选输入，接收后从原消息删除 token。

- `/tmp/slc-v4-ipc.mjs`：普通 `process.send({kind:'runtime-loaded'})` 的旧候选仍有必失败 factory。修复后返回 `artifact: entry lifecycle failed: constructor must fail`；删除额外 IPC 的同一候选也返回相同真实失败，旧 `findings=[]` 绕过未再出现。
- permanent tests 实际验证了 telemetry、通过 `_send` 发送错误 capability 的伪造完整 envelope，均不能盖过构造失败；exit0 没有完整报告时拒绝；in-flight cancellation 拒绝并等待子进程结束清理；inert entry 的真实 init/dispose 仍通过。

### 本轮发现、修复并复核的 audit-drain P2

初始 v4 实现收到 authenticated report 后先等待 auditEvent 才设置 settled；子进程 exit0 可先触发“没有报告”。独立 `/tmp/slc-v4-audit-completion.mjs` 在实际 compilationAudit 上模拟已有写入队列，得到了真实 inert init/dispose 报告却误判 checker-failed。原始事件目录 `.../T/slc-v4-audit-cxPLXZ/` 同时存在完整 checker-report 与错误 checker-finish，发现已立即发给主 Agent。

主 Agent 随后在通过完整校验后同步锁定完成状态、清理 timer/abort listener，再排空 audit queue。最终快照中 `/tmp/slc-v4-audit-completion-fixed.mjs` 用同一 queued-audit 反例返回 **[]**（目录 `.../T/slc-v4-audit-d9ZNoK/`）；无排队 control 也为 []。新增 permanent backlogged-audit 用例实际通过，同时断言完整 initialize/dispose observations 和成功 checker-finish。因此本 P2 已关闭，未作为终稿遗留问题。

## S3：supported Node 与 native denied-network 边界 — 通过

已核对 `engines >=25.5.0`、README、standalone-compilation/DR-068 的同步修改，及 Agent work 前的 feature preflight。独立 checker parent 在不具备 native network permission 的 runtime 上先返回环境拒绝，child 也在加载 artifact 前验证实际 denied-network 状态。

独立 `/tmp/slc-v4-network.mjs` 启动真实本机 loopback server，先从普通 parent client 发送并确认 `POSITIVE_CONTROL`，证明目标真实可达。候选 init **await** Socket 的 connect/error Promise，不用 fire-and-forget 推断没有 I/O。

- **Node25.5.0**：probe 返回 artifact forbidden verification side effect / connect ERR_ACCESS_DENIED；server 最终只收 `['POSITIVE_CONTROL']`，没有 BUSINESS_WRITE。
- **原 Node23.6.0 二进制**：调用当前 checker 立即返回 `environment: compiler verification requires Node >=25.5.0 with native network permissions; upgrade Node before compiling`；server 同样只有正控字节。原 v3 中旧 runtime 真正发生 BUSINESS_WRITE 的反例已关闭。
- final permanent lifecycle suite 也使用独立真实 loopback 正控、await Socket error，并断言 server 仅收到 fixture-positive。

本结论只覆盖声明最低版本与已复核的能力边界，不把 Node25.5.0 本机执行扩展成其它 Node/OS 的实际平台通过。

## SC3 design-sc3-v4 — 相应修订通过

已实际读取 `evidence/design/SC3.json` 和 `case-design/design-sc3-v4/result.json`，definitions SHA 仍为 `15e40cc1436119f3fbc6949406b2b048d93d1b3265aecb437b28684875f34d33`。

- `TC-witness-authority-check` 现在明确要求 renamed/nested nonempty startup input 的独立 Source proof，预期 unverified，并保留 events-only 正控。
- `TC-init-effects-check` 现在明确要求 telemetry/forged IPC 不掩盖必失败 constructor、真实 loopback 正控与直接 Socket、declared minimum/older-runtime 的环境拒绝。
- `TC-budget-check` 现在把 in-flight abort、worker 无报告退出及结束后无活 checker/actor 的观察写进动作，补上 v3 仅在 expected 中声明取消/崩溃的缺口。

这些补充均来自原有安全初始化、独立检查和 cause/cleanup 契约及已知失败，没有新增无依据的产品行为。本轮只认可上述设计修订及实际执行到的定向实现；未把 SC3 其余用例或其它场景改判为已执行 passed。

## 最终独立定向执行

命令使用当前源快照及原测试副本：

```text
node /Users/boboyang/work/sublang.ai/slc/node_modules/vitest/vitest.mjs run \
  test/standalone-lifecycle.test.ts test/standalone-witness.test.ts \
  --root /var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-MHrMod
```

最终真实工具输出：

```text
Test Files  2 passed (2)
Tests       18 passed (18)
Start at    03:16:59
Duration    12.85s
```

分配为 lifecycle 10 项（含新增 audit-drain）和 witness 8 项。没有把前一版 17 项输出误写成最终 18 项；本轮唯一源码增量修复后已重新执行当前两份测试。

## 未覆盖边界

完整原生 OS/backend/父目录矩阵、Source 全量 regressions、pins refresh、候选包构建/完整字节 anchor/安装、LAN 或公共 registry 证据、CI 和 merge 都未由本轮执行或授予通过。不要将本 scoped passed 用作完整交付 gate。未做任意恶意代码的通用 sandbox 安全证明；本轮验证的是报告来源、约定的当前源码权限/副作用控制及已知反例闭环。

## 精确摘要

终稿 UTC：2026-11-17T19:18:57.711354+00:00。

- `slc/src/isolated-check.ts`: `f973b2b373385bb1d21a5e651be38d5b81ae0f7439429cdc563c09cf1fddbc83`
- `slc/src/verification-worker.ts`: `93fdbb30310e4589bc023873a4a6d911b913e9fd25b46a60f3bcce7869f83162`
- `slc/src/verify-coverage.ts`: `79d1d28e53dc1b0d1a8e3de1036d3b9baddb1a9b236300eeda6dd1b733713f47`
- `slc/src/managed-compilation.ts`: `8121e0fc245e6cc06b1a386b17da842adc9518f209479afb7d3ddc6044416da7`
- `slc/src/compilation-audit.ts`: `e2d1aec811f684c29b05cbf1233dc549b373c403d872c9bb92b6720d296f3be5`
- `slc/src/errors.ts`: `cfef3f047f15f3b9e153f149adefc8f640616bcc6b0f48abe5476bb93c7f3622`
- `slc/src/check-report.ts`: `5a1382fdd3e96a8eca3872766abdc3efe68bd594fd42d957879b4bbf7f2d64e1`
- `slc/test/standalone-lifecycle.test.ts`: `03c444902bd2372247f17f8e480bd2e2acbc07b8bc87379ebeaa8c49f298fe3c`
- `slc/test/standalone-witness.test.ts`: `f4984caa4df939d6ab520a75159999ab37cfbce5ec4fd54c8d9e3dce1375af66`
- `slc/package.json`: `7bda32fdb24d0c6a83eab57693a97c737aead0ac3a85510e0aa219b2d06e20a8`
- `slc/README.md`: `db6d1166080f6af9316f666af03fa493885810f9fb2d64e6e83daebc7fe34fe9`
- `slc/specs/packages/verification.md`: `3739897adb4de119aa4354951b8c0a9a1b0c690799491f7025f52b6d5ade8376`
- `slc/specs/packages/standalone-compilation.md`: `5fb1208c404aa1726837d2fd6c658658703705d9fcd661514108e1c7c251ac0e`
- `slc/specs/decisions/068-standalone-compilation-environment.md`: `78e8f1cebc3b5a74932dbde19577e2321544cb8e8224714b5d35d30d77783488`
- `slc-global-delivery-20261117/evidence/design/SC3.json`: `0bc655dff2fc2c856f61373c6340065bc350cf1dada7e2b0b0ebd90820f5c2b5`
- `slc-global-delivery-20261117/.acceptance-local/native-v1/AT-slc-global-20261117/case-design/design-sc3-v4/result.json`: `fbd3f148b9316dc7389ee454fe7413738d61ce9e73f07c247e7bfd7f44955602`

实际运行快照/反例：
- `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-MHrMod/source-identity.json`: `100d8230f63a18771b5fccd4d570a62c5ddf1ffe03750c349addada17a42cb19`
- `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-dOag0P/source-identity.json`: `72eb061b2982a972f1b03a18f7267dde6e0f75cdd64855e7585381471dfc9643`
- `/tmp/slc-v4-renamed-witness.mjs`: `7aa7565d71858b220fbc160e38bad1da6a410dab74f946a55a4f802e0c266f76`
- `/tmp/slc-v4-ipc.mjs`: `4b8c40ad605b15fcad803bdfd0359ab551fe3ee887b2ecb2f13366c97caad4d6`
- `/tmp/slc-v4-network.mjs`: `d87e86961d9942497f1dcd294d9b90c755fd3bb47d3c3934c42c64d5ca411955`
- `/tmp/slc-v4-audit-completion.mjs`: `b252a65590ee19b5654e80e44b870b1bfd9d2807be8f6abb7525b14da091e4c0`
- `/tmp/slc-v4-audit-completion-fixed.mjs`: `a7ac23bcf02f86a31d1b1a585068cc7dcdc43aed93889067b28ca3781106e165`
- `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-MHrMod/test/standalone-lifecycle.test.ts`: `1ec5172cabf81638303227770dc85f761914a5cfeaecaff3c0fdb267a1ab24d9`
- `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-MHrMod/test/standalone-witness.test.ts`: `702a4ff298db68a9d696938dd5057ce08703f3a68c8934802bd08320b44651b6`
