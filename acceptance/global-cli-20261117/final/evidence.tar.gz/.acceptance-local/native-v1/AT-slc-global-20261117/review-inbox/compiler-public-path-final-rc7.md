# RC7 public-path reachability — independent finding

**needs_revision / P1：真实可达性检查把合成 context 当成已到达状态，产生 coverage false-positive。** 本意见只读产品，未修代码；只在 /tmp 添加独立 trace、普通 XState 正负控，并将自己的复现材料保存到本目录。实际执行 Node25.5.0 和当前 rc7 dist（本轮主 Agent 只新增测试，产品/包字节未变）。

## 独立实际结果

复现脚本 `public-path-rc7-independent.mjs`、完整结果 `.json`、精简工具输出 `.stdout` 均保留。原测试 fixture 的 machine 函数原样提取，仅去除一个 TypeScript assertion；用 XState createMachine 重建并添加无副作用 entry trace，保留原 guard/action/actor implementations。

无 witness、缺 path、relative path、absolute path 四种检查均返回 findings=[]。所有 observed work entries 却直接为 BOSS_INTERRUPT，context.path='/tmp/slc-verification/task.md'、prepared='work'。没有 ready/prepare entry，没有真实 START 迁移；原初始 context 是 path=''、prepared=false，真实 prepare 的赋值应为 prepared=true（布尔）。这说明合成值不是正常前驱赋值的产物。

同一普通 XState actor：初始 BOSS_INTERRUPT、缺path START、relative START都留在ready/context未变；合法absolute START真实经过ready→prepare→work，prepared=true，再发interrupt成功。

更强负控：在 /tmp 的 fixture副本将唯一START guard改为()=>false，未改根interrupt前置条件。此时普通actor的合法absolute START和BOSS_INTERRUPT都留在ready，初始context始终未变；**检查器仍findings=[]**。此负控又不添加任何entry trace直接重建普通machine执行，仍是[]，排除了trace重建改变语义的解释。该工作状态不存在可观察的公开初始路线，不能用additive witness或自动找到合法替代路径解释通过。

## 具体根因调用链

1. `interruptDriveForRef`（src/verify-coverage.ts:1437，赋值约1482–1507）用probeGuardAssignment，`varyExistingContext:true`，把context.prepared/path调成能使interrupt guard成立的值，再返回assignment.context。事件payload合成与context可达证明混为一体。
2. `makeActor`（1019，1073–1085）收到restoredContext就调`persistedSnapshotWithContext`（992），从未启动seed的snapshot覆盖context并清children；createActor(snapshot)跳过真实初始entry及前驱动作。
3. 根interrupt enterability检查（5014→5037，5114–5125）只要drive.satisfiable，就把drive.context传给makeActor，send BOSS_INTERRUPT并以atState成功作为覆盖。只有satisfiable=false才进入真实searchCoverageEntry fallback（5050起）；本例合成context让fallback根本不发生。
4. `captainProbeActor`（3794，3830–3856）也优先选择satisfiable interrupt并将drive.context交makeActor，随后scripted outcome得到done/failed轨迹。这是本fixture普通captain各结果被接受的第二处同源路径。
5. `childCoverageDrive`（2644）→`searchCoverageEntry`（3020）→`replayCoveragePath`（2875）同样能队列化带drive.context的合成根路径。现有`trustedEntry`仅限制部分literal观察，不能普遍阻止replay target被当作covered。
6. `entryDrivesForRef`（1529，1581）亦允许varyExistingContext:true；即使仅关闭interrupt上下文合成，另一public-entry合成context通道仍需检查。parallel/predecessor helper也多处向makeActor传drive.context，不应仅修本fixture的一处入口。

`absolutePathCandidates`（5950）确实自动给绝对路径候选；这是允许的event payload合成，不是本反例里经过START设置context.path的证据。

## 需求、设计与最小修正边界

`verification-11`表明确要求：初始不可得的interrupt context必须通过实际predecessor/public-event replay先建立，private snapshot substitution不证明可达。`verification-74`要求真实initial state、正常guard/actions/ordered transitions及无context patch。此处是现有合同的实质违反。

最小安全边界：ordinary guard satisfiability可以枚举context作为局部诊断，但**任何reachable-entry/interrupt coverage成功都必须来自真实初始actor或同一真实prefix产生的actor/snapshot**。求得的context不得作为reachable证据恢复到actor。对当前初始context不成立的interrupt，使用真实public-entry/witness+predecessor重放；到达后在真实context上验证并发送interrupt。找不到有预算的真实路线时返回unverified和具体未证实义务，不能凭合成context通过，也不能据搜索失败判定artifact数学不可能。

不要全局禁用guardSatisfiable的context搜索：`test/verify-coverage.test.ts:3503` conjunctive-guard、3525 helper-bound comparison这些局部可满足性测试是有意允许枚举的；3972 shared-action-arm diagnostic也需区分“局部可选择”与“真实可达覆盖”。而3844 `restores satisfying context before driving a guarded parallel parent`是高层coverage=[]的旧预期：fixture初始phase=idle/topic=''/reviewScope=''（1000–1017），该测试不能凌驾新明确可达合同，应补真实前驱改变context后证明，或保留无前驱版本预期unverified。不要仅把新反例改成通过来保留这种上下文恢复期望。

保留已有真实路线正控：4319 static-child prior results、4463 public-after-interrupt实际观测、5384 reached primitive predecessor、5754 dead predecessor refusal；补初始entry/actions、always前驱、ordered guards与budget的轨迹。至少要求本例合法START→prepare→work（prepared=true）后interrupt实测，dead-initial与未实际观察的路线保持unverified。

**witness语义需另行精确化。** 当前witness是补充队列（searchCoverageEntry:3080 unshift，但普通drive仍保留），不是exclusive test scenario。单个缺/相对path witness不能证明其路径；若普通search真正从initial发现另一个合法absolute START，整体coverage可以成功。因此冻结TC-public-path的“invalid/absent remains unverified”不能无条件解释为“无论其他真实路径都必须失败”。应以可观察轨迹断言bad witness不贡献证明，并加无其他已观察合法路线的负控；若保留全局unverified期望，夹具需排除其他可发现合法路线。本轮不是据此放行产品：实际trace和dead-initial已独立证明真绕过。

## 证据版本与影响

主Agent红灯`slc-final-sc3-detail-tests.json`真实19项、17pass/2fail被保留。新增四个Source omission通过只证明该测试增量，不能改写旧rc7 full输入记录；旧full当时727项匹配结论保留其时间范围。我的前一SC3库存已标完整path证据不足，现此项进一步升级为已观察产品P1，不能被原库存的机制证据覆盖。此前v4意见仅限nonempty startup witness/IPC/Node边界，不曾授予整个reachable-search通过。

修复会改变checker executable/packaged行为，应出新候选；rc7安装/bridge/冷生成证据保持rc7实际版本。必须重测受影响的coverage producer/consumer/retained/emitted入口、root/parallel/public/predecessor路径及本反例，不能只以测试文件增量说明字节未变。完整原生矩阵复用边界应另作影响分析；本意见不授予CI、发布或merge。

## 本轮摘要

记录UTC：2026-11-17T21:43:14.499755+00:00。

- `slc/src/verify-coverage.ts`: `79d1d28e53dc1b0d1a8e3de1036d3b9baddb1a9b236300eeda6dd1b733713f47`
- `slc/dist/verify-coverage.js`: `a1614b6ad3b1876b7146df3c7c57498495a5313aa69542de93c0d4b340970c16`
- `slc/test/standalone-witness.test.ts`: `fffec16fa2eeb5e7afb971a52502e594e2e1fe60cbd3f23a693afe4844e4dc93`
- `slc/test/verify-coverage.test.ts`: `75a7254d5adeeb0bc99259953b8b10f90d2e4f93c344e6388fc5f99944f17a03`
- `slc/specs/packages/verification.md`: `3739897adb4de119aa4354951b8c0a9a1b0c690799491f7025f52b6d5ade8376`

## 追加：对全局 entry-drive 修正范围的明确答复

应统一约束所有会贡献实际actor可达性证明的entry/interrupt drive；只在coverageWitnesses存在时加限制会使无witness路径继续伪造证明，是按输入形状规避反例。verification-11对interrupt已有独立明确要求，因此并非把74的optional witness规则扩大到不相干的局部求解。

具体最小边界为：entry驱动的guard求解只枚举真实public event payload，使用真实initializer所得context（initializedMachineContext，不能用initializedCoverageContext中覆盖的synthetic guard values）并assignContext:false；实际actor从正常initial启动，不以求解器context调用persistedSnapshotWithContext。需要前驱context时保留/重放真实actor路径再发送interrupt。即使context值看似相等，也不应以人工初始snapshot取代entry/actions执行证明。

保留纯guardSatisfiable及ordinary arm局部可满足性context枚举，明确它们只给局部诊断，不自动给reachable=true。调用点应区分这两个命题，而不是全局禁掉probeGuardAssignment能力。仅改varyExistingContext:false不够：assignContext默认允许补缺字段；仅固定context却继续把initializedCoverageContext/synthetic snapshot传入actor同样不够。

无witness基线若没有实际发现有效初始路线，应unverified；有真实自动发现START路线或合法witness，应保留verified。不能把“某个坏witness未到达”解释为“整个FSM绝无其他路线”，也不能把“guard在某context可满足”解释成“该context已真实到达”。旧restore-context高层正控若没有实际前驱，应该修改为unverified或补合法真实前驱，而非保留伪证明以求suite绿灯。
