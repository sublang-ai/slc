# AT-slc-global-20261117：54 条历史执行证据复审

结论：**51 条在各自真实范围内 passed，3 条 insufficient_evidence**。未发现未解决的导入字节、最终产物、检查链或历史锚点不一致。该结论只适用于本轮 54 条外部观察，不是原 SC2 全冷生成矩阵、公开 npm 安装、CI、合并或整体发布结论。每项意见均为 `covers: []`；未登记、未编辑原执行或产品。

| 实际模式 | 条数 | 结论 | 可证明范围 |
|---|---:|---|---|
| cold-generation，Codex × macOS/Linux/native Windows，CommonJS 父目录 | 3 | passed | 从 Source 经真实安装 CLI 与实际 gpt-6.1-sol 调用，经过五阶段和当前最终门禁的编译 |
| cold-generation，claude-code/GLM × 三系统，CommonJS 父目录 | 3 | insufficient_evidence | 当前真实调用被 HTTP429/provider1308 五小时额度拒绝；不能证明成功编译 |
| retained-current-gates，8 父目录 × 3 系统 × 2 历史输入来源 | 48 | passed，限环境 delta | 新建空子目录后先放入独立锚定的历史 accepted bundle，运行当前实际 CLI `--complete`；零阶段、零 Agent 调用 |

## 固定身份与证据层次

- 定义基线 SHA256：`15e40cc1436119f3fbc6949406b2b048d93d1b3265aecb437b28684875f34d33`。
- 冻结 cohort12 SHA256：`caa119f79235be47b82923f19c12a2cb85ea3d9f27277a731627016eae790c30`。
- 实际 Source SHA256：`af0a67466cfb4d5efb79caee263ee433ebc6a9fc7090cd6fbb071a1a998ab969`。
- 被测包为 SLC `0.23.0-rc.11`、Playbook `19.1.0-rc.5`、Cligent `0.40.0-rc.2`。独立复算三个 tgz 及其所有冻结文件摘要（209 / 175 / 263 文件）和冻结源码清单摘要；安装结果记录与冻结包一致。
- `sourceHead` 与 source inventory 是冻结包的源码溯源字段，不能据此推断当前工作树、CI 或公开注册表状态。实际执行身份来自 raw compile receipt、native identity、invocation 事件与选定 runtime；结论来自这些实测材料。
- 本轮没有运行产品测试、重新编译、调用付费 Agent、修改产品、登记复审或扩展用例。全量测试数量（SLC 2111 pass/2 skip、PB 3248 pass/34 skip、SDK 2353 pass）仅为交接信息，不冒充本轮独立执行，更不等于 54 条通过。

## 独立复算

逐目标核对 history result、请求和原始收据身份，复算 **3405 个 artifact 引用、3189 个执行输入引用、1074 个快照引用**；逐条比对 rawCase 的 compile/result/stdout/stderr 与导入副本、模式、参数、工作目录、时间和返回码。native 版本收据及 entry-check 收据/流摘要也已核对。

对 51 个成功记录，从**导入 original** 只读调用已检查过源码的后置函数，独立重算结果与已存 final-audit 除核对时间外一致；还核对最终 manifest 的实际字节与 runtime、CLI 身份、最终 checker 输入快照及完整 start → report → finish，成功 lifecycle 的 initialize → dispose 顺序。冷生成另有 continuation，retained 只要求其真实运行的 fsm/linked/lifecycle。后置函数的 `verified` 没有被用作整体设计或发布通过。

48 个 retained 记录的六个历史输入锚点，分别回到 history05 original artifact 和独立 accepted receipt 字节；当前 canonical FSM/linked 文件均保持原 accepted SHA256。实际 events 的 phase/Agent/preflight 为零，不能证明当前 provider 可用。检查了记录中的父目录预期字节、兼容/冲突运行时夹具身份、Git 祖先、父目录/祖先前后相同、无根项目脚手架，以及编译器选定的运行时链接。`emptyBeforeCopy` 说明放入历史 bundle 前为空，不能表述为 `--complete` 从只有自然语言 Source 的空环境重新生成。

native Windows 的 **18 份单 gzip 原生采集、974 个捕获文件** 全部复算，与完整 `complete-native-12` / `complete-native-retained-12-v2` 及导入副本一致；原 archive 比较差异均为 0。这保留了原生路径和长路径深层快照，不以 WSL 或短截目录替代。

## 额度拒绝和有限缺口

三次 GLM 冷生成均只有一次实际 Agent 调用。两条 ready SDK/native preflight 先于调用；stderr、终止 Agent 事件、text2gears failed phase-return 和 invocation-finish 同时保留 `429`、`1308`、五小时用量上限及重置字面值 `2026-11-18 09:01:59`（时区未注明）。重算了失败快照；后续阶段未到达，无 accepted entry/manifest/build history 或 lifecycle 接受记录。

故三条为 provider quota 阻塞下的 **insufficient_evidence**：不是通过，也没有证据把它判为软件缺陷。48 条 retained 不补齐这三条冷生成成功，也不给原 SC2 的 48 次全新冷生成承诺盖章。无需为了本次证据复审再调用模型；后续是否等待额度或调整验收方法由需求判定处理。

## 已解释的表示差异

- macOS `/tmp` 与事件中的 `/private/tmp` 经物理路径解析为同一路径。
- manifest 的单值 `artifactSchema` 属于选定运行时的 `supportedArtifactSchemas`；其 package/runtime 内容身份相等。
- 早期 `retained12-TC-local-macos-codex-commonjs` 的 harness 为 `c9041c…`，已独立哈希完整保存的 `evidence/development/retained-v2-before-metadata-fix.mjs`；与当前 `55b7ca…` 源码差异仅 identity 内 `networkProfile` 和 `glmProxyBypassed` 描述改为 null。环境设置、复制、CLI 执行和断言未改变。其余 47 项绑定当前 harness。
- 审计初稿中对 schema、canonical 路径及 preflight 数目的过严假设已按实际 raw 值修正；没有修改原证据。

## 交付记录

- 汇总及 54 项准确 target/SHA256/status：`review-final12-execution-review.json`。
- 全部字节核对与逐项理由：`review-final12-independent-byte-audit.json`。
- 对导入原档复算的 51 项最终门禁：`review-final12-recomputed-gates.json`。
- 可登记单项意见：`review-final12-<requestId>.json`，共 54 份，沿用真实 TC 和 target，不伪造正式执行。主 Agent 负责使用本次独立会话身份登记。
