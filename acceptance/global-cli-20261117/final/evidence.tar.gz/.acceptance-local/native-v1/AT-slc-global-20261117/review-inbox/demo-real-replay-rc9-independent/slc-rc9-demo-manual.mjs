import{createRequire}from'node:module';import{writeFileSync}from'node:fs';const repo='/Users/boboyang/work/sublang.ai/slc',snap='/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-Ccu70n',require=createRequire(repo+'/package.json');const{createActor,fromPromise}=require('xstate');const out=[];const tick=()=>new Promise(r=>setTimeout(r,0));
for(const lang of['en','zh']){
 const{findMachine}=await import(snap+'/dist/verify-coverage.js');const machine=findMachine(await import(snap+'/dist/'+lang+'.fsm.js')); let pending;const results=[],transitions=[],trace=[];
 const logic=fromPromise(({input})=>new Promise(complete=>{pending={input,complete};}));const provided=machine.provide({actors:{player:logic,script:logic}});const actor=createActor(provided,{input:{},inspect:(e)=>{if(e.type==='@xstate.microstep')for(const t of e._transitions??[]) transitions.push({event:e.event?.type,source:t.source?.id,targets:t.target?.map(x=>x.id),reenter:t.reenter,root:t.source===provided.root});}});actor.subscribe(s=>trace.push({state:s.value,loops:s.context.reviewLoops??s.context.loopCount,judgments:s.context.judgmentCount,inputTask:s.context.inputTask}));actor.start();actor.send({type:lang==='en'?'START':'BOSS_TASK',inputTask:'/tmp/real-maintained-task.md'});await tick();let interrupted=false;
 for(let n=0;n<16&&actor.getSnapshot().status==='active';n++){
  if(!pending)throw Error('no pending '+actor.getSnapshot().value);let{input,complete}=pending;
  if((lang==='en'&&input.stateId==='implement'&&!interrupted)||(lang==='zh'&&input.stateId==='reviewCommit'&&actor.getSnapshot().context.loopCount===2&&!interrupted)){
   interrupted=true;pending=undefined;const event={type:'BOSS_INTERRUPT',targetId:lang==='en'?'implement':'implementChange'};actor.send(event);results.push({publicEvent:event});await tick();if(!pending)throw Error('interrupt no pending');({input,complete}=pending);
  }
  const sid=input.stateId;let result;
  if(['setup','ensureRepository'].includes(sid))result={guard:'ok',exitStatus:0};
  else if(['implement','apply','implementChange','reviseByConclusion'].includes(sid))result={guard:'done'};
  else if(sid==='review')result={guard:'findings',reviewFindings:'Observed actual review findings'};
  else if(sid==='reviewCommit')result={guard:'issues',reviewFindings:'Observed actual review findings'};
  else if(sid==='judgeFindings')result={guard:lang==='en'?'judged':'accept',coderJudgment:'Observed actual judgment'};
  else if(sid==='argue')result={guard:'agreement'};
  else throw Error('unknown '+sid);
  results.push({stateId:sid,result});pending=undefined;complete(result);await tick();
 }
 out.push({language:lang,status:actor.getSnapshot().status,final:actor.getSnapshot().value,context:actor.getSnapshot().context,results,trace,rootInterrupts:transitions.filter(x=>x.event==='BOSS_INTERRUPT')});actor.stop();
}
writeFileSync('/tmp/slc-rc9-demo-manual.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
