# Cligent recovery helper implementation review v3

Acceptance AT-slc-global-20261117. Result: NEEDS_REVISION, one P2 inherited-npm-configuration issue. All other reviewed recovery paths below passed real installed-package tests. This is an early implementation review, not formal acceptance or authorization to merge/publish.

This v3 opinion is immutable with respect to the frozen package: Cligent 0.40.0-rc.1, tarball SHA-256 33954e49b0cf17366bd497c3300cc9b7eb32493ae714815977767901a9f9ad8b; packaged helper SHA-256 5fdee2cd892b688370354c84bad9417bb8013c895fdd13c1692045663f0e4237. The initial require.resolve validator draft was corrected before this frozen package and was not used for a repair trial. Subsequent explicit legacy=false fixes belong to v4 and are not silently attributed to these bytes.

Reviewer changed no repository files, user authentication or user configuration. All package installs, damage, sentinels and fault injection were in unique scratch directories. The home-esxi-test Skill verified Ubuntu VM 75 identity; tests used exact Linux x86_64 Node22.23.4/npm10.9.9. Shared npm download cache was explicitly reused; none of this is a cold-network-download claim.

## P2: inherited legacy-peer-deps prevents the promised normal-peer recovery

Frozen helper install argv (around lines 90–108) and npm ls argv (around 124–138) explicitly include optional/peer dependencies but do not reset legacy-peer-deps. A global/user environment setting can therefore disable peer resolution during this supposedly normal-peer install.

Actual test: remove Codex native plus Claude's required Anthropic/MCP SDK peers from the installed scratch tree, then run the packaged helper with npm_config_legacy_peer_deps=true. npm install completes, but npm ls detects the incomplete graph and helper exits 1 in 15.893s before package replacement. Both required peers remain missing. The original manifest is unchanged. Thus this is safe refusal rather than false success or data corruption, but the reported command cannot fulfill its recovery contract in that environment.

The same original tree with that inherited setting removed is repaired successfully in 20.926s, with both required peers and native/adapter availability restored. Add --legacy-peer-deps=false explicitly to both npm invocations, retaining --include=peer/optional and normal resolution. The next revision must rerun this affected real environment test. Raw evidence: extra-summary.json, legacy-config-repair.log, legacy-before/after.json, legacy-availability-after.json and normal-restore-after-legacy.log/probes.

## Real normal-package and four-fault results

Installed only the frozen tarball globally into a new prefix containing spaces and Chinese text. Initial SDK/native availability passed. The installed manifest SHA-256 was 509794c1ef66dd674c1ee0278b5bcf0f1e5f4fc578cc86eeea12b02adb6362d2 and remained identical after all recovery/failure trials.

For each of Codex native missing, Codex SDK missing, Claude native missing and Claude SDK missing, moved the ACTUAL selected physical component outside the dependency paths. The installed readiness gate refused the configured adapter, and its actual printed node/helper command was extracted and executed unchanged through /bin/sh. This tests quoting and the new packaged command rather than reconstructing an npm repair.

All four repairs exited 0 in 28.252 / 37.118 / 20.339 / 24.014 seconds. Each restored the same selected path, BOTH public adapter availability results, both native locators and every declared required Claude peer. The active SDKs were the descriptor-tested Claude 0.3.325 and Codex 0.159.1, resolving from the selected installed Cligent tree.

The test installed a synthetic optional OpenCode SDK sentinel, an unrelated host package and a custom .bin symlink before faulting. All bytes/modes/links remained unchanged after every success. No repair-stage directories remained. These sentinels test preservation; they are not claims that a fake OpenCode SDK implements its provider API.

Independent native execution after successful recovery returned status 0: Claude Code 2.1.325 and codex-cli 0.159.1, without credentials or model calls. Required peer lookup was anchored to the physical Claude SDK, not checkout/global fallbacks.

Raw evidence: summary.json, the four component fault/after/peer JSON sets, four actual shell repair command receipts/logs, and native-version-execution.json.

## Meaningful rollback: two distinct late failures passed

1. Force only the helper's FRESH post-merge readiness child to fail, after real npm installation and package replacement. The helper exits 1 and restores the exact previously damaged tree: 9437 entries of file contents, directory/file modes and symlink targets hash identically before/after, digest b5c51ba43fd0a60243dfae1c45b4ee09ff920b6840c6ad4f836fcbd8a788ba12. The original manifest remains unchanged and no staging directory survives. The failure log also reaches the helper's specific restoring-prior-tree branch; this is not an install failure before mutation.
2. Inject EACCES into zod's staged package placement late in sorted replacement order, after the old zod package was backed up and earlier packages were already replaced. The helper exits 1; before/after full-tree records compare exactly, including the original missing-native state, sentinels, modes and links. Original manifest unchanged; no staging directory remains.

Fault injection preloaded Node builtins only in disposable test processes; helper source and SDK/native files were not replaced with fake implementations. Real npm install, actual package moves, backup restoration and public adapter checks ran. Raw evidence: rollback-tree-before/after.json, rollback-repair.log and rename-rollback-before/after.json, rename-rollback-repair.log, extra-summary.json. Two harness setup errors (Python3.10 hashing API and restart directory idempotence) happened BEFORE any helper call and are retained separately as fixture failures, not product results.

## Source and evidence review

- SDK exact recovery requests derive from the installed runtime descriptor; no independent floor mapping was introduced. The temporary manifest clones runtime dependencies/overrides and omits the owner's development graph. The original runtime ranges and exact development pins are not rewritten.
- SDK identity/version validation reads staged manifests rather than require.resolve, correctly admitting ESM-only SDK export maps. npm ls validates the staging graph, and a fresh actual adapter/native child validates the merged tree before commit.
- Package-granularity replacement preserves unstaged optional/host packages. Scoped packages are treated as @scope/name; stage .bin and hidden locks are not transplanted.
- No hidden lock existed at this ordinary global owner's node_modules before or after the tests. An independent npm Arborist loadActual reads the actual new 0.3.325/0.159.1 versions correctly. This does not claim coverage of a pre-existing ancestor hidden lock in every nested/hoisted consumer; runtime resolution here reads physical manifests, and future install/cache behavior in other layouts remains a separate check.
- npm/tool discovery used the portable Node22/npm10 installation. This review did not execute native Windows discovery/rename semantics. A forcibly killed process or independent concurrent repair is not covered by the two exception-driven rollback trials.
- The manifest files list includes the helper; the archive actually contains it. The verifier executes the quoted printed shell command unchanged and retains failed command/debug receipts. CI uploads evidence on always(); the official upload-artifact v7.0.1 tag exists. No stable publication boundary was changed in this helper revision.

The external picomatch full-development-audit finding is not a helper recovery result and is NOT called passed or ignored here. Production audit, candidate publication and eventual merge remain independently gated. No npmjs/OIDC publication, SLC compilation matrix or paid Agent call was performed by this reviewer.

## Evidence identity

Local raw archive: /tmp/sdk-helper-v3-review-gVbag8/v3-review-evidence.tar.gz
Archive SHA-256: 6c553b4fb2fdc49a99ec01a286db704ad04c80f500fb99ed82e19f375e5a58d7
Extracted evidence: /tmp/sdk-helper-v3-review-gVbag8/v3-extracted/v3-evidence
Remote isolated source state: /home/bobo/sdk-linux-repair-review-YLeQlD/v3-evidence/
The archive contains the frozen tarball/helper, command receipts, programs, full tree comparisons and owned npm logs, with per-file SHA-256 identities. Large installed trees and Node tool archives are excluded.
