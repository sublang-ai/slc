# Final rc.7 help delta — independent review

- Acceptance ID `AT-slc-global-20261117`。Reviewer `/root/slc_impl_review`。
- **限定范围 passed，无遗留 P1/P2。** 仅判断 cli-52/-53 对帮助文案的修正、当前实际子进程帮助输出、提前退出与负向声明，以及包内 delta。
- 未运行构建，未修改产品源码/测试，未调用付费 Agent。本意见不授予 rc.7 acquisition、依赖自动安装、冷生成桥接、完整矩阵、全量回归、公共发布、CI 或 merge 通过。

## 原问题与修复

已读 cli-52、cli-53 原文：帮助应说明单一自动 workflow-owned internal environment 与新 `.mjs` entry，不提供 independent/project environment-mode 选择。

原 `src/app.ts` 仍声称 runnable `<basename>.ts`，新增 smoke 断言后，`slc-help-final-red` 记录为 1 failed/5 passed，exit1；这证明旧 Usage/环境变量断言确实没有覆盖新增契约。

当前 source 和实际 help 均为：

```text
when --link is omitted, also emitting the runnable <basename>.mjs entry.
Each playbook uses one automatic workflow-owned environment inside its
artifact directory; no project-root Node setup is required.
```

表述与已定义的 canonical Playbook 编译/内部环境行为一致；没有新增用户环境模式，没有承诺无 Node/npm/授权前提，也没有宣称任意自然语言或业务结果必然成功。

## 独立实际子进程输出与负向检查

使用 `/tmp/slc-help-rc7-review.mjs` 分别测试：

1. 当前 `slc/dist/cli.js`；
2. 从不可变 rc.7 tgz 提取的真实 package/dist/cli.js，使用当前既有 node_modules 解析依赖。

后者只是验证打包代码已经包含修正，**不是新 prefix 的 production dependency acquisition**，更不是公共 registry 安装证据。

每个对象各运行两条真实进程命令，共 **4/4 通过**：

```text
node <actual-cli> --help
node <actual-cli> --config <nonexistent-file> -h
```

两者均在新的空 cwd、隔离 HOME/XDG 下执行；只提供无效 SLC_AGENT 与不存在的 SLC_PIPELINE_PATH，没有提供 provider credentials。独立检查实际结果为：

- exitCode 0，stdout 以 Usage 开头，stderr 为空；
- 出现 runnable `<basename>.mjs`、one automatic workflow-owned environment、artifact directory、no project-root Node setup；
- 不出现旧 runnable `<basename>.ts entry`；不出现 `--independent`、`--project` 或 SLC_ENVIRONMENT_MODE；源文案也没有提供环境模式选择；
- invalid Agent/pipeline/config 未阻断 help；当前 `run()` 源码在 config/Agent/pipeline 处理前处理帮助，符合提前退出约定；
- 两次执行后 cwd 文件列表和隔离 HOME 文件列表均为 `[]`，没有生成项目根 package/tsconfig/dependency tree/Git 或首次 config。

原始 stdout 和 result.json 位于：

- `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-help-rc7-Ll1TjX/`（当前 dist）。
- `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-help-rc7-kzOUUG/`（tgz 提取代码）。

没有用 `not contains .ts` 这种过宽断言禁止合法 FSM/历史 TypeScript 引用；负向判断只针对旧 runnable entry 声明和环境模式选择。

## 测试记录与包身份

已核对主 Agent 的 `slc-final-rc7-help-green` 原始记录：smoke **6 passed**、exit0。其输入清单 SHA 与收据一致，727 个输入文件与终稿读取内容逐项一致。smoke 用例本身调用应用 run()；本轮另外提供了上面的真实 bin 子进程/打包代码检查，没有把应用函数测试冒称为安装后 CLI 运行。

实际 rc.6→rc.7 tarball 成员差异仅为：

```text
dist/app.js
dist/app.js.map
dist/app.d.ts.map
package.json
```

唯一可执行 delta 是 app.js 的帮助字符串；不是 generation/checker/lifecycle 行为变化。实际 rc.7 包里的 app.js 与当前 dist 同字节。

- SLC `0.23.0-rc.7` tarball SHA：`32d279344b698bc112fb9f191f3e18734470b60b3c4d663d970b2a61510767ca`。
- cohort08 SHA：`ecd18fd3460b96b0be979a4a90393ac89bd9fe7336750c62cac4da4e1550237b`。

## 版本与后续边界

rc.6 已发生的真实 bridge 观察仍属于其原始不可变版本，不能由本帮助修正改标 rc.7。package/compiler identity 已变，rc.7 的额外安装、current checks/reuse 与真实桥接仍需独立记录。尚在运行的 rc.7 full suite 不在本意见中判绿；本次仅关闭 help 文案/包内输出缺口。

cli-53 还涉及从不同父目录编译 fixtures；本轮没有重新执行那些编译，也没有从 help 通过推导那些组合已通过。现有对应证据应按原版本和此前影响分析分别判断。

终稿 UTC：2026-11-17T21:31:43.933957+00:00。

- `slc/src/app.ts`: `6d1d5dc7cc6139e169361ef2fa4ccf1174f05fc3c5a4c518910b36c6c3a7f6cb`
- `slc/dist/app.js`: `e3fcc2983ea3fbfe6a04cccfbd0318806bdf07bfcf32ebf13371720ca67c64f4`
- `slc/test/smoke.test.ts`: `880f718fc2f81d004511567fea0fa166c98a088f59d936e6a22320ab5b68274f`
- `slc/package.json`: `360a43316ef52eee07fc745510baa5acc951147e35a9332512459edd46cbf05a`
- `slc/specs/packages/cli.md`: `76cc3ca23d4051d82f8730f0173d30904ffdcae2d87c56e355d8d06d779a6ab4`
- `slc-global-delivery-20261117/evidence/candidate-cohort-08/frozen-cohort.json`: `ecd18fd3460b96b0be979a4a90393ac89bd9fe7336750c62cac4da4e1550237b`
- `slc-global-delivery-20261117/evidence/alternative-branch-registry/sublang-slc-0.23.0-rc.7.tgz`: `32d279344b698bc112fb9f191f3e18734470b60b3c4d663d970b2a61510767ca`
- `slc-global-delivery-20261117/evidence/commands/slc-help-final-red.json`: `3e891a3a985d04baad23684901769a1946314a8dcaab776012a391f9653bb03f`
- `slc-global-delivery-20261117/evidence/commands/slc-help-final-red.stdout`: `0ed728cb4ed5b3c1ff8d96bafe597a9e55f2e29b07e77a70665205a8c4973fb7`
- `slc-global-delivery-20261117/evidence/commands/slc-final-rc7-help-green.json`: `d83e44d5df9f9649845f8ed5565cdc45b7275a31864949434f51388ab8b49b4c`
- `slc-global-delivery-20261117/evidence/commands/slc-final-rc7-help-green-inputs.json`: `6e6f8e1a54dd0f67f10d1068af1466350aa53c6d0d90d0f4169c587f72c6a9c5`
- `slc-global-delivery-20261117/evidence/commands/slc-final-rc7-help-green.stdout`: `09828e959b3c11672432069118481b8ef49b723de938a3bc0c59c01eb472edfe`

独立 helper/实际结果：
- `/tmp/slc-help-rc7-review.mjs`: `7efb776d30cd3444bf11a010cf14a14f9952cd4b13cdf77712874256d3f06a34`
- `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-help-rc7-Ll1TjX/result.json`: `55744d27fdea4314898c01cc652d46c79fb49deaa430e60a0363b5ec70f00304`
- `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-help-rc7-kzOUUG/result.json`: `c3790df4b7b01682e6fe8a98cf5e1dac323aeb3b16c9592918bebe0fee336285`
