# RC9 maintained demo real-replay investigation

**结论：不是FSM真不可达，也不是缺少正常业务actor结果候选。已独立观察三处搜索能力/调度问题：EN无guard START缺少inputTask事件候选；EN apply被重复无进展Q回访优先级拖住；ZH implementChange终止arm需要真实到达中途后再发root interrupt，普通onDone/onError反向剪枝与prefix只含结果/Q的模型表达不了。**

只读产品和原FSM；所有修改均在独立/tmp source快照的转译副本中，属于诊断实验，不是产品实现或新候选验收。没有付费Agent、业务脚本/Git执行或修改生成产物。真实XState手工控制仅provide与checker相同的script/player结果。

## 输入与重现

baseline source快照Ccu70n，51模块identity保存；该时刻是去掉循环硬ban、尚未加入本轮reached-interrupt与后续payload/progress修正的源码。当前live源码已被主Agent继续修改，不能把prototype输出称为当前产品通过。原rc9 CLI失败读自evidence/development/demo-real-replay-rc9/en与zh；64/1024仍失败的原记录保留。

我的临时kernel checkFsmCoverage使用原FSM文本作为sourceText，预算64invocations/1024attempts/900000ms；基线独立重现EN两项、ZH一项相同finding。给每个search记录真实pending节点、原样actor context、prefix步骤、Q数量及预算尝试序号，未改变guard、context或actor结果。完整JSON与脚本在同名证据目录。

## 可达性实际证明

`slc-rc9-demo-manual.json`是原FSM的普通XState actor（没有coverage solver）：只给script提供ok/exitStatus0，按每个公开invoke.input.result提供合法player结果，所有counter和payload均由原assign动作产生。

EN：START(inputTask='/tmp/real-maintained-task.md')→setup(ok)→implement；在实际context中发送BOSS_INTERRUPT implement并观测root=true/reenter=true到implement；done→review1→findings→judgeFindings→judged→argue→agreement→apply1→done→review2→findings→judgeFindings→judged→argue→agreement→apply2→done→loopLimitReached。共10次脚本/角色结果，最后apply的原onDone arm2实际选中。结果是正常done，不是solver把counter设2。

ZH：BOSS_TASK(inputTask)→ensureRepository(ok)→implementChange0(done)→reviewCommit1(issues)→judgeFindings(accept)→reviseByConclusion1(done)→reviewCommit2；此时发送BOSS_INTERRUPT implementChange（真实root微步，原guard检查inputTask、当前loopCount2保留）→implementChange2(done)→cycleLimitReached。共6次结果调用；最后原implementChange onDone arm1实际选择。没有普通结果回边到implementChange，故需中途公开interrupt，不能以普通reverse graph不含回边判不可达。

这些是实际FSM kernel可达证明，不等同CLI全量completion已通过。

## 三种具体问题

### EN START payload

ready.START是无guard的START→setup，startRun从event.inputTask赋值。当前entryDrive仅解guard，生成{type:'START'}，不含inputTask。trace里inputTask一直undefined，即使setup完成、implement pending，根interrupt的hasText(inputTask)必拒绝；重复Q也不会补该字段。因此原EN implement root证明耗深度是缺合法公开事件候选，不是循环计数问题。

最小通用方向：在真实initial actor发送公开entry event时记录实际guard/action对event自有数据字段的读取，预算内为这些实际读取字段生成候选，**每个候选重新从真实initial actor完整发送**。不能从function source猜context字段、不能事后patch context，也不能填host catalog/private snapshot。只读取字符串字段并给有限generic/native absolute path候选是可审的初始范围；getters/proxies/动态不支持数据应保持unverified，guard仍须实际接受。显式Source许可的events-only witness也可作正控；本轮没有把手改原产物添加witness当修复。

### EN apply priority starvation

apply arm2需要reviewLoops>=2。baseline该搜索588个实际prefix rows：apply0有222、apply1有215；review2已58次，但从未到apply2；461rows有>=10个Q步骤，最大depth63。说明结果候选与counter实际增长存在，优先Q回访把后续正常prefix拖在后面。

三个临时对照：

| 只改变临时调度 | EN apply arm2 | 既有target-local两次Q优先测试 |
|---|---|---|
| 全部target continuations由unshift改push | 仍1024耗尽；最大depth9，到argue2但尚未apply2 | 本实验未据此授予回归通过 |
| 已有同target Q后所有后续Q移FIFO | 已证明（EN只剩START/inputTask问题） | 真实失败，11pass/1fail |
| 当前真实context与上次该target Q之前的context相同才将此次Q移FIFO；其他保持优先 | 已证明（EN仍只剩START问题） | 12pass/0fail，含branchingPrefix+两次Q及successive正负控 |

最后一种仅调整优先级，所有path仍保留、原预算不变；没有把context相等当“以后不可能到达”的去重结论。其临时实现对这些良性普通data fixtures使用structuredClone+isDeepStrictEqual，只是因果验证，**不建议原样ship**：structuredClone可能读getters/不支持函数等。生产可用有界own-data descriptor快照，跳过proxy/getter/function及不支持对象，unknown保守当有变化；不得调用用户getter/toJSON，不用该比较删除路径。仍需全kernel/预算与dead-context回归验证。

### ZH 中途interrupt边与剪枝

原target=implementChange反向reachable只看onDone/onError；普通图没有从后续review/revise回到该初始实现叶的边。baseline/fair/progress调度的该target搜索pending只见implementChange0与ensureRepository0，从未进入reviewCommit。因此只调队列无法证明其loopCount2 arm，也不是循环输出字段缺失。

最小表达扩展为预算内的实际reached-prefix public interrupt step：从已重放到的pending节点/真实context，固定context解root ordered event payload；记录event、armIndex及真实declared target；重放时不伪造当前actor输出，先改变expected，再send该真实公开事件，要求新增root/source-arm/event/target微步以及新的正确pending invocation。新step照旧计入path length/attempt/duration，所有actor清理保留。反向剪枝必须保守考虑这些真实root interrupt可能连接到的节点，否则不会生成合法review前缀。

## 对主Agent新增reached-interrupt源码的静态复核

本轮中途已读取其新增CoveragePathStep.interrupt：

- optional reachedContext只作为固定guard seed；assignContext:false，不恢复到actor。
- orderedArmPredicate仍检查既有顺序；重放匹配transition.root、确切armIndex、同event对象和声明targetId；leaf shadow不应凭atState通过。
- expected先改为next，interrupt后仍需新的pending/真实atState；当前被preempt的script promise不被complete造结果，XState真实取消旧invoke。
- 每个interrupt successor走相同depth门、attempt replay收费及finally stop。interrupt候选FIFO，不拿其无界抢占target priority。
- root-arm参与reachable会扩大候选集合；每个prefix枚举全部可能interrupt有性能/公平性风险，应结合实际demo和完整kernel检查，不把本次静态审核升级为最终实现passed。

未发现新增context恢复或绕过ordered/实际微步的捷径。该实现是在冻结baseline后修改的live源码，尚未由本报告的prototype结果证明；主Agent新fixture红→绿收据也不能代替维护demo当前CLI实测。

## 最小验证与证据诚实

保留原64/1024红灯；按三个机制分别补精确小型TDD（无guard action读取字段、停滞Q对真实累积Q、必须中途interrupt且带dead/ordered-shadow负控），再对新dist执行原EN/ZH actual CLI completion和emitted/independent checks。既有priority断言不得删改成耗尽；旧child repeatBranch []仅是允许真实循环后的正确期望，不算产品bug。

真实full suite源测若调用旧dist仍不能证明新CLI；当前源码/原包/临时prototype/实际CLI四种证据应分别记录。新增产品修复必须新候选与受影响验证，不授予公共发布/CI/merge或整个SC3通过。

记录UTC：2026-11-17T23:03:12.187141+00:00。

本轮结束时live摘要（与baseline identity分列）：

- `slc/src/verify-coverage.ts`: `7010733bb6d3a37868b493307535a9c67a957dc5f408f5447bbeedfcaee88180`
- `slc/demo/reference/workflow.playbook/workflow.fsm.ts`: `9a85555fa8ff56c04b69c0937dfca7a738dc7ff3cf4ef9cd5fb7467ab77accf0`
- `slc/demo/reference/workflow.zh.playbook/workflow.zh.fsm.ts`: `5670cac974fae8d9936cd1cb1d9301665f60e310df0b4b9d7c3ff19693fd6787`
