# Playbook SC3 host-marker / two-hop CJS 独立细节复核

结论：**TC-markers的新public-host证据可关闭原具体缺口；TC-gates-cjs仍needs_revision，真实native module.require存在P1 freshness缺陷。**新增测试的断言方向正确，不能为了让套件变绿而削弱999断言、删module.require分支或把这次失败归结为Vitest缓存。

本次只读产品和原始记录；仅在/tmp创建instrumented loader副本及probe fixture，写自己的评审记录，没有编辑产品、测试或原始receipt。只评这两项精确事实，不授予SC3全部15项、48原生矩阵、发布/CI/合并通过。

## 实际receipt与源码绑定

`evidence/commands/playbook-final-sc3-host-cjs-native-v2.json`已结束：exitCode **1**，开始2026-11-17T21:45:31.767650Z、结束21:45:36.478842Z、elapsed4711ms；inputsUnchanged=true，sourceHead3431690d9b0c857b5b8ce0eb9139f6d53a96826e。JSON报告为16 tests：15 passed、1 failed。两项marker参数测试均passed；两跳require passed；两跳module.require failed。

我核对stdout/stderr摘要与receipt一致，当前test/fresh-artifact.ts/.js/artifact-environment.ts/.js及实际host launch-config.js/provision.js摘要均匹配该receipt的inputs清单。测试文件SHA为`797c51a768083fe519d3f13ba7a2ef474c0bd700c7bfbcb4544ca213a54a59e7`；native child实际执行emitted `src/fresh-artifact.js`（SHA`6239bca064c72cba9dd8609712617474cdfe37bfb04f0941262264f71b9f83e8`），不是Vitest改写过的TS模块。

早期两份红灯receipt仍有诊断价值：最初Vitest直接import的module.require不可用是测试执行环境问题；native-v1还有runtime conditional exports身份基线不匹配。native-v2已经在子进程内重建其真实runtime identity、assert同一XState物理root，随后真实两跳module.require仍返回旧值。因此本轮红灯不能继续当这两个已修正的测试准备问题。

## TC-markers：7种×2provision选择的actual-host边界成立

测试 `artifact-environment.test.ts:238–273` 每次用新fixture，7种变体为valid、missing-header、malformed-header、duplicate-header、missing-manifest、malformed-manifest、genuine legacy-ts；分别通过enabled=true/false执行。

实际路径是 `loadLaunchPlan` + 公开`prepareConfiguredRegistries`，不是只调内部marker解析器。`launch-config.js`会先完成整个configured catalog的prepare transaction，再进入import循环；prep异常包装为failed to prepare。publicprepare调用locateBuildManifest，managed路径继续inspect/prepare/validateArtifactManifest，真正无footprint的legacy走历史provisionEngine。

- valid .mjs和genuine legacy .ts分支真的执行`import(specifier)`并等待loadLaunchPlan完成，且catalog包含workflow，超出“只看生成文件/只置布尔标记”的弱证明。
- legacy-ts放在另一个新目录中，没有managed marker/footprint，未把损坏managed文件重命名成legacy掩盖。
- 五种managed负控要求prepare抛错、import seam从未被调用、入口内容保持原样。它们证明拒绝发生在host模块导入之前；no-provision也没有降级绕过managed验证。
- valid正控与负控共享相同synthetic注册表契约，避免“全部fixture都因另一个通用错误拒绝”的假阳性。

这关闭SC3 TC-markers原具体承诺：有效managed/真实legacy能通过actual public-host入口，managed marker/manifest坏掉不能降级导入。边界仍是公开host加载/准备seam的集成测试，import回调由测试注入且内部用真实dynamicimport；没有启动tmux/CLI、不调用runtime.initialize、不评价业务。默认链接已经存在，所以它不另行证明损坏链接修复或Windowsjunction，亦不替代packed安装或三平台执行证据。错误文本只断言failed-to-prepare大类，不声称逐个诊断措辞本身已精确验收。

## TC-gates-cjs：新测试正确暴露实际缺陷

`artifact-environment.test.ts:129–172`形成entry.mjs → linked.mjs → value.cjs → helper.cjs的真实链；value.cjs独立参数化literal require与module.require。核心顺序是在**同一个native子进程**内：

1. synthetic manifest先绑定该native进程的conditional-export runtime身份；不同于对已接受产物偷偷改运行库，这里只是建立测试初始fixture。
2. validate初始manifest、真实fresh-import读到1。
3. helper改999，旧manifest因runtime file changed拒绝。
4. 通过实际inspectArtifactFiles更新closure并写新manifest，validate通过。
5. 再次真实fresh-import必须读到999。

native-v2 require分支按此通过；module.require在最后一步明确`1 !== 999`。由于此前旧manifest拒绝、新manifest通过，缺陷是**accepted updated closure没有按新revision真实读取**，不是没有记录helper或hash gate没做。原有closure omission/change及createRequire alias refusal测试仍通过；它们不足以替代新两跳fresh-read成功判据。TC-gates-cjs整体不能关闭。

测试保留了unsupported-registerHooks的明确拒绝分支，外层成功文字前缀也允许这种分支。因此在未来不支持hook的Node运行时，必须将那次结果记为unsupported-host refusal而非freshness正证；当前实际Node v25.5.0有hook且进入了1/999分支，此 caveat不解释当前红灯。

## 独立native instrumentation：token没有丢，hooks被缓存提前绕过

原始临时副本probe在`playbook-sc3-cjs-native-trace.json`，目录`/private/tmp/playbook-cjs-review-PukclL`。我复制当前emitted fresh-artifact.js到/tmp，仅把error-class import指回原模块，并在resolve前/提取token后/load处添加stderr日志；每种loader用独立native子进程，在同一进程import→改helper→import。

| 路径 | 第一次 | 第二次 |
| --- | --- | --- |
| literal require | 1 | 999 |
| literal module.require | 1 | **1** |

module.require第一轮helper resolve的parentURL是正确的`.sublang-<token>-value.cjs`，token/scope存在，helper使用alias加载。第二轮value.cjs已经用了新token，但**helper的resolve与load hook一次也没进入**。因此继续修改resolve-hook内token提取顺序不能修这个缓存短路。

本机Node25.5内置源码可直接读取（不需猜测外部版本）：

- `internal/modules/cjs/loader`的`Module.prototype.require`调用Module._load；_load先构造`relativeResolveCache` key `${parent.path}\0${request}`，如果旧filename对应Module._cache还在，直接return cachedModule.exports；`resolveForCJSWithHooks`在这个分支之后。
- 当前fresh-artifact.ts:34把每个token只编码进**同目录的basename**，各revision父模块的parent.path仍相同。首次`module.require('./helper.cjs')`缓存了旧helper alias；新revision同目录/同request命中旧alias，在hook有机会删除/重写缓存前就返回。
- ESM translator给imported CJS的lexical require提供单独requireFn，走cascadedLoader/getOrCreateModuleJob；与module.require→Module._load不是同一dispatch，所以literal require能带新token成功。
- 当前`:32`删除的是original file缓存，不是旧alias缓存；而此次module.require早期命中时根本没有进入该行。`.mjs` query或新的CJSbasename不能独自解决Node目录级相对解析快缓存。

这就是artifact-environment-7/verification-72要求fresh transitive module state的实际产品缺口，优先级P1。产品修复、emitted JS同步与新receipt由root处理；本Reviewer不编辑产品。

## 最小修复边界与已试错方案

修复必须让module.require在Node早期cache lookup之前就处于正确revision身份/dispatch，且保留实际相对路径解析和原始lexical __filename/__dirname，不得全局patch Module.prototype.require或清空无关包缓存。

root提出的“每token一个virtual alias子目录，并在resolve hook把parentURL改回原址”已在/tmp独立尝试，结果记录`playbook-sc3-cjs-virtual-directory-probe.json`、临时loader`/private/tmp/playbook-cjs-dir-review-uPydsL/fresh-dir.mjs`。**这个简单版本两种loader都先报MODULE_NOT_FOUND ./helper.cjs，不可直接采用**：lexical require会在hook前用native Module._resolveFilename与真实module对象解析；module.require的defaultResolve闭包也仍持有真实alias parent，单改hook context.parentURL不足。

建议保留同目录alias及现有native回归，优先设计局部revision-aware的module.require适配或明确隔离加载上下文，而不是继续补query。若采用局部module facade，不能直接重赋原native module.require=lexical require：原生CJS makeRequireFunction可再次调用mod.require造成递归；应保持原module对象未被全局改写，并验证exports转发及普通require/resolve语义。另一种只改module.path的目录级key隔离虽能避开已知Node快缓存，但改变公开元数据语义并依赖私有实现，不应当无声明“安全修复”。清旧alias require.cache只能证明简单顺序场景；旧/新revision延迟module.require交替可能再命中目录级快缓存，不能只跑现有eager探针就声称完整修好。

产品修复后至少保留当前强999断言，并在真实native进程验证延迟/重复old/new调用与两个workflow scope不会串缓存、__filename/__dirname和相对依赖仍正确；这些是避免此次修复回退原行为的必要边界，不新增业务场景。本报告没有把未经验证的shim候选当作已经完成修复。

## 最终范围

本轮新增host-marker测试通过并关闭对应具体缺口；新增两跳CJS测试本身有力，且发现仍未修复的native module.require陈旧值。当前真实receipt整体15/16，故TC-gates-cjs及整个相关套件不能标pass，也不能拿TC-markers通过外推SC3全部15项。原红灯保留，不修改断言或原始结果；新修复必须有新输入绑定及新执行证据。

## 补充：已验证的局部module facade候选（仍非产品修复通过）

按root要求，另做了临时emitted-loader副本probe，只替换inner wrapper的module实参为局部Proxy：

```js
new Proxy(module, {
  get(target, key, receiver) {
    return key === 'require' && !Object.prototype.hasOwnProperty.call(target, key)
      ? require
      : Reflect.get(target, key, receiver);
  }
})
```

这里的require是当前wrapper收到的lexical require；真正native module.require没有被重赋，故避免makeRequireFunction反调导致递归。普通set/exports及其他成员使用Proxy默认转发；用户在该module上设置的own require属性不被覆盖。测试只在/tmp，没有编辑产品。

`playbook-sc3-cjs-local-facade-probe.json`记录真实Node25.5结果：literal require、literal module.require各自独立进程，value→middle→helper三跳；eager读1后改helper，new eager读999；交替delayed old/new是 **[1,999,1,999]**。两者的module.exports赋值、初始exports===module.exports、后续selfExports返回实际导出同一object、Object.getPrototypeOf(module)===Module.prototype、instanceof Module、原lexical __filename/__dirname均通过。own module.require自定义返回77，删除后原两revision继续分别读1/999。

因此这是比清全局cache或只改virtual directory更有针对性的**可行局部候选**，足以让root开展最小产品修复；本报告仍不声称它已进入产品或其新receipt已通过。

需要明确的兼容边界：Proxy本身与native Module对象严格身份不同；prototype/instanceof和exports身份通过并不能证明与Module._cache实体、宿主私有对象引用的===关系相同。把默认module.require重定向lexical require也会改变函数本体身份；原形方法显式.call、反射、非字面量loader及自定义loader覆写不由本次literal require/module.require合同自动证明。own override的运行时转发保留，不意味着静态closure analyzer应接受不可证明的动态loader。不能把这些未覆盖的元编程语义包装成全CommonJS兼容。

三组临时loader及stdout/stderr已另存本review-inbox下 `playbook-sc3-native-probes/{baseline-trace,virtual-directory,local-facade}`，SHA清单在其`SHA256SUMS.json`，便于fresh-context Reviewer读取，不依赖/tmp长期保留。生产新代码仍须保留当前强999回归以及root采用的eager/delayed/scope隔离验证，并出具新的源码绑定receipt。
