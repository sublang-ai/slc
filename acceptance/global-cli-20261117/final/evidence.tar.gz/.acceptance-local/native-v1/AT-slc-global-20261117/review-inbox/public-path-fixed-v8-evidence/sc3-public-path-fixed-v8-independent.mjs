import {readFileSync,writeFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {isAbsolute} from 'node:path';
const root='/Users/boboyang/work/sublang.ai/slc';
const require=createRequire(root+'/package.json');
const {setup,assign,fromPromise,createMachine,createActor}=require('xstate');
const {checkFsmCoverage}=await import('/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-OlJXN5/dist/verify-coverage.js');
const src=readFileSync(root+'/test/standalone-witness.test.ts','utf8');
const ts=require('typescript'); const fn=ts.transpileModule(src.slice(src.indexOf('function machine('),src.indexOf("describe('public coverage")),{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
function fixture(trace,dead=false){
 const orig=Function('setup','assign','fromPromise','isAbsolute',fn.replace('event.output as { guard: string }','event.output')+';return machine();')(setup,assign,fromPromise,isAbsolute);
 const conf={...orig.config,states:{...orig.config.states}};
 for(const [key,state] of Object.entries(conf.states)){
  conf.states[key]={...state,entry:[...(state.entry?(Array.isArray(state.entry)?state.entry:[state.entry]):[]),({context,event})=>trace.push({entered:key,context:{...context},event:{...event}})]};
 }
 if(dead) conf.states.ready.on={START:{...conf.states.ready.on.START,guard:()=>false}};
 return createMachine(conf,orig.implementations);
}
const out=[];
for(const variant of ['none','missing','relative','absolute','dead-initial']){
 const trace=[]; const m=fixture(trace,variant==='dead-initial'); const module={machine:m};
 if(!['none','dead-initial'].includes(variant)) { const event={type:'START'}; if(variant!=='missing') event.path=variant==='relative'?'relative/task.md':'/tmp/slc-witness/task.md'; module.coverageWitnesses={schema:'sublang.slc.coverage-witnesses.v1',entries:[{events:[event]}]}; }
 const findings=await checkFsmCoverage(module,{coverage:{maxAttempts:8,maxInvocations:4,maxDurationMs:10000}});
 out.push({variant,findings,trace});
}
// Independent ordinary actor: rejected inputs cannot leave ready; then a real valid START and interrupt.
const realTrace=[]; const m=fixture(realTrace).provide({actors:{captain:fromPromise(()=>new Promise(()=>{}))}}); const actor=createActor(m); actor.start();
const snapshots=[];for(const event of [{type:'BOSS_INTERRUPT',targetId:'work'},{type:'START'},{type:'START',path:'relative/task.md'},{type:'START',path:'/tmp/slc-witness/task.md'},{type:'BOSS_INTERRUPT',targetId:'work'}]){actor.send(event); snapshots.push({event,value:actor.getSnapshot().value,context:actor.getSnapshot().context});}actor.stop();
const raw=Function('setup','assign','fromPromise','isAbsolute',fn.replace('event.output as { guard: string }','event.output')+';return machine();')(setup,assign,fromPromise,isAbsolute);
const rawConfig={...raw.config,states:{...raw.config.states,ready:{...raw.config.states.ready,on:{START:{...raw.config.states.ready.on.START,guard:()=>false}}}}};
const rawDead=createMachine(rawConfig,raw.implementations); const rawDeadFindings=await checkFsmCoverage({machine:rawDead},{coverage:{maxAttempts:8,maxInvocations:4,maxDurationMs:10000}});
const deadActor=createActor(rawDead);deadActor.start(); const deadSnapshots=[];for(const event of [{type:'START',path:'/tmp/slc-witness/task.md'},{type:'BOSS_INTERRUPT',targetId:'work'}]){deadActor.send(event);deadSnapshots.push({event,value:deadActor.getSnapshot().value,context:deadActor.getSnapshot().context});}deadActor.stop();
const result={uninstrumentedDead:{findings:rawDeadFindings,snapshots:deadSnapshots},sourcePath:root+'/test/standalone-witness.test.ts',checker:'/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-OlJXN5/dist/verify-coverage.js',out,ordinaryActor:{snapshots,trace:realTrace}};
writeFileSync('/tmp/sc3-public-path-fixed-v8-independent.json',JSON.stringify(result,null,2));
console.log(JSON.stringify({runs:out.map(x=>({variant:x.variant,findings:x.findings,entered:x.trace.map(t=>({state:t.entered,event:t.event.type,path:t.context.path,prepared:t.context.prepared}))})),ordinaryActor:result.ordinaryActor.snapshots,uninstrumentedDead:result.uninstrumentedDead},null,2));
