// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: 2026 SubLang International <https://sublang.ai>

// Standalone review of a compiled `playbook` artifact directory: runs the four
// DR-009 compilation-correctness checks (conformance incl. Boss-reply coverage,
// introspection summary, prompt contract incl. composition when the linked
// module exposes its composer, and transition coverage) plus the DR-028
// compiled-execution fidelity check — the definition's `## Compiled execution`
// section, when it declares one, must be preserved verbatim in the bundle's
// GEARS — and the DR-029 Source-fidelity check over the Source beside the
// artifacts (`<basename>.text.md`) or the one `--source` names, and prints
// findings. The review half of the build-and-review flow (DR-005, DR-007); run
// `npm run build` first.
//
//   node scripts/verify-artifacts.mjs <artifactDir> <basename> [--source <path>]

import { existsSync, readFileSync, realpathSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

/**
 * Review one compiled artifact through the supplied verification module.
 * Keeping orchestration separate from the CLI lets the repository audit prove
 * the independent review's data flow without depending on source formatting.
 */
export const reviewArtifact = async ({
  dir,
  basename,
  /** Definition to check fidelity against; defaults to the pin's recorded definition, else `<pipelineDir>/<basename>.md`. */
  definition,
  /** Source to check the GEARS against; defaults to `<artifactDir>/<basename>.text.md` (DR-029). */
  source,
  verification,
  pinning,
  /** Reads the link target's installed engine declaration (DR-028). */
  contract,
  /** Checks compiled-execution fidelity between definition and GEARS (DR-028). */
  fidelity,
  /** Checks Source fidelity between the Source and the GEARS (DR-029). */
  sourceFidelity,
  coverage,
  log = console.log,
}) => {
  const {
    capturePromptContract,
    checkGearsFsmArtifact,
    checkPromptComposition,
    enumerateCaptainStates,
    findMachineConfig,
    loadFsmModule,
    loadLinkedModuleForVerification,
    pinIntrospection,
    resolveArtifactSchemaForVerification,
  } = verification;
  const artifactDir = resolve(dir);
  const pipelineDir = resolve(artifactDir, '..');
  const findings = [];
  const section = (title) => log(`\n== ${title}`);

  const gears = readFileSync(join(artifactDir, `${basename}.gears.md`), 'utf8');
  const fsmPath = join(artifactDir, `${basename}.fsm.ts`);
  const fsm = await loadFsmModule(fsmPath);
  const config = findMachineConfig(fsm);
  let provenance;
  let callerMachineInput;
  let runtimeDeclaration;
  let record;
  if (pinning !== undefined) {
    try {
      const loaded = await pinning.loadPinFile(pipelineDir);
      record = loaded.file?.pins?.[basename];
      if (record !== undefined) {
        const verdict = (
          await pinning.evaluatePinFile(pipelineDir, loaded.file)
        )[basename];
        if (verdict === undefined) {
          throw new Error(`pin index has no verdict for ${basename}`);
        }
        if (verdict.status === 'current') {
          provenance = record.linkTarget.provenance;
          if (contract !== undefined) {
            // The installed engine's own declaration is the schema evidence
            // for any provenance outside the exact historical map (DR-028).
            const linkTarget = resolve(pipelineDir, record.linkTarget.locator);
            try {
              runtimeDeclaration =
                await contract.readPlaybookRuntimeDeclaration(linkTarget);
            } catch (error) {
              log(
                `ignoring unreadable link-target engine declaration for ${basename}: ${
                  error instanceof Error ? error.message : String(error)
                }`,
              );
            }
          }
        } else {
          log(
            `ignoring ${verdict.status} pin provenance for ${basename}: ${verdict.reason}`,
          );
        }
      }
    } catch (error) {
      // Pin parsing/currency has its own later gate. An unreadable or stale pin
      // is not artifact-schema evidence for the just-built bundle.
      log(
        `ignoring unavailable pin provenance for ${basename}: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  }
  const linkedPath = join(artifactDir, `${basename}.playbook.ts`);
  let linked;
  let linkedLoadError;
  if (existsSync(linkedPath)) {
    try {
      linked = await loadLinkedModuleForVerification({ linkedPath, fsmPath });
    } catch (error) {
      linkedLoadError = error;
    }
  }
  const schemaResolution = resolveArtifactSchemaForVerification({
    ...(provenance === undefined ? {} : { provenance }),
    ...(runtimeDeclaration === undefined ? {} : { runtimeDeclaration }),
    config,
    ...(linked === undefined ? {} : { linked }),
  });
  const artifactSchema = schemaResolution.artifactSchema;
  findings.push(
    ...schemaResolution.findings.map((finding) => `schema: ${finding}`),
  );

  section('compiled-execution fidelity');
  if (fidelity === undefined) {
    log('not reviewed: no fidelity checker supplied');
  } else {
    const definitionPath =
      definition !== undefined
        ? resolve(definition)
        : record !== undefined
          ? resolve(pipelineDir, record.definition.path)
          : join(pipelineDir, `${basename}.md`);
    if (!existsSync(definitionPath)) {
      log(`not applicable: no definition at ${definitionPath}`);
    } else {
      const definitionText = readFileSync(definitionPath, 'utf8');
      const verdict = fidelity.checkCompiledExecutionFidelity(
        definitionText,
        gears,
      );
      // DR-028 is the independent host contract for these owned, pinned
      // compiler shells only. Ordinary artifact exports or matching basenames
      // cannot authorize startup values. Establish identity and fidelity before
      // coverage; never synthesize a context field or a definition default.
      const ownedPipelinePath = fileURLToPath(
        new URL('../pipelines/playbook/', import.meta.url),
      );
      const ownedPipeline = existsSync(ownedPipelinePath)
        ? realpathSync(ownedPipelinePath)
        : undefined;
      if (
        provenance !== undefined &&
        ownedPipeline !== undefined &&
        record !== undefined &&
        verdict.applicable &&
        verdict.findings.length === 0 &&
        ['text2gears', 'gears2fsm', 'link'].includes(basename) &&
        realpathSync(pipelineDir) === ownedPipeline &&
        realpathSync(definitionPath) ===
          realpathSync(join(ownedPipeline, basename + '.md')) &&
        record.definition.hash ===
          'sha256:' + createHash('sha256').update(definitionText).digest('hex')
      ) {
        callerMachineInput = { definition: definitionText };
        log(`host input: current pinned definition ${record.definition.hash}`);
      }
      if (!verdict.applicable) {
        log(`not applicable: ${verdict.reason}`);
      } else {
        findings.push(...verdict.findings.map((f) => `fidelity: ${f}`));
        log(
          verdict.findings.length === 0
            ? `ok: ${verdict.item} preserves the definition's compiled-execution contract`
            : verdict.findings.join('\n'),
        );
      }
    }
  }

  section('source fidelity');
  if (sourceFidelity === undefined) {
    log('not reviewed: no Source-fidelity checker supplied');
  } else {
    const sourcePath =
      source !== undefined
        ? resolve(source)
        : join(artifactDir, `${basename}.text.md`);
    if (!existsSync(sourcePath)) {
      log(`not applicable: no Source at ${sourcePath}`);
    } else {
      const conserved = sourceFidelity.checkSourceGearsContract(
        readFileSync(sourcePath, 'utf8'),
        gears,
      );
      findings.push(...conserved.map((f) => `source: ${f}`));
      log(
        conserved.length === 0
          ? `ok: the GEARS conserves every fragment ${sourcePath} authors`
          : conserved.join('\n'),
      );
    }
  }

  section('gears↔fsm conformance and transition coverage');
  const conformance = await checkGearsFsmArtifact(gears, fsm, {
    sourceText: readFileSync(fsmPath, 'utf8'),
    ...(callerMachineInput === undefined || findings.length
      ? {}
      : { machineInput: callerMachineInput }),
    ...(artifactSchema === undefined ? {} : { artifactSchema }),
    ...(coverage === undefined ? {} : { coverage }),
  });
  findings.push(...conformance.map((f) => `conformance: ${f}`));
  log(conformance.length === 0 ? 'ok' : conformance.join('\n'));

  section('introspection');
  const pins = pinIntrospection(config);
  log(
    `captain states: ${pins.captain.length}; quiescent: ${pins.quiescent
      .map((s) => s.state + (s.final ? '(final)' : ''))
      .join(', ')}; initial: ${pins.initial}`,
  );
  log(
    `root events: ${Object.keys(pins.rootOn).join(', ') || '(none)'}; interrupt targets: ${pins.interruptTargets.length}`,
  );
  for (const state of pins.captain) {
    log(
      `  ${state.state} [${state.sourceItem} -> ${state.player}] results: ${state.resultKeys.join('/')} onDone: ${state.onDone.length} onError: ${state.onError.length}`,
    );
  }

  section('prompt contract');
  const rows = capturePromptContract(config);
  const promptActors = new Set(
    enumerateCaptainStates(config)
      .map(({ actor }) => actor)
      .filter((actor) => actor === 'captain' || actor === 'player'),
  );
  for (const row of rows) {
    log(
      `  ${row.state}: reads [${row.reads.join(', ')}] placeholders [${row.placeholders.join(', ')}]`,
    );
  }
  if (existsSync(linkedPath)) {
    if (linked !== undefined) {
      for (const [actor, exportName] of [
        ['captain', 'composeCaptainPrompt'],
        ['player', 'composePlayerPrompt'],
      ]) {
        if (!promptActors.has(actor)) continue;
        const compose = linked._internal?.[exportName];
        if (typeof compose !== 'function') {
          const message = `linked module exposes no _internal.${exportName} required by ${actor} states`;
          findings.push(message);
          log(message);
          continue;
        }
        const composition = checkPromptComposition({
          config,
          compose,
          actor,
          ...(artifactSchema === undefined ? {} : { artifactSchema }),
        });
        findings.push(...composition.map((f) => `composition: ${f}`));
        log(
          composition.length === 0
            ? `${actor} composition ok`
            : composition.join('\n'),
        );
      }
    } else {
      const message =
        linkedLoadError instanceof Error
          ? linkedLoadError.message
          : String(linkedLoadError);
      findings.push(`linked module failed to import: ${message}`);
      log(`linked module failed to import: ${message}`);
    }
  } else {
    const message = 'no linked module beside the artifacts';
    findings.push(
      promptActors.size === 0
        ? message
        : `${message}; composition cannot be reviewed for ${[...promptActors].join(' and ')} states`,
    );
    log(message);
  }

  section('verdict');
  if (findings.length === 0) {
    log('PASS: no findings');
  } else {
    log(`FAIL: ${findings.length} finding(s)`);
  }
  return { findings, passed: findings.length === 0 };
};

if (
  process.argv[1] !== undefined &&
  realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url))
) {
  const argv = process.argv.slice(2);
  const positional = [];
  let source;
  for (let index = 0; index < argv.length; index++) {
    if (argv[index] === '--source') {
      source = argv[++index];
      continue;
    }
    positional.push(argv[index]);
  }
  const [dir, basename] = positional;
  if (!dir || !basename || (argv.includes('--source') && !source)) {
    console.error(
      'usage: node scripts/verify-artifacts.mjs <artifactDir> <basename> [--source <path>]',
    );
    process.exitCode = 2;
  } else {
    const [
      verification,
      pinCurrency,
      pins,
      runtimeContract,
      fidelity,
      sourceFidelity,
    ] = await Promise.all([
      import('../dist/verify.js'),
      import('../dist/pin-currency.js'),
      import('../dist/pins.js'),
      import('../dist/runtime-contract.js'),
      import('../dist/compiled-execution.js'),
      import('../dist/verify-source.js'),
    ]);
    const { resolveCoverageConfig } = await import('../dist/app.js');
    const { loadConfigFile } = await import('../dist/config-file.js');
    const file = await loadConfigFile({
      cwd: process.cwd(),
      env: process.env,
      seed: false,
    });
    const result = await reviewArtifact({
      coverage: resolveCoverageConfig(process.env, file.config),
      dir,
      basename,
      ...(source === undefined ? {} : { source }),
      verification,
      pinning: {
        evaluatePinFile: pinCurrency.evaluatePinFile,
        loadPinFile: pins.loadPinFile,
      },
      contract: {
        readPlaybookRuntimeDeclaration:
          runtimeContract.readPlaybookRuntimeDeclaration,
      },
      fidelity: {
        checkCompiledExecutionFidelity: fidelity.checkCompiledExecutionFidelity,
      },
      sourceFidelity: {
        checkSourceGearsContract: sourceFidelity.checkSourceGearsContract,
      },
    });
    if (!result.passed) {
      process.exitCode = 1;
    }
  }
}
