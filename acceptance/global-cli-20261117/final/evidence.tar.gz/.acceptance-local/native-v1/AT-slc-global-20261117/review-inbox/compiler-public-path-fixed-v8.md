# Public-path fixed v8 — independent source review

**限定修复 passed：原 context-patch P1 已独立关闭；新发现的 terminal-target 观察边界也已修复并独立复测。当前审阅范围未保留 P1/P2。**

这不是正式 SC3 15 项、发布或最终候选通过。产品 package 尚未为这些修改构建/冻结：package.json 当时仍为0.23.0-rc.7，但被审对象是后续未提交源码，不能把新结果改记到不可变 rc7 安装包。没有产品编辑、产品构建或付费 Agent 调用；临时转译及测试副本只写在 /tmp。

## 方法与实际输入

为避开旧dist，用既有独立freeze脚本从live src转译全部51个TypeScript模块到临时目录。第一版快照74Rzz6用于初始修复；根interrupt terminal-target补强后重新冻结最终快照OlJXN5，并在该最终快照重跑本轮全部主要反例及正负控。测试副本只把../src/导入改向临时../dist/，配置的self-reference也改向临时dist；依赖使用实际仓库node_modules，不把该方法称为新包安装。

最终快照：`/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-OlJXN5`。
51个源模块逐一与live源复算，差异为[]。本目录`public-path-fixed-v8-evidence/review-identity.json`包含精确摘要及原始证据摘要；源码身份与原始输出已一并归档。

## 核心修正与独立实际反例

- `interruptDriveForRef`和`entryDrivesForRef`以initializedMachineContext作固定初始上下文，assignContext:false；只求真实public event payload，不再修改缺失/已有context字段。
- AST遍历核对8个makeActor调用：第四参数全部undefined或省略。controller、普通Captain、predecessor、queued replay、parallel及root direct入口均不再传入solver context。persistedSnapshotWithContext/restoredContext参数虽然保留为当前无调用分支，不能据其存在声称仍有本绕过；本轮未发现其他snapshot写入入口。
- 强反例原样重跑：none、missing path、relative path及dead-START均返回具体unverified/unproved；没有伪造work entry。合法absolute witness返回[]，实际trace依次ready→prepare→work:START:true，再观察work:BOSS_INTERRUPT:true；不再出现prepared='work'或跳过前驱。
- 同一dead-START反例不加entry instrumentation直接重建也拒绝；普通XState对照仍在ready。证明修复并非仅针对trace函数/测试形状。
- witness是additive的测试语义已修正：缺/相对路径本身不能贡献证明；若普通搜索真的找到其他合法路径，必须有真实START/predecessor轨迹后才允许整体成功。本次实际none/missing/relative仍为unverified；保留寻找其他真实路线的合法空间，没有把坏witness当全局否决开关。

原P1的两条根因（合成context和恢复初始snapshot）均在实际可达性驱动边界关闭。纯guardSatisfiable局部求解仍可枚举context，不能把它们的局部可满足性结果提升为reachable证明。

## Self-reentry 与 child predecessor

`probeNonPreemptiveActor`对同叶目标现在同时要求authored reenter:true，以及本次pending完成之后记录到匹配sourceId、armIndex、done/error事件和reenter的真实微步。没有把“仍在同一状态”当成完成证明。

我额外构造了真正强制走nonpreemptive fallback的同一absolute-path/prepared fixture：根interrupt在初始context不满足，必须先真实START。其ok结果指向自身：

- reenter:true：findings=[]，trace包含work:xstate.done.actor.0.work:true，是真实调用完成后重入。
- reenter:false：返回result ok remains unproved和onDone arm0 has no distinct observable target，无done-event重入entry。

这补充了当前permanent reentry测试（普通goodMachine可能走direct驱动），避免只用测试名字认定新fallback分支已验证。

另写独立root-child fixture：初始Captain plan必须完成并assign prepared=true，才能进入child并满足其根interrupt。正控findings=[]，trace先CHILD:xstate.done.actor.0.plan:true，再REAL_INTERRUPT和CHILD:BOSS_INTERRUPT:true；将producer guard置假后，没有任何child entry，child/root interrupt保持unverified。验证了新增targetPlaybook predecessor replay不是context补值。

## Terminal target 的追加修正

早期本轮额外观察：initial done已final时，直接根interrupt只检查atState(done)，可返回[]但根action从未运行。主Agent随后补了direct-root实际微步判据；我在最终快照复测完全相同脚本：

`findings = ['BOSS_INTERRUPT target done remains unverified after actual public interrupt replay']`

trace仅DONE_INIT，未伪造ROOT_SELECTED。新代码在发送事件前记录transition计数，成功须有新增root=true、精确armIndex、同一event对象、声明target微步并实际atState。这个窄观察边界在终稿中关闭，不计遗留问题。

## Specs 与测试期望

verification-6固定初始context并要求真实predecessor/public replay的修订，与verification-74和原本的实际可达性限制一致。verification-11旧“restore satisfying context through persisted snapshot”与这些要求冲突，本次改为真实前驱建立context、无路线则unverified，解决冲突。

旧无前驱guarded-parallel []正控改为明确unverified有实际依据；没有给任意solver context默许。dynamic Captain默认夹具去掉无赋值路线的final Boss jump，另保留helper(true)独立负控断言done remains unverified，正向exact-catalog child仍真实通过；这避免删掉反例后只保留绿灯。

Reference自身覆盖和reference equivalence自身比较在本轮实际通过，没有放宽其断言。真正authorised reenter让firstPhase→IRTask→moreTasks路线可观察，是保持合法reference结果的合理修正。

## 最终独立定向运行

真实运行临时快照，三个文件：standalone-witness、verify-coverage、equivalence.acceptance；选择public witness、root-final、guarded-parallel、exact-catalog、reference、自重入、真实前驱、初始动作、compound/parallel string/object initial形态和纯guardSatisfiable局部求解。

最终：**3 files passed；68 passed / 312按-t过滤未执行（380注册），5.03s，exit0。** 这些filtered-out不是本轮通过。32个compound/parallel ×8入口×2initial形态的子集矩阵（共32）实际以invoke.input中的entry/initial动作断言验证，此外包含inactive descendants与active parallel selection。独立四组复现的原始JSON/stdout也归档，未把其数量加进Vitest68。

详见`public-path-fixed-v8-evidence/slc-v8-independent-final-targeted.log`。前一个74Rzz6的26+41通过不重复计作终稿135项；最终68是修正terminal观察后的真实重跑。

## 尚未授予的边界

完整SLC regression、生产build/typecheck/pack、PB fresh-loader修正后的最终依赖图、三平台新候选实际检查、原始冷生成矩阵复用判断、SC3全部冻结用例、registry/公共发布、CI和merge均未由本轮授予通过。当前源码通过不等同不可变rc7可覆盖新checker行为；需新版本候选并记录受影响checker入口/验证路径的重跑结果。后续产品或依赖字节变化需按影响范围重新判断。

记录UTC：2026-11-17T22:09:49.360591+00:00。

- `slc/src/verify-coverage.ts`: `ada761a84403bd824fbbf8bd476d8e93aa3f07512c2f5c873900c84e5378ddb0`
- `slc/test/standalone-witness.test.ts`: `ff3743225970452d9d7f4f9bb29732aae2f0936c00b59feffc1dc6756a6e335c`
- `slc/test/verify-coverage.test.ts`: `8c4d3920818cf190ec05530c802ce5eab71443caca0c906fff5a9c07446fe33c`
- `slc/test/equivalence.acceptance.test.ts`: `6ad87ef65244b886f7f4e5e8581a32b3bc80f3c05149a0e7af1025bbe912d9e8`
- `slc/specs/packages/verification.md`: `dd8befb68b79aa57d49ef072cbfda3e839a35c97e4db0a25b4469ff06f32c5db`
- `slc/package.json`: `360a43316ef52eee07fc745510baa5acc951147e35a9332512459edd46cbf05a`
