# Native design / harness v6 独立复核

结论：**通过本轮设计与harness修订复核（ready_for_execution_review）**。v5的N1完整gate证据链、N2 Windows采集缺件及实际compiler toolchain来源边界均已得到针对性补足。这个结论针对“冻结v5原生执行 + 完整原档 + v6独立后置检查 + 固定矩阵索引”的组合；raw result.status=passed仍只属preliminary，不能独立作为最终验收通过。

未修改产品、规格、原始执行证据或既有评审报告。本次没有重跑模型编译，允许已完整保留的实际记录通过新后置检查补审。仍不授予全部48项执行、注册表安装/公共发布、CI或合并通过；正式history和交付须不同fresh-context执行Reviewer复核。

## 阅读与独立复核

完整阅读 `tools/check-native-evidence.mjs`、`audit-matrix.py`、`record-toolchain.mjs`、`capture-completed-case.mjs`、`recollect-windows.py`、`probe-evidence-check.mjs`；读取三平台实际toolchain记录、原有四个后置负控结果及 `/tmp/evidence-probes89.log`、Windows完整capture/gzip和矩阵索引。v5 native脚本/wrapper与match-sc2-v5已登记绑定仍一致；没有将运行中的v5脚本改成新版本来覆盖旧执行来源。

读取索引的时间点为 **2026-11-17T20:27:00.010714+00:00**：24个verified、24个未执行或尚未完成。我直接import实际 `checkNativeEvidence`，对这24个indexed verified archive逐个重验，**24/24 verified，无失败**；这是本轮证据准备和后置检查复核，不等同24项正式fresh-context执行批准，更不能外推其余24项。

独立记录在同目录 `native-design-v6-independent-checks.json`，包含checker摘要、读取索引时间、逐case结果及五项临时副本探针。

## 原意见关闭依据

| 原问题 | 组合的实际拦截与独立验证 | 结论 |
| --- | --- | --- |
| N1 缺checker-start/report仍通过 | 后置checker逐条建立job+args对应的有序start/report/finish链；每个字符串文件参数必须有输入snapshot；verified finish必须有report；存在未闭合start即拒绝。直接独立重跑原两种缺日志反例，更新外层events hash后仍分别拒绝于“report无preceding input/start”和“verified checker缺complete report”。 | **关闭。**不是仅靠旧result或容器hash拒绝。 |
| N1 旧gate结果覆盖新accepted bytes | 最终fsm/continuation gate的FSM、linked gate的FSM+linked、lifecycle gate的FSM+entry快照SHA必须匹配manifest最终accepted文件；lifecycle成功链有initialize/dispose观察。独立篡改FSM并同步manifest及result的manifest摘要，仍拒绝于“没有final accepted bytes的完整成功fsm check”。 | **关闭。**有真实机械修复或较早失败的记录可以保留，最终成功链必须绑定最后accepted版本。 |
| 必需gate输入快照可漏项 | 独立新增负控：保留checker-start但删除一项FSM输入snapshot，并同步events容器hash。实际函数拒绝于“Checker input has no captured bytes”，而非偶然hash错误。 | **通过针对性补强验证。** |
| compiler TypeScript/Node typings/Spex可能来自祖先 | recorder从实际已安装SLC的createRequire解析并canonicalize工具，拒绝prefix外root，记录entry/version/hash；计算与原invocation-start相同compilerIdentity。compilerIdentity源码实际覆盖compiler代码、TypeScript入口、Spex双语语义输入及Node declarations。三平台记录的工具root均在各自candidate4 prefix内，buildIdentity均为`1a6ae516828616e121375056f2f97262e93cb4697ff9eb69aec003071258530e`；后置checker将platform/Node/buildIdentity与真实invocation-start关联。独立foreign-TypeScript-root负控拒绝。 | **关闭本轮actual toolchain来源边界。**不据此授予另一个registry-install层。 |
| N2 Windows旧递归SFTP副本缺Agent revision | capture由Windows原生Node读取原workspace+case，输出单文件gzip；scp仅传这个短路径文件，Python解压逐文件hash和安全相对路径检查；后置checker原生Windows路径映射到本地副本。原partial归档保留，完整副本另存。 | **关闭已指出的Windows empty缺件。**详见下文原始hash核对。 |

其余v4 F1/F3/F4的结论延续v5：三包packed bytes与实际XState/SDK/native acquired-tree约束、父fixture/链接目标/祖先配置保护、caller/config/result TC归属已修复。仍以对应脚本摘要和完整原档为前提；新后置检查不替代这些前置及原生过程断言。

## 独立反例结果

临时副本来自真实macOS Codex empty档案，只改副本。删除事件时故意同步result.eventsSHA256；更改最终FSM时同步manifest容器和result.manifestSHA256，避免仅靠外层摘要挡住反例。

| 反例 | 实际结果 |
| --- | --- |
| 删除全部checker-start | refused：Checker report has no preceding input/start: fsm |
| 删除所有非lifecycle checker-report | refused：Verified checker lacks its complete report: fsm |
| 最终FSM改变，manifest及外层摘要同步更新 | refused：No complete successful fsm check of the final accepted bytes |
| TypeScript root改为外部目录 | refused：Compiler tool is not from the acquired installation: typescript |
| 保留start但缺一项实际参数snapshot | refused：Checker input has no captured bytes |

原有正控及本轮24份真实完整档案均通过。这里没有要求为等价名字改动增加新样例，也没有添加业务Boss turn、真实业务效果或结果质量验收。

## Windows采集修复核对

对 `native-complete-05/formal-TC-local-windows-codex-empty.json.gz` 独立读取解压：capture含82个文件记录；压缩包SHA与Windows原生capture stdout中的archiveSHA256相符；82项原始字节/记录SHA及解压副本逐项一致，无差异。capture的原机workspace对output-copy比较为 `collectionComparisons: []`，支持“原机档案完整，旧递归SFTP采集不完整”的定位。

原缺的 `agent-3a2b0ea9-24b7-423f-8aa2-246d179c08d0-flow.gears.opt1.md` 已在新complete副本恢复；整个case的41个snapshot及完整gate链通过实际后置函数。旧 `native-05` partial副本仍缺此文件、未被覆盖，因此先前缺件结论和恢复路径可追溯。该case后续应引用 **native-complete-05** 与对应gzip/capture记录，不能再引用旧partial作为完整证据。

## 最终判定应使用的边界

1. v5原生真实编译及其初步pass，保留OS/backend/父状态、包/输入/环境、时间/退出及失败历史。
2. 原档完整采集；Windows使用短路径单gzip恢复路径，旧partial和失败回执保留。
3. 对具体case运行本轮摘要对应的只读后置checker，snapshot、manifest/runtime文件、entry JSON verified、完整最终gate链及actual toolchain均通过后，才能列入`evidence-audit-05` verified。
4. 以固定48唯一坐标汇总，未完成集合不计pass；最终执行Reviewer复核原始来源、case对应关系与history导入，公共发布/registry/CI/合并分别维持自己的门槛。

`audit-matrix.py`实际按固定48集合扫描matrix receipts，对Windows完成项先重新采集，再调用后置checker；失败记录为blocked/execution-failed，未完成单列。本轮索引仍只有24项，不能把审计脚本准备完成理解为48项全部成功。索引会继续更新，本报告只批准已读取的实现与修复边界。

后置工具的本轮源码摘要如下，后续history/正式执行复核应明确绑定这些实际检查器/采集器及toolchain记录；工具或产物改变后不得沿用旧结果：

- check-native-evidence.mjs：`b2d8f726c77ae48692368a41a2f11690e211578e12e5c47791ec8165df3e6a31`
- audit-matrix.py：`b77f9f98f6d19ca432c0a24c7d2a164e19c2ab1056faefb55761b552cff4ba49`
- record-toolchain.mjs：`a6d4c3476b5eafbc42b05d3befca021c3fe111646dd0ce9482c2a827aff70b96`
- capture-completed-case.mjs：`f889a2515a9e4b035b11d0156b0d689b546951c074b95362a05f0cece4aedfcd`
- recollect-windows.py：`2dd7588baa587f5d69f6a1e3464a2b9b5975b9e3a5d491650b7d72c3fb6ecd1b`

外部长任务真实结果可以随后如实导入history；仍不得将其称为从未发生的operations.execute。六次blocked stdout的真实分类继续是两次300秒参数拒绝、四次storage busy；原先失败、初版put错误及进行中case不重写为pass。
