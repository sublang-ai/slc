# SLC failure classification and rc.4 → rc.5 evidence-impact review

- Acceptance ID `AT-slc-global-20261117`。Independent Reviewer `/root/slc_impl_review`。
- Scope：实际新发现的环境错误归因修正、取消/已确立 artifact/未知 checker 的回归边界，以及既有 rc.4 冷编译证据对 rc.5 的可沿用范围。只读产品；未启动真实付费 Agent、未修改代码/规格/原始记录。
- **实现结论：当前最终读取版本的定向分类修正 passed；复核中发现的两处类别混淆已修复并独立复测通过。本轮不授予最终全量回归、候选安装/矩阵、公共发布、CI 或 merge 通过。**
- **影响面结论：有依据进行选择性失效与补测，不存在仅因这一归因补丁就必须全部重做 48 次真实冷生成的明确分支。** 但这不等于把 rc.4 观察改成 rc.5 观察；下述当前包安装、冷启动桥接、当前身份重验与失败路径重测是复用成立的条件，失败/缺失旧例不能被推论补成成功。

## 1. 原始依据与实际代码边界

已读两仓库 AGENTS.md、ADR-068、`verification-73/-83`、`standalone-compilation-7`、`delivery-acceptance-1..10`、TEST-METHOD，以及 Skill 独立复核/需求级判定对“实测与源码推论分开、说明未实测差异如何命中分支”的要求。

已核对主 Agent 的 red95/green96 原始日志：原三项真实 runSlc 集成用例均先因 cause=artifact 断言失败，后转绿；occupied metadata 同时要求 Agent 0 调用和原文件字节不变。两个 transport 用例走真实 interpreter/runSlc 流程，但用确定性 Agent error response 注入已观察的原文；**它们本身不是新发生的真实 provider outage**，本意见不混淆这两种事实。

当前 outer catch 保留真实 ArtifactEnvironmentError.category、已知 I/O code 与准备阶段环境性质；已准备后的未知内部异常，在没有明确 artifact 证据时按 checker-failed，不再要求改 Source 语义。正常失败结果按实际 aborted signal 优先；native permission/显式 checker 原因与 TS artifact 证据优先于 transport 文本启发式。

## 2. 独立实际复测与已关闭的问题

未仅依赖旧 dist。将当时全部 src 转译至 `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-raqOI1`，并核对终稿 src 与该 source-identity 摘要；本轮直接 probe 与测试使用该快照，未修改产品。

### 复核曾发现、现已修复的两处混淆

初稿把环境 regex 放在取消和 native-artifact 判据之前。

- `/tmp/slc-v5-cause.mjs` 当时用真实 runSlc，在 executor 内 `AbortController.abort(Error('caller canceled during ERR_PROXY_TUNNEL'))`；signal.aborted=true 却得到 environment。
- 同一脚本在包含 `ERR_PROXY_TUNNEL` 的真实临时路径中，经 native lifecycle 权限 fork 尝试写 Source；finding 明确为 `artifact: ... forbidden verification side effect (FileSystemWrite at ...ERR_PROXY_TUNNEL.../flow.md)`，却被映为 environment。Source 保持不变。

已立即反馈；最终代码增加 actual signal 优先，按结构化/明确证据分类，并把 transport 匹配限于适用消息形态。当前 `/tmp/slc-v5-cause-fixed.mjs` 已独立得到 **canceled / artifact**，Source 仍不变。不能拿 red/旧中间实现的结果冒称最终包还有相同问题。

### 最终当前源实际结果

1. 复制当前 selfhost.test.ts，仅把 `../src/` import 指向快照 dist，选择原三项及实际 aborted signal 一项：**4 passed / 48 skipped**。这 48 是本次筛选未运行，不是产品通过数。
2. `/tmp/slc-v5-cause-fixed.mjs`：真实 aborted runSlc 的 cause=canceled；真实 native permission finding 的 mapper=artifact；Source 字节未变。
3. `/tmp/slc-v5-outer-cause.mjs` 实际进入 managedCompilation prepared 后 catch 的五项控制：unknown internal→checker-failed、explicit concrete artifact→artifact、native ERR_ACCESS_DENIED→artifact、EACCES→environment、explicit category environment→environment，均符合独立预期。
4. 旧成功轨迹里的 6 份真实非空 CLI checker findings（含 TS、prompt-fidelity 修正）用最终 classifier 重算，均与原 rc.4 输出的 artifact 类别一致，未误归为 environment。

因此 `verification-73/-83` 与 standalone-7 相关的这组已建立原因得到正确区分；这不声称 free-text classifier 对任意未来异常文本具备完整语义识别能力。

日志 `evidence/commands/slc-full-rc5.*` 已显示 2068 passed/2 skipped、exit0，但其执行完成时间早于本轮最后的优先级修订，**不将它算作最终源码的全量绿灯**。最终版本仍应完成自己的要求内回归/CI，并以对应 hashes 记录。我的独立通过仅限上述定向范围。

## 3. 不可变包的实际字节比较

本轮已对实际 tgz 解包成员逐字节比对，不只是 git diff。事实如下：

| 对象 | cohort04 / 原版本 | cohort06 / 新版本 | 结论 |
| --- | --- | --- | --- |
| SLC | 0.23.0-rc.4，SHA `688bb17dea70d9d39cbbec7c54382ad0bf81488c93e5903e360ac62e80ad1c73` | 0.23.0-rc.5，SHA `effaac36846956af35900cb5094f5f0cbf0a33cffd030531af2d091ed6faeb88` | 209 个文件中 201 同字节、8 变更，无新增/删除 |
| Playbook | 19.1.0-rc.4，SHA `a7c2df3dc1b64238e7ec7ff56aac6a734a84003a0204890abfdba7de449c5e7e` | 同一 tarball | 175 个包文件对当前内容全部相同 |
| Cligent | 0.40.0-rc.2，SHA `d826a46839b6257cebe349c16b9393a7fc3750a64f585828e73e9a786cf31fa3` | 同一 tarball | 263 个包文件对当前内容全部相同 |

SLC 8 个变更是：

- 可执行 `dist/check-report.js`、`dist/managed-compilation.js`；后者只改失败结果的 cause 和 catch 分类，没有改 ok/phase/generation/lifecycle/manifest 发布成功主体。
- check-report.d.ts 的文档说明及四个 map 文件。
- package.json，解析后只有 version 从 rc.4→rc.5，依赖、bin、engines、入口和其它字段相同。

`runner/interpreter/compiled-executor/cligent-agent/config/CLI/entry/TypeScript/coverage/checker/lifecycle/ABI` 等其余已打包执行字节相同；PB 的 definitions/runtime 和 Cligent SDK/native acquisition 代码也不变。源码中本地 pins 刷新不能被忽略，但它们不在这两份 SLC 包内；该 production PB 包也没有 slc.pins.json。安装态实际执行的语义闭包仍必须按各平台 acquired tree 核对，不能用 checkout 中未运行的 pin 文件代替。

**必须单独处理的版本差异**：compilerIdentity 实现虽未变，却会 hash package.json 和 emitted code，故 rc.5 compiler.version/buildIdentity 必然不同。这会使旧 accepted bundle 命中 `invalidReuse/revalidateReuse`；新的安装/manifest/current revalidation 证据不能简单借用 rc.4 的 identity 记录。

## 4. 旧正向证据的独立核对及适用性

在本轮固定读取的 index 快照中有 29 项 verified（不是把开始交接时的 24 项写成最终数）；6 项 execution-failed，13 项未完成。索引仍在由主 Agent持续更新，以上仅是此次审查快照。

- 我独立调用当前 `checkNativeEvidence()`，对这 **29** 份原始归档逐项重验，**29/29 verified**。包身份均实际为 SLC rc.4；未改 result.json、cohort、源码版本或档案内容。结果在 `/tmp/slc-v5-recheck-rc4.json`。
- 这 29 份 attempt 日志没有新匹配的两类 transport 文本，host checker-finish 没有失败 findings/error。
- 不能仅凭最终 ok 推断 Agent 生成过程中没有失败分支：因此又解析其真实 Agent tool_result，得到 76 份 `sublang.slc.check.v1` 返回，其中 70 verified、6 failed 后被纠正。将 6 份非空 findings 交给最终新 classifier，**categoryChanges=0**。每个被审成功 case 均有此类真实工具返回，结果保存在 `/tmp/slc-v5-old-cli-checks.json / old-cli-check-delta.json`。

这提供了具体源码推论依据：在这些**已观察成功轨迹**中，新的失败输出逻辑不改变 Agent 已收到的类别、实际 gate findings、阶段输入、生成流程或最终接受结果；最终 result.ok=true 又不会进入新增的 failure cause/catch 分支。与 package byte diff 一起，足以支持这些父目录正向行为对当前补丁属于未受影响范围的论证。

这不是证明 rc.5 必然生成同一份 FSM，也不是新的真实 Agent 观测。随机 Agent 生成的稳定性不由本补丁保证；原 rc.4 冷生成事实、rc.5 源码等价/不影响推论和 rc.5 新实测必须在报告中并列。

## 5. 受影响验收与最低补证方案

按 delivery-acceptance-8 的 **affected evidence** 处理，同时保留 -2/-3/-6/-7/-10 对实际平台、候选身份与完整交付 gate 的约束。Skill 允许的源码推论用于说明未受影响范围，不能修改旧执行收据的版本或把 cache/replay 改名为 cold compile。

| 范围 | 可保留什么 | rc.5 必须新增/重测什么 |
| --- | --- | --- |
| 已 verified 的 rc.4 父目录冷生成正向样本 | 真实 OS/backend/parent/Source、Agent 调用、冷过程、最终产物与无父级修改；连同本次不影响分析作为旧版观察依据 | 用最终包/完整闭包 diff 和当前版桥接/检查证明适用性；不得称为 rc.5 已实跑该 TC |
| 原 48 中 failed/未完成 | 仅保留真实失败/尚未完成事实和原因 | 继续用新的空子目录取得每个必需组合的真实成功；classification 修正不能把它们“推成成功” |
| 环境/传输失败归因 | 旧原文可证明原问题存在 | occupied metadata（Agent0调用、文件不变）、两种 observed transport、EACCES/权限与显式环境类别，按真实处理边界重测 |
| 类别优先级与未知检查错误 | 旧错分类历史不能代表最终实现 | 真 signal cancellation（含 transport 字样）、native permission（路径含 transport 字样）、明确 TS/契约 artifact、unverified exhaustion、unknown checker，保持失败且 cause 正确 |
| 安装与 package identity | rc.4 acquired tree 的版本事实 | 三个原生 OS 新 prefix 只请求 exact rc.5，验证 packed bytes 与完整生产依赖树、两个 SDK/native 组件/工具身份；不能把相同 package.json 依赖范围当实际闭包未变 |
| 当前 cold start | rc.4 真 Agent 观察保留 | 至少每 OS×backend 有当前 rc.5 的新 empty-child 真实冷生成桥接；若承担正式 registry post-install smoke，empty 与 CommonJS 两类均必须满足，即 **3×2×2=12**，不可只做6后宣称 -7 满足 |
| 当前 checks / identity / reuse | 旧输出 byte snapshots 可作明确输入 | 用 rc.5 对保留输出做 current gates/entry init-dispose；显式测试 rc.4→rc.5 compiler identity 变化引发的重验、发布新 manifest 后再次 unchanged reuse 不调用 Agent；这些是新重验/复用证据，不是新冷生成 |
| full regressions/pins/CI/release | 旧执行如实留存 | 最终同版要求内回归与 pins/CI，原 blocked public publication/audit 不能借推论放行 |

推荐做法是在原生三平台上，对已保留/最终完成的旧 runtime 输出批量跑**不花 Agent 调用的当前检查或 completion**，记录新 compiler/environment/manifest identity；同时用新 prefix 的两个 backend/empty+CJS 真实 cold smoke 作桥接。这样可以获得很强的当前版直接检查证据，而不把所有未受影响父目录样本重新付费生成一次。重验输出应放独立目录/新记录，保留原归档不变。

rc.5 新安装的 transitive dependencies 仍可能因 registry 解析变化而不同；若 SDK/default model、TypeScript/Node typings/SPEX、PB/XState 代码、definition/语义输入、checker/lifecycle 或启动/模块选择出现实际字节变化，必须重新分析命中的平台/backend/父目录分支。不能在这些条件变化后仍套用本次“仅归因变化”的结论。

## 6. 是否需要全48重新冷生成

**就已核对的精确包差异，没有必须全48重跑的代码依据。** 新代码对已成功且未进入这些失败类的执行没有新分支；已观察的中间 checker 返回也不变，因此可依据本次影响证明保留这些旧正向样本。

但存在三条不能省略的边界：

1. 最终覆盖仍需覆盖全部约定组合，任何 failed/missing 不能被成功样本、mock、replay 或源码推论替代为“实测冷成功”。
2. 当前 rc.5 的安装身份、新冷启动和 compiler-identity/revalidation 分支确实变化，必须直接补证；registry 的 empty/CJS 原始约定不因本次评估被减少。
3. 若最终要求要写成“**所有48次都由rc.5实际执行**”，该表述只有全部48次真实 rc.5 执行才能支撑。可选择性复用的正确表述应是“rc.4真实矩阵观察 + rc.5精确不影响推论 + rc.5当前补测”的需求级结论，交给独立需求 Reviewer 按实际收据确认，不能自动把旧 TC 状态改成新版执行通过。

没有足够数据排除受影响分支的具体旧样本，应重跑该样本/分组；如果变更进入所有 generation/acceptance 共有路径且无法证明等价，才可能使全部48受影响。本次已完成字节与轨迹核对的差异不属于那一情形。

## 7. 交付 gate 与精确版本

cohort04 SHA `d98865e1b2463092844cbcafd454209a37941b2f94639ad690bd27c49fae56b2`；cohort06 SHA `e067454f55c7f3c4f785b9a8b20482e170c2ec3ce2c8dce8fc5c7e006bf36a4a`。两者 immutable 事实已分别读取，不相互覆盖。

公共 npmjs 发布、未发布依赖、development audit、最终同版 CI 和 merge 仍按既有阻塞保留。本意见既不批准 merge，也不把 isolated LAN registry 的有限替代证明写成公共发布通过。

终稿读取 UTC：2026-11-17T20:59:52.304569+00:00。

- `slc/src/check-report.ts`: `b7b5e3613f943b7853529b064055face08006a83419cdd11ed1452d43a6ac01e`
- `slc/src/managed-compilation.ts`: `c7d0dba6021f8e731d0cee6c87dc2ddfd50e39d5ca68b700056d1023b9dacb09`
- `slc/src/cli.ts`: `c6644ea118ec8d3727443f7a1e212f627c7a4fa14b0450023aed80bb10171872`
- `slc/src/compiler-identity.ts`: `11bdd778f6e4f7b75f326c50abc293930ec18a887d1923b9288b932efe70ebfb`
- `slc/src/runner.ts`: `a67bced329f17eda9b78669689da9a310c3a476e9268e1ce8bbde86a300eaf9f`
- `slc/src/errors.ts`: `cfef3f047f15f3b9e153f149adefc8f640616bcc6b0f48abe5476bb93c7f3622`
- `slc/test/selfhost.test.ts`: `37c7427a686dc9820bf23f0528782e48f23af5d55efe8cca0a918f7cbe7087fb`
- `slc/dist/check-report.js`: `a8f2a351c7d77378586134f600d582f0258c06d014ced2b5293cb2477949b864`
- `slc/dist/managed-compilation.js`: `8288e80e7f7832e93661bc9b74981dcf1254e8c67ab7da4a9e8041cae2e259f7`
- `slc/package.json`: `26eb806cf105409a19ddb27b656889b89b95552df61a8d73d2b65bc03fc93c4b`
- `slc/specs/decisions/068-standalone-compilation-environment.md`: `a84a17c16209272c910a02d7bd371cd46e30ded38610b8b589e23ce0ad14f11f`
- `slc/specs/packages/delivery-acceptance.md`: `e4e7ddbdc28991275f33968d3b95114aee4cbf8955849ce1e5afd635820dfd03`
- `slc/specs/packages/verification.md`: `3739897adb4de119aa4354951b8c0a9a1b0c690799491f7025f52b6d5ade8376`
- `slc/specs/packages/standalone-compilation.md`: `5fb1208c404aa1726837d2fd6c658658703705d9fcd661514108e1c7c251ac0e`
- `slc-global-delivery-20261117/evidence/candidate-cohort-04/frozen-cohort.json`: `d98865e1b2463092844cbcafd454209a37941b2f94639ad690bd27c49fae56b2`
- `slc-global-delivery-20261117/evidence/candidate-cohort-06/frozen-cohort.json`: `e067454f55c7f3c4f785b9a8b20482e170c2ec3ce2c8dce8fc5c7e006bf36a4a`
- `slc-global-delivery-20261117/evidence/alternative-branch-registry/sublang-slc-0.23.0-rc.4.tgz`: `688bb17dea70d9d39cbbec7c54382ad0bf81488c93e5903e360ac62e80ad1c73`
- `slc-global-delivery-20261117/evidence/alternative-branch-registry/sublang-slc-0.23.0-rc.5.tgz`: `effaac36846956af35900cb5094f5f0cbf0a33cffd030531af2d091ed6faeb88`
- `slc-global-delivery-20261117/tools/check-native-evidence.mjs`: `b2d8f726c77ae48692368a41a2f11690e211578e12e5c47791ec8165df3e6a31`

本 Reviewer 的独立快照/计算与反例：
- `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-v3-source-raqOI1/source-identity.json`: `9bfd3f6a033fc0c189470614a93c18ef3787ba56750329579621da6ca31b137e`
- `/tmp/slc-v5-cause-fixed.mjs`: `6bffad2bc299232dcaf5e5471471fd3bf1130f2d6a426c45ecb57afc2719b817`
- `/tmp/slc-v5-outer-cause.mjs`: `6ac2c9ccc0134b3d6557542e90db026fbb0de48743323d4fa560f55fcbba5db5`
- `/tmp/slc-v5-package-byte-diff.json`: `26f092e7dcc32a34f536abaebc2a4fb568c41bff7ca14340bfe5b46f4cbf9592`
- `/tmp/slc-v5-recheck-rc4.json`: `b5d87aa6c4a1983e14d0e4ad9810469e452fda0e7da060aefdae178d95c8af5e`
- `/tmp/slc-v5-impact-observations.json`: `205656483831760a26550f836669016c5c36f836d67c97ad21d7820fa4557b75`
- `/tmp/slc-v5-old-cli-checks.json`: `7b34fabcc593ead0cac54fa1d1eeba11a23e69040a44f80a57761adc20113503`
- `/tmp/slc-v5-old-cli-check-delta.json`: `222e737d6ce75992d17a2f3fd2ff973cfcb9e8dd5e4053adffc3b8737bc73e02`
