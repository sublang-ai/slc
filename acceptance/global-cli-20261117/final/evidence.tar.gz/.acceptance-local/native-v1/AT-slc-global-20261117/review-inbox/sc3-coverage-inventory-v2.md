# SC3 15项证据盘点 v2

记录时间：2026-11-17T23:04:01.032254+00:00。独立Reviewer `/root/native_design_review`；本轮只读源码/收据，没有修改产品、运行测试、构建、安装或调用付费Agent。

**结论：四类明确缺口已补上；仍不能赋予SC3 15/15 passed。最小新增夹具为两组：managed foreign live link、accepted managed身份变化重验表。更紧迫的现有执行门槛是SLC rc9：最近已绑定rc8全套有12个completion失败，当前coverage/worker又变化，不能用rc7历史全绿覆盖。**

PB rc5 full-v2已经完成exit0：3092+156=3248 passed、34 skipped，artifact-environment16项实际通过且关键当前源码摘要匹配。四个Source omission在后续rc8 JSON各自passed；不能因rc8其他12项失败抹去它们，也不能把整个rc8称为通过。

## 新补证的判定

- Public host marker：7变体×provision true/false，通过真实loadLaunchPlan/publicprepare；有效mjs与genuinelegacy.ts实际import入catalog，坏managed在import前拒绝。对应旧缺口关闭。
- Source return：producer.message、producer.reason、output.message、output.reason各独立缺一项，逐一assert Source位置、condition、field和findings长度1，实际rc8四项passed；checker源码未再改。对应旧缺口关闭。
- Public path：fixed-v8独立证据在同一FSM记录absoluteSTART→prepare→work:START:true→work:BOSS_INTERRUPT:true；none/missing/relative/deadSTART对照实际拒绝，terminaltarget缺真实interrupt微步也拒绝。核心漏洞已关闭于该源码；当前rc9新solver/loop需新执行绑定。witness是additive，坏path不能提供证明，但若普通探索真的找到合法前驱路线应允许成功，不把坏witness改为全局否决。
- Fresh CJS：原native-v2 module.require1!=999红灯保留；当前真实PB JS `84cc23504566bcaad7152e57b6f744b806beea921e39539e68adbb22cae16384`的两跳旧manifest拒绝→更新→999及真实product58材料已补。58中28功能命令+30控制；后30有2个预期exit1的unscoped拒绝，绝不说58都exit0。

PB loader当前spec7/DR110明确logicalrevisionURLs、不保证ESMself-file read，保持physicalcanonical配置locator、相对目录及CJSlexical名。这个有限元数据边界可以作为managed空目录目标的最小实现边界，不能称完整Nodeinterop；现有Source没有要求使用import.meta.url读取自身。无需为这个未承诺能力增加“必须selfread成功”夹具。

## 逐项核心范围与当前证据

15项都与已经接受的环境/编译/安全初始化或兼容回归约定相关，不属于业务输出质量。没有理由把某项整项删去；但“每个形容词必须在一个巨型fixture同时出现”或OS×Agent×故障×stage全部相乘不是原目标。下表是证据充分性建议，正式case判定仍未由本盘点赋予。

| 用例 | 核心证据与判定 | 最小还需工作 |
| --- | --- | --- |
| `TC-archives` | 真实runSlc接受bundle后删除Source、GEARS、.slc与辅助checks，public manifest验证和独立lifecycle仍可运行；改可执行FSM/二跳helper即拒绝。；PB rc5 full-v2对两种entry布局的缺档fixture通过；runtime identity源码只枚举公共运行时闭包及声明，不枚举docs。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |
| `TC-budget` | 真实10调用、default/larger finite budget、attempt竞争前缀、duration/derived allowance、并发策略及started==stopped actor清理有独立断言。；生产/保护consumer/两个真实emitted subprocess执行小预算拒绝与大预算通过；invalid policy在artifact读取前拒绝；worker exit无authenticated report与abort分开拒绝。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |
| `TC-gates-cjs` | 当前PB同一native子进程实际helper1→旧manifest拒绝→新manifest验证→fresh999，对require/module.require均16项文件内通过。；当前真实product JS84cc2350…的58命令保留：28功能commands、12literal-reexport、native error/no-scope/stack controls；读取原始returned fields，不把58统一称exit0或全格式通用pass。 | PB当前绑定已补证 |
| `TC-gates-pair` | PB真实selected-XState正控不受broken父依赖影响；真实nested support解析foreign XState时inspectArtifactFiles拒绝，不先执行foreign代码。；PB rc5 full-v2绑定了这些实际断言；三包/selected roots及两links的独立原生harness约束另有证据。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |
| `TC-gates-types` | project TypeScript被设为执行即throw、坏Node ambient、无关tsconfig；compiler-own check接受process.argv:string[]而拒绝TS7006。；真实relative support actual module format和TS2322正负对照、package-less linked/FSM及原父状态冷矩阵另有证据。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |
| `TC-init-effects` | 实际native construct/init/dispose FS写Source各自artifact拒绝且Source原样，dist CLI exit1/categoryartifact；同权限inert正控通过。；ordinary/伪造IPC不能代替构造失败，真实loopback正控收bytes但受限nativeSocket不产生BUSINESS_WRITE；完整checker report queue-drain含真实init/dispose观察。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |
| `TC-init-required` | inert optional真实初始化释放；validator真正requires file时空fixture返回unverified并保留Source原因，constructor sentinel不执行。；required structured options实际Captain shell测试证明未凭空补domain值；编译finalize与retained completion都接入同一生命周期机制。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |
| `TC-layout` | PB两entrylayout验证真实通过；runSlc -o relocatedtarget实际生成且无默认entry。较早独立ESM-o成功/CommonJS实际format失败不是目录ban。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |
| `TC-markers` | public loadLaunchPlan+prepareConfiguredRegistries实际7variants×2provision选择：validmjs和真正无footprintlegacy.ts实际import并出现catalogworkflow。；missing/malformed/duplicateheader、missing/malformedmanifest各自在prepare拒绝，import seam未调用、入口字节未动；enabledfalse不允许降级。 | PB当前绑定已补证 |
| `TC-occupied` | managed公共服务对real occupied XState目录和foreign user metadata拒绝；不创建package metadata/另一PB link，原user bytes不动；clean/repeat正控通过。；runSlc foreign metadata在Agent0前environment拒绝。 | MF1 |
| `TC-public-path` | fixed-v8独立冻结源码复现同FSM：absoluteSTART→真实prepare→work:START:true→work:BOSS_INTERRUPT:true，无contextpatch。；同FSM none/missing/relative/deadSTART实际unverified；无trace装饰的deadSTART仍拒绝；terminalinitial target不能仅atState误判interrupt已发生。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |
| `TC-reuse` | accepted managed unchanged allphase reuse确实zeroAgent prompts、恢复辅助outputs并保持history bytes；PB改entry/helper拒绝及generic semanticinput变化另外真实执行。；managed源码会比较compiler version/buildIdentity、validate current runtime roots/version/content，并在invalidReuse时走revalidation。 | MF2 |
| `TC-rollback` | 真实acceptedA→Sourcechange/producerconformancefail：latest/entry不动、A再validate/init成功且retry真的调用producer。；独立cancel在FSM实际重写后发生，runtimefiles/manifest/latest每字节及两ownedlinks目标恢复，A再次validate/init成功。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |
| `TC-source-returns` | 新增producer.message、producer.reason、output.message、output.reason四个独立mutation各有findings长度1，Source line1、具体中文condition、缺field及producer/output类型的断言。；rc8 full原始pertestJSON四项均passed，完整正控及ambiguityunverified也passed；verify-source当前SHA与该receipt相同。生产调用位于GEARSproducer边界，先于FSMconsumer。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |
| `TC-witness-authority` | 真实events-only绝对START正控；reservedhost/privateinputs、xstate internal event、renamed/nestednonemptyoptions均实际拒绝/unverified。；此前独立configured-child/undeclared-child强反例已记录；当前不凭字段名，而对无Source-derived权限的所有nonemptywitness input统一拒绝，不能借改名重开权限。 | 既有当前SLC执行绑定/下述边界，非自动新造大夹具 |

## 只要求两组最小新夹具

**MF1 — TC-occupied**

对managed prepareArtifactEnvironment布置一条指向真实foreign目录的live xstate/PB link（非legacy provisionEngine），保留foreign sentinel；调用公共prepare，断言occupied/foreign路径与可操作repair、package.json/另一ownedlink未部分创建、原link和foreign内容未改。

**MF2 — TC-reuse**

同一个actual accepted managedA为baseline，unchanged验证zeroAgent；用参数表独立改变recorded/currentruntime root/version/content、compiler buildIdentity、entry/helper bytes，观察currentgates重验/具体refusal或rebuild，不能unchecked up-to-date；合法重验后再unchangedzeroAgent。实际新candidate rc4→rc9/PBrc5身份迁移证据可覆盖对应坐标，不为等价名字再重做。不得改开发者真实依赖树，使用isolatedpackedprefix/副本。

这两组是独立可失败的安全/状态分支，当前未定位实际执行；不是要求再跑付费Agent生成。managedforeignlink与legacyprovisionEngine的foreignlink不是同一个ownership分支。reuse也不能拿generic incremental contenthash或Source改变重生成代替“已accepted、身份变了、无unchecked up-to-date”。

## 不再机械膨胀的辅助条件

- archives的无关docs mutation、pair诊断字段逐一assert、types把ES5/CommonJS/ambient/FSM/linked全塞同fixture、budget所有值×所有入口全乘：可以补强，但现有真实机制组合足以支持核心；未执行的精确辅助条件在JSON如实保留，不伪称已观察。
- init-effects已有三个nativeFS阶段、IPC真报告、nativeSocket正负控及真实acceptancegate接线；无需再为每个businessport×stage跑完整model pipeline。普通异常与effect失败共享native捕获边界，不增加业务任务执行。
- rollback已有producerfail与实际写后cancel、runtimefiles/manifest/latest/links恢复及A真实init。checker写后fail或runtimeB原安装不可用分支仍未实测，不把它们称pass；先看MF2是否触发不同transaction路径，再决定是否需要一个追加负控，而非预造全故障矩阵。
- witness改名不需要新案例；重要的是没有Source-derived权限时所有nonemptyinput都不能授hostauthority。当前已有reserved/private/renamednested强负控与独立child反例，后续运行当前source即可，不扩成同义key清单。

## 当前执行事实不能跳过

SLC rc8实际2083注册、2069passed、12failed、2skipped；12fail全在completion，包括en/zhretained、usablebuild、inside-bundle实际import、protectedmutation、callablevalidator等。它们有的在更早coverage阶段失败，不能称后续mutationguard通过。rc9的verify-coverage/verification-worker及witness/budget测试又变化；当前真实demo还在调试。所以completion依赖的init/layout/reuse等当前状态必须等新修复/原有测试重跑，不能仅展示源码或PBfull绿。

当前PBpublic-host/fresh文件及生产JS匹配PBfull-v2绑定；SLC verify-source与四omissiontest匹配rc8相关passed，managedcompilation/selfhost代码也未变，但verify-coverage/worker变更足以使旧整条编译路径证据需要重判。完整逐file当前/receipt摘要差异与percase证据类型已在JSON保留。

NativeWindows exactdrivepath还缺当前同FSM的实际执行，可直接跑既有fixture/独立checker，无需付费Agent。macOS Node25/26的58productcommands不能代替Linux/nativeWindows installedpackage运行。RC4旧cold生成结果不可改记PBrc5/SLCrc9；其当前重验/受影响源码范围、registry、CI和merge另受各自门槛。

同名JSON保留冻结15case原文、每项核心相关性、实际/组合证据、精确未观测边界、最小夹具ID、源摘要和收据hash检查。这个盘点修正“全部都partial所以再写15个端到端”的过度解释，同时保留原始失败、条件分支和当前候选执行缺口。
