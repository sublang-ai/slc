# Native design/harness v5 独立复核

结论：**needs_revision（SC2 implementation / SC4 收集证据完整性）**。v4 的 F1 外部 XState/SDK 来源、F3 父树/相关祖先保护、F4 TC 归属与配置绑定均已有针对性修复；F2 真实阶段及快照审计已明显补足，但每个必需 gate 的完整输入→报告→结果链仍未成为必要条件，独立副本负控可全过。此外当前收集到的一份 Windows passed case 缺失被日志引用的 Agent 修订快照，不能授予完整证据通过。

本报告只复核设计/harness 与已完成调试材料的准备边界，未修改产品、规格、原始执行档或 v4 文件。不授予全部48项真实编译、registry-install、公共发布、CI或合并通过；实际执行/history仍须不同fresh-context Reviewer复核。

## 已核对

- 需求基线及TEST-METHOD/相关原规格沿用v4报告，设计没有扩大到业务执行或业务结果质量。
- 完整阅读 `native-case-v5.mjs` 186行、`run-native-v5.mjs` 28行、`make-native-configs-v5.py` 16行、`run-matrix-v5.py` 17行。
- 全96份 native-configs-05 JSON坐标/平台/backend/parent与标签一致，96个work互异；48坐标各有debug/formal两份。
- `match-sc2-v5/result.json` 为matched/full，**execution_status=not_executed**。98个bindings（native脚本、wrapper及96配置）全部与读取时文件摘要相符。native脚本SHA为`4e77c2ba03f06361061a12013ab4a3c8a22ff04d4cd0bb399989048d197f92f4`，wrapper为`73ee22ce5d499e50fa05f553ae262e5442a2397cd6ebb812ff166a6175aae2c9`。matrix/generator是调度与生成工具；现有已生成配置已绑定，未来重生成改变摘要须重新登记，不能只沿用旧match。
- `evidence/preflight/harness-probes-05` 的三个stderr、symlink-target/ancestor-metadata JSON；`audit-probes-05`正控及缺phase/gate负控；`tools/probe-audit-v5.mjs`与实际verifier代码。
- `evidence/preflight/NETWORK-ENVIRONMENT.md`；pre-put-hoist保留脚本与三份transport错误；六份native-operation-04 stdout。
- 补做只读归档交叉核验及独立临时副本探针；记录分别为同目录 `native-design-v5-completed-archive-audit.json`、`native-design-v5-probes.json`。

## 对v4意见逐项判定

| 原意见 | v5修复及第一拦截 | 复核结论 |
| --- | --- | --- |
| F1 外部同版本XState/SDK被双边同时误选 | native :51对selected PB/XState canonical根、:53–57对两个SDK canonical根、:60–66对选中native canonical路径/字节/实际--version使用prefix约束；:144复核三包packed bytes、native bytes和pair未变；:167–169核对实际preflight/backend/model。foreign-xstate和foreign-sdk已在ownedPath(:157)拒绝。 | **关闭原列出的XState/SDK/native外部来源漏洞。**三包独立packed-file锚点保留。完整工具闭包来源边界见下文，不将这项直接扩称所有dependency closure已证明。 |
| F2 仅manifest/entry退出零即可通过、过程档案缺失不拒绝 | :161要求单一cold invocation；:165要求五个真实phase-start和五个ok return；:166检查耗时、最终产物及Agent revision存在；:167–173检查实际Agent、gate、lifecycle和全部已列快照摘要。已有完整真实五阶段正控通过，删除prefix phase-start或lifecycle finish负控拒绝。 | **部分关闭，仍needs_revision。**缺少必需gate完整链及与accepted bytes的关联；独立负控详见N1。 |
| F3 父快照不跟踪symlink目标/祖先 | :153捕获目录/mode/空目录、link实际目标及包内内容；:158生成目标包清单；:159记录各相关祖先Node配置的存在/摘要/mode及Git存在；:107显式检查Git内/外；:141–145比较。已有target内容改动、祖先manifest/Git改动探针可见前后差异。 | **关闭原fixture直接链接目标、目录状态和相关祖先配置保护缺口。**不把限定包内容清单泛称递归扫描整机；该扫描排除目标包内node_modules。当前fixture声明的直接依赖通过各自入口记录。 |
| F4 caller TC/config/result错配 | wrapper :8–9检查caller/config tuple；native :15–16强制caller TC等于native配置/真实OS；wrapper :26检查采集result tuple与zero-exit/pass关系；match绑定wrapper+全部配置。wrong-requested-tc负控在:15拒绝。 | **关闭原归属漏洞。**wrapper结果校验与binding必须继续用于最后固定48唯一坐标汇总；运行中的case不能靠文件存在算pass。 |

## N1 [P1] SC2 implementation：必需gate缺少完整输入/报告链仍能通过

`native-case-v5.mjs:170` 对fsm、continuation、linked、lifecycle仅搜索任一零findings的checker-finish。`:171`只对lifecycle要求initialize/dispose observations；`:172`只验证**仍列在日志中的**快照。代码没有要求每个必要job有对应checker-start、输入快照、完整checker-report及finish，没有交叉核对各gate检查的产物digest就是最终被manifest接受的版本。

独立探针抽取当前实际 `verifyProcessEvidence` 函数，复制真实已通过的macOS-codex-empty原档；将checker-start绝对快照路径迁移到副本canonical路径，保持快照字节和digest不变。未调用编译/模型，未改原始档案。结果：

| 副本 | v5 verifier结果 |
| --- | --- |
| 完整真实档案正控 | accepted，41快照 |
| 删除全部checker-start（包括所有gate输入摘要/快照关联记录） | **accepted**，27快照 |
| 删除fsm/continuation/linked所有checker-report，只保留lifecycle report | **accepted**，41快照 |

因此已有missing-gate负控只证明“删掉某个finish”会拒绝，不能证明完整gate证据缺失会拒绝。精确来源仍是R3/SC4完整证据、standalone-compilation-8/10、verification-72以及TEST-METHOD“required compiler gates actually ran on accepted bytes”；未新增业务判据。

修订应要求每个必需job有有序start→完整report→finish，检查对应输入快照及hash与当次最终FSM/linked/entry及runtime身份一致。对有真实修复/重复检查的情况允许保留早先失败，但最终接受链必须对应最后接受版本；不能简单要求整个日志永远无失败。Source-aware producer check也应核对实际成功结果，不只存在一个事件名称。补上“缺start/缺report/旧输入gate覆盖新产物”的实质负控；不必增加等价改名样例。

这一问题不否定目前完整原档中确实存在的检查，只限制harness自动放行边界。历史已完成TC若原档保留完整，可由修订后的独立审计重查并显式记录旧harness执行/新审计版本；缺原始必要证据则不能靠补写事件追认。

## N2 [P1] SC4 收集证据：Windows codex empty缺失被引用快照

只读核验本次已收集的六份passed原档：macOS Codex empty/commonjs/esm-git、Linux Codex empty/commonjs、Windows Codex empty。六份harnessSHA及eventsSHA均与各自声明相符；前五份的41个已引用快照及manifest runtime文件hash均一致。Windows一份存在下列缺口：

- case：`TC-local-windows-codex-empty`
- attempt：`2026-11-17T19-46-27-616Z-199def74-5c61-4dae-b0f8-57e787e3e385`
- events.jsonl 的 `agent-target-revision` 引用 `agent-3a2b0ea9-24b7-423f-8aa2-246d179c08d0-flow.gears.opt1.md`
- expected SHA：`82533b3096db56aa59af707f4fc546a87d33ed2018ec3ab3253227b7940096bd`
- 当前收集workspace对应文件不存在；仅有另一个 `0016-after-flow.gears.opt1.md`，不能未经核对替代。

这里不推断编译时没有该文件：native verifier可能在原机成功读过，缺口可能发生在归档或运输。需要检查Windows原机工作目录及远端archive，重收集并逐hash复核。wrapper目前只核对result tuple和pass，未对传回后的archive再跑等价完整性审计，故transport success本身不足以关闭该问题。不得把当前缺件case当“完整可追溯证据通过”。其余五份本次只是归档一致性正面检查，并非独立正式执行验收。

## 其余证据边界

### 工具闭包身份

v5已独立约束PB/XState、两个SDK和实际native来源。compiler-owned TypeScript与Node typings仍由packed `verify-typescript.js:27–28/58`的createRequire解析，当前harness没有将两个实际解析根加入ownedPath/身份清单；树中缺失时祖先同名工具的回退仍应由安装闭包证据或新增来源断言排除。这一要求原已存在于standalone-compilation-3、delivery-acceptance-7及TEST-METHOD，不是本轮新增业务要求。现阶段不授予“所有compiler tools与完整registry closure均来自本prefix”的结论；若安装证据已独立证明，应明确和实际TC关联。

### 初次v5 put错误

`evidence/development/harness-v5-before-put-hoist`保留旧脚本及macOS-codex、Linux-codex、Windows-claude-glm三份exit1 transport，均在native-version调用后的`Cannot access put before initialization`停止。旧代码实为未hoist的const put，当前改为函数声明；当前line64在line124真实CLI之前，故不能把这三次当原生编译失败/成功。当前已成功case记录当前修正脚本摘要，旧错误未被覆盖成pass，这一处理边界正确。

### 网络环境

文档说明Linux仍运行原生Linux Node/SDK/native，仅通过loopback SSH转发Windows既有代理的HTTP字节并使用任务私有授权登录副本；这不是Windows代跑Linux，也不引入项目依赖。GLM代理绕过只在child env，候选源/冻结输入不变。它们属于host前提准备；SDK READY只证明该探针可用，不能代替真实CLI编译。网络配置值和凭据未在本报告读取或打印。后续执行记录应关联这份网络准备文档，保留实际host/代理profile标识与非秘密effective配置的可追溯性。

### blocked操作与history

本次已读全部六份`native-operation-04/*.stdout`：只有macOS-codex、Linux-claude-glm两份是`timeout must be 1 to 300 seconds`并有完整持久operation record；其余四份是`acceptance storage is busy or has an unreconciled interrupted write`，没有同等持久case record。应表述为六次blocked stdout、两次timeout持久receipt及四次存储忙拒绝，不能说六份都因300秒拒绝，也不能把pending/request重复算执行。

外部长任务完成后可如实history导入并由独立执行Reviewer复核；导入不能伪称operations.execute，不能覆盖原blocked或失败。这与v4报告一致。matrix-05运行中的其余TC、未完成Windows/GLM材料、未复核的source-head/registry/CI仍不得计为pass。

## 交付判断

本轮认可大部分修复及原设计来源，保留 **N1完整gate证据链** 与 **N2收集后Windows缺件** 为需修订/核对项。来源约束、当前原档复核和最终固定48坐标汇总应共同构成证据，不把 matcher 的full当执行pass。v5现有正面材料可以继续积累，但在上述问题关闭及不同fresh-context执行/history复核前，不批准整体交付。
