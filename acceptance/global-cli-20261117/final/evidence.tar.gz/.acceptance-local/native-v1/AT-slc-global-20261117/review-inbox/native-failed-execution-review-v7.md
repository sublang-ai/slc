# AT-slc-global-20261117 失败执行证据独立复核 v7

结论：**18份失败的证据均完整核验，18份均不能计为验收通过。**实际终止原因可独立归为GLM供应商配额环境问题：HTTP429、code1308、5小时使用上限。供应商文本中的重置时间均为 `2026-11-18 09:01:59`，文本没有声明时区；本报告不把这个字符串擅自换算成已确认UTC时间。

此结论是失败来源及证据完整性复核，不是把失败改成pass。冻结cohort04矩阵仍为30个post-check verified与18个quota阻塞；本轮不授予完整48项、公共发布、CI或合并通过。正式history导入及最终fresh-context执行review由root后续处理。

## 实现及输出

新增独立工具 `tools/audit-native-failures.mjs`。它仅使用本地只读文件API及stdout；没有write、spawn、模型调用、编译、网络或供应商访问，不修改产品、harness或任何raw evidence。可从其他Reviewer直接import其两个导出函数：

- `auditFailedNativeCase({root, caseId, indexEntry, evidenceDirectory?, toolchainFile?})`
- `auditNativeFailures(root, onlyCase?)`

命令（JSON输出写到Reviewer自己的目标文件）：

```sh
node tools/audit-native-failures.mjs --root /Users/boboyang/work/sublang.ai/slc-global-delivery-20261117
node tools/audit-native-failures.mjs --root /Users/boboyang/work/sublang.ai/slc-global-delivery-20261117 --case TC-local-linux-claude-glm-esm-git
```

当前机器可读输出为本目录 `native-failed-execution-audit-v7.json`；每case有原status/cause、独立环境原因、实际命令及时间、compiler/SDK/native/toolchain身份、Source和全部snapshot、到达/未到达阶段、没有accepted产物的确认、Windowscapture及逐文件路径/SHA。它明确返回`failure-evidence-verified`与`acceptancePassed:false`；顶层`auditStatus:complete`只表示失败证据审计完整，不表示编译成功。

输入索引为 `evidence/evidence-audit-05/index.json`，时间 `2026-11-17T20:50:51.494668+00:00`：固定48坐标齐全，notExecutedOrNotComplete为空，verified30、execution-failed18。工具对上述18份执行失败逐项核验；Windows明确使用native-complete-05完整副本，不以旧递归SFTP partial副本代替。

## 实际核验范围

1. 固定TC/OS/backend/父状态与native-configs-05一致；配置及v5 harness摘要匹配match-sc2-v5绑定；cohort04摘要和三包版本、CLI摘要、记录中的完整packed-file核验数量与tarball身份一致。
2. 实际Node+installed SLC CLI命令、cwd、原stdout/stderr摘要、非零退出、signal、wall start/end与monotonic elapsed保留；compile.json与raw result.compilation完全一致。
3. frozen Source字节和实际workspace/Source snapshot相同，全部失败期file-snapshot、Agent revision及到达gate的snapshot可读取且SHA相同；共核验 **263份snapshot**。记录未把写出的GEARS/FSM当作完整成功。
4. 每份只有一次真实cold invocation；invocation-start先于实际Agent readiness/calls；实际SDK/native与取得的安装树相同，真实Agent/model均为claude-code / glm-5.3，endpoint为授权GLM入口。执行到的phase构成真实pipeline前缀，前面phase为ok、最后phase为error；全部有start/return/耗时。
5. 每份pre-Agent invocation compiler identity与平台toolchain记录一致，Node均v25.5.0；工具真实解析根位于对应prefix。SLC0.23.0-rc.4、Cligent0.40.0-rc.2、Playbook19.1.0-rc.4；Claude Agent SDK0.3.326、实际native版本2.1.326；TypeScript6.0.3、@types/node25.9.9、Spex3.0.0。原生路径及runtime byte SHA均在每case机器记录保留。
6. code1308不能只在任意一段prose出现：必须同时由实际compiler stderr、最后失败phase诊断、失败invocation/attempt结果、该phase内实际Agent terminal error/done corroborate；重置文本一致。request ID与不相关Agent日志不复制到新报告。
7. raw compile仍非零，attempt.result及invocation-finish均ok:false、gates:null；没有canonical `.mjs`/historical `.ts`入口、accepted build-manifest、成功build history或entry lifecycle acceptance；父fixture及相关祖先before/after未改变。若存在accepted产物，本auditor会拒绝这种“失败”证据。
8. Windows7份失败逐一核验原生Nodecapture stdout、单gzip摘要、capture中的base64/file SHA及完整解压副本：**207个文件逐项一致，原机workspace与output-copy差异均0**。旧raw与partial保留，新complete仅作为完整采集来源。

这些都是原已确认R1/R3、SC2/SC4与TEST-METHOD的真实性/可追溯性要求，不增加业务执行或提交说明质量判据。

## 逐case结果

所有case前缀为 `TC-local-<OS>-claude-glm-<parent>`；完整ID及全部逐项证据在JSON中。

| OS | parent | 最后失败phase | 核验snapshot数 | 结论 |
| --- | --- | --- | --- | --- |
| linux | esm-git | gears2fsm | 22 | 配额阻塞，未通过 |
| linux | compatible-runtime | text2gears | 13 | 配额阻塞，未通过 |
| linux | conflicting-runtime | text2gears | 13 | 配额阻塞，未通过 |
| linux | missing-runtime | text2gears | 13 | 配额阻塞，未通过 |
| linux | ambient-types | text2gears | 13 | 配额阻塞，未通过 |
| linux | spaces-chinese | text2gears | 13 | 配额阻塞，未通过 |
| windows | commonjs | link | 33 | 配额阻塞，未通过 |
| windows | esm-git | text2gears | 13 | 配额阻塞，未通过 |
| windows | compatible-runtime | text2gears | 13 | 配额阻塞，未通过 |
| windows | missing-runtime | text2gears | 13 | 配额阻塞，未通过 |
| windows | conflicting-runtime | text2gears | 13 | 配额阻塞，未通过 |
| windows | ambient-types | text2gears | 13 | 配额阻塞，未通过 |
| windows | spaces-chinese | text2gears | 13 | 配额阻塞，未通过 |
| macos | compatible-runtime | text2gears | 13 | 配额阻塞，未通过 |
| macos | ambient-types | text2gears | 13 | 配额阻塞，未通过 |
| macos | conflicting-runtime | text2gears | 13 | 配额阻塞，未通过 |
| macos | missing-runtime | text2gears | 13 | 配额阻塞，未通过 |
| macos | spaces-chinese | text2gears | 13 | 配额阻塞，未通过 |

数量为macOS5、Linux6、Windows7。16份在text2gears失败；Linux esm-git已完成text2gears/optimize/prefix，gears2fsm调用被quota拒绝；Windows commonjs已完成前四phase，并留有两次fsm及一次continuation的零findings检查，最终link被quota拒绝。后两者的部分阶段成功不能升格成整次编译成功。其余未到达检查与entry lifecycle始终未算pass。

18份实际编译时间跨度为2026-11-17T20:19:17.943Z至20:50:48.279Z；这不是把每份时长相加得到的并发墙钟耗时。长调用和快速后续拒绝都保留原始elapsed，未把配额拒绝称为checker覆盖超限或流程不可达。

## 原分类错误保留及独立归因

18份rc4原attempt.result / invocation-finish均将cause记录为`artifact / compiler-diagnostic`。原字段、原stderr、index.execution-failed、exit1均未被修改或覆盖。本报告独立分类为`environment / provider-quota / 1308`，并对每case设置`classificationDiffersFromOriginal:true`。

这避免将供应商的真实配额上限误当作生成工作流缺陷。与此同时，rc4的诊断分类与verification-73规定的环境原因有偏差；**独立审计不能追认产品分类为正确，也不关闭这个产品诊断问题**。如果root修复并构建新候选，应按实际源码/包变化重新确定受影响证据，不能通过改raw cause或沿用旧compiler identity掩盖变化。

## 独立探针验证

在 `/tmp` 的证据副本上，使用本工具实际导出函数完成一个无改动正控和六项负控；未访问provider或改动原始文件。结果在 `native-failed-execution-audit-v7-probes.json`：

| 副本条件 | 结果 |
| --- | --- |
| 完整失败原档的无改动副本 | failure-evidence-verified，acceptancePassed:false |
| 删除实际Source snapshot | 拒绝：snapshot文件不存在 |
| 将stderr的1308改为1309，并同步compile.json/result中的stream摘要 | 拒绝：缺真实HTTP429/1308五小时上限证据 |
| 添加accepted manifest | 拒绝：失败cold run出现accepted产物 |
| 工具TypeScript root改成外部目录 | 拒绝：compiler工具不是安装树所有 |
| 实际agent-preflight SDK版本与取得版本不同 | 拒绝：实际SDK/native来源不符 |
| 删除实际Agent terminal quota事件，保留compiler/phase quota文字 | 拒绝：没有terminal Agent error佐证 |

## 后续fresh-context review使用方式

对成功30项继续使用v6后置check及其完整gate证据；对失败18项引用本报告和每case JSON、原stderr/attempt、对应toolchain及Windowsgzip。正式history应该分别保留verified success与environment quota阻塞；本audit的complete不得导入为SC2全面passed。若后续重试，需新cold工作目录、新执行记录和真实provider可用性，保留这些失败，不能补写原调用或未到达检查。此子任务没有触发重试。

本轮工具SHA256：`caadb1508a6d13631b235d3464c3f26772b5901894c78947cc977f03bfa3e427`。机器审计输出SHA256：`4d20b7855c3c8c6cd54b7ee2252a1033ba6f7fc725434ae70cec9a55e8e327ee`。探针记录SHA256：`657ec0132f83fc606cfead4f205d0ef1fd52d4aa73a573b40db64e1b12d600af`。
