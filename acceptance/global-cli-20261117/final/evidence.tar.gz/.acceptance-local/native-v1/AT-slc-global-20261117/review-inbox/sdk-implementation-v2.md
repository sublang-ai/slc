# Cligent SDK implementation review v2

Acceptance: AT-slc-global-20261117. Candidate version: 0.40.0-rc.1. Result: PASSED for this early implementation review, with the evidence boundaries below. This is not formal acceptance or permission to merge/publish without the remaining required gates.

No unresolved P1/P2 finding remains in the final files read for this review. Three issues identified during this round were corrected and read back before this opinion was finalized. Reviewer modified no product/spec/test files, installed no dependencies, ran no paid Agent calls, and performed no large downloads.

Project: /Users/boboyang/work/sublang.ai/cligent. HEAD remains committed specification baseline 0550600e989fc2f851b16ef055793f324a77311d, with the current uncommitted implementation and added release-source-guard.mjs. The hashes at the end identify the final files actually reviewed.

## V1 findings reconciled

1. Global/nested sibling-SDK expectations: FIXED. Global and nested installs now pass only the tarball, not separately requested SDKs. Expectations resolve SDK package roots from the installed Cligent context and the Codex wrapper from its SDK context. The executable-entry assertion compares the actual expected wrapper path; the independent native --version check compares the executable's reported version to the SDK-declared runtime version, avoiding the false assumption that wrapper and native binary share an SDK-root prefix. Ambient executable decoys, native checks, Node-floor runs and public exports remain exercised. Real receipts 0011–0019 show both layouts and their probes succeeding. Open ranges actually selected Claude 0.3.326 / Codex 0.169.0 and the probes permit honest untested classification.

2. Installed faults and printed repairs: FIXED for the evidenced candidate. Four real installed-tree faults cover each included SDK and each native package. The installed launcher refuses with status 1, names the missing SDK/native component, and creates no session. Its actual printed argv is extracted and executed without harness-added target/scope flags. It explicitly targets the installed Cligent package root in project scope and supplies both descriptor repair specs with --omit=dev --save-prod --no-save, so the duplicate development pins neither omit the selected SDK nor prune its peer stack. The manifest is compared unchanged. The installed launcher then succeeds and creates a session under the stub harness. All four fault JSON files record failure 1 / repaired 0; command receipts 0022, 0023, 0025 and 0026 record the corresponding unchanged argv and successful npm execution. The SDK-root ownership assertion and generated configuration retain both adapters. This is materially stronger than the former injected-loader fixtures.

3. Production dependency audit: FIXED. The repository audit still reflects npm's duplicate dev-pin metadata and is not falsely treated as sufficient production proof. A separate empty production consumer installs the tarball with --omit=dev, verifies both SDK roots and audits that installed graph. Receipt 0005 records 116 packages installed; 0006 records zero vulnerabilities with dev:0 and the actual production/optional/peer graph. The separate full repository graph audit remains, also zero findings (0002). Exact development conformance pins were retained.

4. pnpm override loss: FIXED. The four original lockfile overrides are present again; all three relevant matcher consumers resolve minimatch 11.0.3. The current lock change places SDKs in the runtime importer and does not retain the unintended minimatch 10.2.6 downgrade. This review did not install with pnpm; it verifies the restored declarations and lock resolution, not a pnpm 11 install claim.

5. Public installation contract: FIXED in final reviewed sources. README, docs/guide.md and docs/tmux-play.md now distinguish included Claude/Codex stacks from optional OpenCode and external CLIs, and remove directions to separately install Claude/Codex SDKs globally. Credentials remain separate. Historical release evidence files were not rewritten.

The package manifest has exactly the intended ownership: two ordinary non-optional SDK dependencies, only OpenCode as optional peer, existing open runtime ranges, and independent exact development targets. Runtime descriptor compatibility values are unchanged. The legacy peer kind was clarified rather than replaced with a new compatibility authority. Existing optional/bundled-dependency guards, protocol checks, declaration-consumer checks, Node import/help floor checks, target alignment, decoy isolation and both audit roles were retained.

## Findings corrected during this v2 review

- P1 candidate-source guard: the first implementation required the workflow run's pull_requests array to contain the PR number. Read-only GitHub API observations showed this field empty in this repository's successful pull_request runs, including run 43705166460 at e249b3dec326c17148bd6ccb7c0d8adbb2a47642; the original predicate rejected that otherwise matching payload shape. Final code first validates the open same-repository PR targeting main at the exact tag SHA, then requires matching CI workflow event, head repository, SHA and branch. It only enforces a run-level PR number when that optional linkage is populated. The corrected empty-array case and wrong-identity cases passed direct reviewer assertions. No real candidate publisher failure is claimed.
- P2 inaccurate SDK tree note: final readiness.ts no longer claims SDKs resolve from the outer global node_modules root. It accurately names the running package root and anchors lookup to that package; concrete repair argv identifies its target. Optional-peer unreachability remains distinct. This changes diagnosis wording, not the already-proven production repair flags.
- P2 stale shipped guides: docs/guide.md:15–27 and docs/tmux-play.md:20–23 initially retained the optional-peer/manual-global-install story after README was fixed. Both were corrected and read back. Their final content is newer than the archived distributable2 tarball.

The diagnostic wording correction initially broke an old exact-string test at readiness.test.ts:384. /tmp/cligent-final-focused.log truthfully records that failure. The assertion was aligned to the accurate optional-peer wording and /tmp/cligent-final-focused2.log records all 100 targeted tests passing. The older green full-suite result is not substituted for this newer targeted run.

## Release lane and stable boundary

No remaining obvious candidate-publication blocker or stable-lane weakening was found in the final source. The guard accepts only a matching valid stable or rc.N tag/version. Candidates require an open same-repository PR targeting main at the tag's exact source SHA, and successful CI for that identity; a different repo, SHA, branch, event or explicitly conflicting PR association is rejected. Newer failed/pending matching CI is not bypassed by older success.

Stable releases still require a successful push CI run on main for the exact tagged commit. Stable versions still audit their matching preparation record; the rc-only test context audits the prior real stable record instead of inventing a completed stable preparation for an unmerged candidate. Full checkout history/tags, clean build, package checks, lint, default suite, release notes, OIDC provenance and public scoped access remain before publication. Candidates explicitly publish to rc-global-cli and create a prerelease; stable publication uses latest. No static npm token was introduced. The new pull-requests:read permission supports the read-only source gate.

Reviewer executed lightweight, read-only guard assertions for valid/invalid release identities, rc/latest separation, closed/fork/old-head/wrong-base PR refusal, empty run-level PR linkage, wrong SHA/repository/branch/event/PR, failed/in-progress/latest-run behavior, and stable-main-only behavior. These passed. This checks predicates and source structure; it is not a real OIDC or registry publication.

## Evidence and verification limits

Evidence root: /Users/boboyang/work/sublang.ai/slc-global-delivery-20261117/evidence/development/cligent-rc-distributable/.

- /tmp/cligent-rc-distributable2.log reports full verifier success. All 26 archived command receipts were read and have status 0; all four actual fault JSON files were read and contain refusal and repaired results.
- /tmp/cligent-rc-tests-final.log contains 87 files / 2353 tests passed. This completes the full run that was still in progress at handoff, but predates the final wording/guide changes.
- /tmp/cligent-final-focused2.log contains 3 files / 100 tests passed after the wording/assertion update. /tmp/cligent-final-prepush2.log reports spec lint and prepush clean; lint2 has no error. Reviewer also ran no-emit typechecking and diff checking successfully.
- The distributable2 tarball predates the final diagnosis/guide edits and latest source guard correction. Its manifest and README match the reviewed candidate, and its real fault receipts prove the same repair mechanism; it does not prove the later final package bytes or final source-guard publisher execution. Repack/reverify the final immutable candidate and retain that linkage before claiming same-version delivery evidence.
- The harness stubs tmux and glow. This is appropriate debugging evidence for installed readiness/repair and session-command ordering; it is not real-glow formal acceptance.
- Shared npm cache reuse does not invalidate fresh installed-tree/layout checks, but is not cold-download proof. The precise cache choice is not embedded in command receipts; preserve invocation metadata with formal evidence.
- No branch-prerelease registry installation, OIDC publication, Linux/native Windows install, real owner-authenticated Codex call, Claude/GLM call or complete SLC compilation matrix is established by this opinion. Those remain separate acceptance/publication evidence requirements, not inferred failures of this SDK revision. The separate spex-playbook Skill remains outside scope.

## Reviewed file identities

Distributable2 tarball SHA-256: 0c3477f1c8f53ea93f7ce209a54552dbc210bc2a6f87086432b7448693d2b240

- package.json: 7c31501fb922074c7a2525a7bd1257168b490d9cc843d1b2c1d69e0df5f04953
- package-lock.json: 20ae49a03ecd1040fdb28b63cd91be205ae63058600e1b62b2896cb0581447ab
- pnpm-lock.yaml: 8bc6326be53b237d3d16aa909abf5c68bd6a37b1e44bf1f8fc5af0449e810e5f
- README.md: 910e31964fb93a816227490d7428b69f191467beca111691a76b4e37e7335f4d
- docs/guide.md: 49d5870efa775146f1b2c904860b77c5e35980be335efa6b158eecc005430874
- docs/tmux-play.md: 60d0e257547cf9b91419d0f6dfddee160256fd38f4652ade69eb4d8f6cb72db1
- scripts/verify-agent-targets.mjs: a66ce5388f12e9457bb32462d5686ff84fd8b5fb8da5ee67c8188072aeb5b0dc
- scripts/verify-distributable.mjs: 8c365bc865417dd872914ccfc6f834810c6b0cafd5554d1540e705b2e4bc68a8
- scripts/release-source-guard.mjs: 15ae1a7883a58cd77ebd01fc9acf8f7227e98691dfa3b360b3660b07b5e8cf57
- .github/workflows/release.yml: cc52f1116f8c551699105aa12c898cb0759606741cb6cb059631d2ebbc8f058c
- src/app/tmux-play/readiness.ts: 1b04fd105a141c660bfd08033c74e01facac41f7e884aa2bf82443c936a1ff4e
- src/app/tmux-play/readiness.test.ts: 3d7970e185513f3eccad2fa115e6d40dbacd1bc013edadf9c1c2da3afc8ac5ea
- src/__tests__/release.test.ts: 2a256c49d82c9ea9ed552f4f827e8d02ee81a37f788f9c667d974f6e52d745f1
- src/runtime-targets.ts: 95cda14644b85be54bf131be04bd6f2af5dda29bbc4740d18f606045463bb88f
- specs/packages/tmux-play.md: 9df9f95233d743d8b2908f0ba2a85a76d6fca11cb1a4df4ff83957c2d189ba4b
