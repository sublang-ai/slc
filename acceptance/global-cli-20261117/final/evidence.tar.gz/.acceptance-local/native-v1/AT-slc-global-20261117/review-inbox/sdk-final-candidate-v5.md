# Final Cligent candidate SDK recovery review v5

Acceptance AT-slc-global-20261117. Scoped result: SDK RECOVERY PASSED — final 0.40.0-rc.2 package, four newly executed Linux component faults. This does not grant overall acceptance, CI, publication or merge approval. The existing full-development audit blocker is unchanged.

No product repository, user-authentication data or user configuration was modified. All installation, fault and sentinel writes were confined to the reviewer's separate scratch prefix. No paid Agent/provider call or unrelated CLI regression suite was run.

## Exact candidate and source boundary

- Source checkout HEAD read: b889811c5808bde863eef42f82c4364a8ce94bcb; clean at initial inspection. The committed helper's bytes were read with git show and match the package.
- Package: @sublang/cligent 0.40.0-rc.2.
- Supplied tarball: /Users/boboyang/work/sublang.ai/slc-global-delivery-20261117/evidence/alternative-branch-registry/sublang-cligent-0.40.0-rc.2.tgz.
- Actual tarball SHA-256: d826a46839b6257cebe349c16b9393a7fc3750a64f585828e73e9a786cf31fa3.
- Actual packaged, committed and installed helper SHA-256: 60b8cbb240ccccc4511e6fe41c9fc95e9d7991c4048759dffd2294645630137d.

All 263 packed file hashes match the @sublang/cligent entry in evidence/candidate-cohort-04/frozen-cohort.json. That JSON's sourceHead is still the historical base 395fa710c076c7ded49e3aee4cf94a08a43a3d9e, not the final b889811 commit. Its recorded working-tree source inventory SHA-256 94e06e1742fb7ad7527fe65118299fd4058321e1be6e4b761e06b1cc7f96fdf3 was independently compared with the final checkout: 405/406 files match, the sole difference is src/app/tmux-play/launcher.test.ts, and no tracked final file is missing from the inventory. No production-source difference was observed. Thus this opinion records the historical base-plus-working-tree inventory accurately instead of pretending the cohort header itself names b889811.

A complete packed-file comparison with v4 rc.1 found only package/package.json changed. Its raw-byte difference is solely 0.40.0-rc.1 to 0.40.0-rc.2. All 262 other packed files, including recovery, SDK adapters, runtime descriptors and readiness code, are identical.

## Actual execution environment and ordinary installation

The home-esxi-test Skill verified Ubuntu VM 75/codex-ubuntu identity. Execution used Linux x86_64 with exact portable Node22.23.4 and npm10.9.9 — the environment that reproduced the earlier Arborist failure. The normal tarball-only global-style installation used a fresh independent prefix containing spaces and Chinese text. Its actual argv/status/timestamps are retained in normal-install-command.json.

Only the final Cligent tarball was requested; no SDK or peer was manually added to the initial install. The ordinary ranges actually resolved:
- Claude Agent SDK 0.3.326: available and honestly untested against descriptor target 0.3.325.
- Codex SDK / its declared Codex runtime 0.169.0: available and honestly untested against target 0.159.1.

The initial manifest retained ordinary SDK ranges >=0.3.321 and >=0.159.1, exact independent development pins 0.3.325 and 0.159.1, and only OpenCode as optional SDK peer. Shared npm download cache /home/bobo/.npm was explicitly reused; fresh installed-tree proof is not mislabeled cold-network proof. Installation receipts retain the actual --ignore-scripts/--no-audit flags. These flags are not an audit result or security waiver.

## Four final-package fault recoveries — newly executed

For each row, moved the ACTUAL selected physical SDK or native package outside every selected dependency path. The actual installed configured-readiness gate rejected the selected adapter (configReady=false). Extracted its ACTUAL printed node/helper line, executed unchanged through /bin/sh -c, and re-ran real installed SDK/native and required-peer checks. No npm command was reconstructed and no extra target, SDK or scope argument was appended.

The readiness-gate rejection is the library implementation used by the installed launcher; this review does not pretend that it independently drove a real tmux/glow session. The recovery command and native binaries themselves were executed.

| Actual removed component | Start UTC | End UTC | Seconds | Helper exit |
| --- | --- | --- | ---: | ---: |
| codex native | 2026-11-17T20:14:19.768512+00:00 | 2026-11-17T20:14:42.518229+00:00 | 22.750 | 0 |
| codex sdk | 2026-11-17T20:14:44.123596+00:00 | 2026-11-17T20:15:09.402049+00:00 | 25.278 | 0 |
| claude native | 2026-11-17T20:15:10.974154+00:00 | 2026-11-17T20:15:41.106684+00:00 | 30.132 | 0 |
| claude sdk | 2026-11-17T20:15:42.779018+00:00 | 2026-11-17T20:16:13.882835+00:00 | 31.104 | 0 |

Common actual printed command:

    node '/home/bobo/sdk-linux-repair-review-YLeQlD/global-v5 rc2 空格/lib/node_modules/@sublang/cligent/bin/repair-included-runtimes.mjs'

Each individual command receipt retains exact argv, elapsed time, start/end timestamps, stdout and status. All four recovered the same selected path and left BOTH adapters/native locators available. The active recovery versions were the descriptor's Claude 0.3.325 and Codex 0.159.1; no floor or new independent version mapping was introduced.

Every required Claude peer was resolved from the physical installed SDK context, with no checkout or unrelated-global fallback: @anthropic-ai/sdk 1.9.0, @modelcontextprotocol/sdk 1.32.2, zod 4.6.6. Normal peer resolution and the explicit legacy=false policy remained active; this review did not use the rejected legacy-peer-deps bypass.

Independent credential-free native execution after all repairs returned 0 for Claude Code 2.1.325 and codex-cli 0.159.1.

## Preservation and actual package context

The installed package.json remained byte-identical after every recovery and at final inspection:
61cdb43d9b6264cea60599c40374f6c542d165006303a1a3df63181afb060ede

Consequently the version, runtime ranges, exports and independent development pins were preserved. Synthetic optional OpenCode SDK, unrelated host-package and custom .bin symlink sentinels retained their full file/mode/link digest after every repair. The sentinels prove preservation, not a fake OpenCode provider implementation. No repair-stage directory survived.

SDKs, selected runtimes and required peers were independently checked under this exact installed Cligent tree, rather than reading repository dependencies. No owner hidden lock existed before or after this global-layout run, and no stage hidden lock was imported. Pre-existing ancestor hidden-lock behavior in every nested/hoisted layout is not claimed by this case.

## Rollback evidence reused with an explicit byte boundary

Rollback injections were NOT repeated for rc.2. Historical v3 evidence exercised a late package-placement EACCES and a fresh post-merge readiness-child failure, proving exact restoration of 9,437 file/directory/mode/link records, the original manifest and no leftover stage.

That historical whole-helper hash is 5fdee2cd892b688370354c84bad9417bb8013c895fdd13c1692045663f0e4237. V4 added exactly two explicit legacy=false npm arguments; its complete helper hash equals this final package's 60b8cbb240ccccc4511e6fe41c9fc95e9d7991c4048759dffd2294645630137d. I independently compared the entire mutation/readiness/rollback suffix beginning with the original-manifest equality check. Its bytes are identical between the actually injected v3 code and final rc.2, SHA-256:
6f0aa71bb350c8203ebf30bab26327ed8de827bb78d8fa5332e454ca1cb671d4

That source-supported unchanged-block evidence is reused; it is not represented as a same-final-tarball rollback execution. The four component recoveries above ARE new final-tarball executions. See sdk-implementation-v3.md/v4.md and rollback-reuse-boundary.json for the full distinction.

## Remaining gates and scope

/tmp/cligent-frozen-full59.log was read and shows 87 files / 2353 tests passed. This reviewer did not rerun unrelated package/license/typecheck/CLI suites or adjudicate every other gate. The parent-reported cross-platform SLC-only installation/compilation results remain separate evidence, not inferred from these Cligent-only tests.

The full-development picomatch audit remains a known failed external gate. No audit criterion was changed, ignored or called passed; no CI/publication/merge approval is granted. The supplied candidate belongs to alternative branch-registry evidence, not an npmjs/OIDC publication. This review did not test public registry publication, native Windows recovery or real model authentication.

## Evidence

Raw final-package archive: /tmp/sdk-final-v5-review-lcQxIR/v5-review-evidence.tar.gz
Raw archive SHA-256: 78a6e22f179eb81db4b404b948b5f590fe6e5c79395153456f5e9d3446cae471
Extracted evidence: /tmp/sdk-final-v5-review-lcQxIR/v5-extracted/v5-evidence
Source/cohort and reuse checks: /tmp/sdk-final-v5-review-lcQxIR
Report: /Users/boboyang/work/sublang.ai/slc-global-delivery-20261117/.acceptance-local/native-v1/AT-slc-global-20261117/review-inbox/sdk-final-candidate-v5.md

The final handoff bundle combines this opinion, the raw archive, exact package/cohort identities, committed helper bytes and rollback reuse/difference proofs; it excludes large installed trees and Node binaries. Per-file hash indexes are included. All failed earlier experiments remain in their prior versioned review evidence rather than being relabeled final-candidate failures or successes.
