# Retained current-environment 验收方法复核 v1

结论：**这是一项成立且有针对性的“当前版本环境delta”方法，不能作为新模型生成证据。v1有一处必须补的历史产物身份锚点；root已确认采用v2独立目录修正，v2未读到实物前不在此报告中预批准。**不要求重做业务质量、付费Agent或所有故障场景交叉乘积。

本次只读四份脚本、48份retained配置、cohort12及一份已完成Mac样例；没有编辑产品/原档、没有调用Agent或运行编译。原48个cohort04冷生成记录继续保持30 verified、18 quota阻塞；这组retained不能把后者改成冷生成通过。当前另外6个commonjs×3OS×2Agent真正cold case与此方法分目录、分目的，进行中不计pass，也不被本方法替代。

## 当前版本及配置

cohort12实读SHA：`caa119f79235be47b82923f19c12a2cb85ea3d9f27277a731627016eae790c30`，包含SLC0.23.0-rc.11、Playbook19.1.0-rc.5、Cligent0.40.0-rc.2。48份formal retained-configs-12全部读入核对：3原生OS×2configured backend×8父状态，caseId/platform/backend/parent坐标一致，work和output各48个互异；历史输入各指向同OS/backend的cohort04 empty成功记录。没有把历史quota失败样例当作保留输入。

脚本使用原生Node/PowerShell或POSIX shell目标机执行实际安装CLI。case先建立父fixture，再新建空child并检查为空；随后明确复制历史已有产物并调用`slc playbook flow.md --complete`。这不是“编译时child只有Source”，也不是“从Source新生成”；初始空与准备后含retained bundle必须分开表述。复制的是以前编译器创建的私有artifact metadata，不是测试用户手写项目根manifest；child根仍禁止package/lock/tsconfig/node_modules/.git。

## 能证明什么

- 当前实际CLI/三包packed bytes、selectedPB/XState物理root、两个SDK根、选中native path/字节/实际--version都被检查来自当前安装prefix；编译前后复核三包内容、native字节与selectedpair不变。
- 当前public环境服务在不同父状态下准备workflow-owned环境和两runtime links，真实currentFSM/link/entry gate、真实initialize/dispose以及新manifest发布均被检查；父fixture树、直接链接目标包内容、祖先Node配置/Git状态保持原identity。
- v1内嵌检查明确拒绝agent-call、phase-start/return、agent-preflight；要求FSM/linked前后hash不变，Source仍为冻结SHA。独立后置checker要求`--complete`、zero Agent/phase，完整有序start/report/finish、必要输入快照及最终accepted文件hash，lifecycle有initialize/dispose观察。
- 当前toolchain记录通过platform/Node/compiler buildIdentity与实际invocation绑定，工具必须是安装树所拥有；独立entry JSON必须verified。transport校验caller/config/native result tuple，非零或收集失败不升为pass。

这组机制适合作为旧已认可工作流在当前安装、当前检查器/loader及不同父目录下仍可完成重验的环境delta证据。2个backend标签在这里代表当前配置选择及对应历史输入来源：因为不调用Agent，它们**不证明当前Codex或GLM的生成、provider网络/auth/quota均可用**。SDK/native根与--version也不等于实际provider phase成功。当前6个cold样例另负担实际新调用这一部分。

## v1最小必须修正：历史baseline不能在复制后自证

`native-retained-case-v1.mjs:113–118`只检查prior.status/platform/Source/caseId，随后从可变`prior.child`复制，复制后才给FSM/linked计算新baseline。若旧child早先已被改过，之后前后hash一致、当前gates通过，也可能被误称“原独立认可的旧代码未手改”。`check-retained-evidence.mjs:29–30`只迭代result自报retainedExecutables，连恰好两个canonical路径都未强制，空对象也不会检查历史来源。这个缺口直接关系本方法的承诺，补一个身份锚点即可，无需扩大生成矩阵。

root确认的v2方案是适当的最小修正：

1. 配置保存来自已独立review/history导入的旧result原字节SHA；native先核对VM上的prior receipt等于该独立SHA。
2. 从prior.gates.files按确切kind=FSM/linked取得两个原accepted SHA；复制前/后两文件必须与这些SHA一致，不能复制后自建baseline。
3. 原receipt bytes另存`retained-original-receipt.json`进本次archive，原记录不编辑。
4. 后置checker使用独立传入的expectedReceiptSHA，而非只信当前result自报；强制两个canonical路径、历史kind/hash，与原receipt bytes、result及当前workspace互相核对。
5. v2用新work/output/config路径，v1样例留作历史，不覆盖或换名追认。

这些修正可以后置补审已经完整保留且实际hash吻合的样例；不需要为了同一段确定未改的代码再付费生成。仍应在v2实际落盘后核对代码及最小正负控，不能只凭本计划认定v2已通过。

## 已完成Mac v1样例的实际边界

读取时`native-retained-12/formal-TC-local-macos-codex-commonjs/result.json`已为passed，CLI实际`playbook flow.md --complete`耗时4636ms。其events是12个file-snapshot、3组checker-start/report/finish、1 invocation-start/finish、1source-gears-check和1entry-lifecycle；没有Agent或生成phase，current gate jobs为fsm/linked/lifecycle。

我独立对照历史已认可的MacCodex-empty receipt：其原字节SHA等于retainedInput.historicalReceiptSHA256；FSM原accepted SHA `741fade2c09c4d1f8273dcc37f221b4cea48a44ab2af44d59d2291527bca521a`、linked原accepted SHA `46ac24d3897df980e5f4b48ae7297edf38f45c06967aa93a63150a425629786f` 均与当前样例retainedExecutables相同。因此**没有观察到这个样例实际被手改旧代码**；上节指出的是v1自动方法缺少拦截，而不是指控样例篡改。此样例也只属于retained complete，不是一次新的Codex冷生成。

## 两项轻量说明及执行边界

- 同prefix约束应从toolchain自报prefix进一步对应case当前CLI/installedSLC的真实prefix；相同buildIdentity字节可存在不同安装目录，不能仅凭自洽toolchain文件证明当前解析根。用一次路径对应断言解决，不需额外OS/Agent重复。
- v1仍会读取GLM私有token及Codex私有profile并设置环境，尽管没有Agent调用。若保留此准备流程，只能称“zeroAgent/phase0”，不能称“credential-free completion”；可以删去retained专用路径不必要的credential读取，避免凭据缺失造成和产品completion无关的阻塞，不需改用户真实登录文件或调用provider。

输出和汇总必须带`retained-current-gates`/new-model-generation=false等明确目的，避免复用TC-local坐标后误覆盖原cold记录。v1 checker沿用native-check schema及“Cold archive”错误文案，应至少在最终报告/机器结果层明确retained身份；计数分开即可，不要求新一套复杂状态系统。

Windows仍使用递归scp时可能再出现旧采集路径问题；后置checker对全部snapshot做hash会fail closed，不允许只看transport0/rawpassed。若实际遇到缺件，复用已存在的原生短gzip采集即可，不预先重开一个耗时全平台故障计划。

## 不授予的结论

这不是source-only全新生成、不是当前48次真实Coder/Reviewer模型phase，不证明业务工作流执行/输出质量；也不证明registry仅安装SLC的自动获取过程、公共发布、CI或merge。它不重写冻结SC2设计里的cold-generation含义，而是在用户当前“优先环境可交付，避免无必要耗时”方向下增加清晰分层的当前delta证据。v2锚点修正后，只要真实执行及后置完整性检查通过，这个有限目的成立，无需把所有历史场景立即重新付费生成。

复核输入脚本SHA256：

- `tools/native-retained-case-v1.mjs`：`3217061f76dc3da583e9456539add8640de539cd7c2c440b0896a2afb79953be`
- `tools/run-retained-native-v1.mjs`：`37f5389a458bd248da19495a9e3c959b412a6c2737a16ffb1ac4de221342f6d1`
- `tools/prepare-retained-matrix.py`：`21a1d819f6a55a69b1db934103269833f520aa93ac62e7dcf024896354b3142a`
- `tools/check-retained-evidence.mjs`：`f2627341b4a64537f68be8b883fe8fa95f629359f4563499b0dd5f9aa81c9a63`
