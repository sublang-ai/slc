# Real replay fixed v9 — scoped independent review

**限定源码复审 passed；本轮未保留 P1/P2。** 结论覆盖有限重复调用、实际reached-context interrupt、停滞Q调度和无guard入口payload读取修复；不授予尚未完成的全量回归、不可变最终候选、正式SC3全项、发布/CI或合并通过。

产品与原生成FSM均未由Reviewer编辑。只在/tmp冻结51个源模块、制作测试副本和独立探针，无付费Agent或产品build。当前实际源快照AkkWgU逐模块与live复算差异[]；身份与原始证据在同目录real-replay-fixed-v9-evidence。前期rc8/rc9红灯、旧dist source-suite结论和临时prototype严格保留各自范围。

## 实现和Spec核对

1. **真实有限循环**：去掉按node已访问身份硬禁的重复调用拒绝。prefix保留完整历史，每次推进仍需实际pending与node匹配、真实ordered结果完成后出现新的正确pending；非reenter同叶不会凭atState继续。原depth/attempt/duration、取消和actor清理仍在。Spec6允许的是这个有限真实重复，不是无界循环或把搜索耗尽改判artifact证明。
2. **实际中途interrupt**：CoveragePathStep记录真实公开event、root armIndex和声明target，固定当前真实context解payload。重放不complete当前actor造结果，改expected后send原事件，要求新增root微步、相同事件对象/arm/target以及正确新pending。leaf shadow、同状态无微步和错误ordered arm不能替代实际证据。
3. **Q调度**：questionProgressSnapshot只作priority hint，不用来丢path/合并context。与上次同target Q前snapshot相同的普通data上下文转FIFO，有变化或不支持比较仍保留优先。所有candidate/root-family预算原样收费；解决了“qdefer一律降级”破坏两次问答priority正控的问题。
4. **安全快照**：先utilTypes.isProxy再读取prototype/own descriptors；仅普通Object/null/Array，拒绝accessor/symbol/custom/function/cycle和超depth8/128visits/文本64KiB，复制data descriptor与共享非循环alias。不会调用用户getter/toJSON。比较值只是调度启发式，不声称任意actor历史/模块闭包状态等价。
5. **无guard公开入口**：只对无guard、有action、原guard未发现payload变量的entry增加一次真实stopped actor观察；event Proxy记录实际读取的缺失顶层字段，超过4个则不支持。仍在同一个probe counter中逐字段给有限值，原ordered guard验收、后续实际concrete event完整重放才可证明；没有从函数源码猜context key或回填actor snapshot。
6. **源码/spec同步**：Spec6/11移除旧“仅Q可重复”和“恢复合成context”冲突，加入实际调用/真实interrupt/有界进展调度及action读取字段的窄例外；Spec62上限与耗尽分类不变。selected64/1024不改变默认8/64/300000，也不是无限开关。

## 当前搜索范围的明确限制

当前额外interrupt successor只枚举**直接进入当前audited target**的root arms，普通结果前驱仍保留；并不枚举任意中间节点的所有公开事件序列。该选择降低分支爆炸，但需要先interrupt到别的中间节点再进入target的更一般路线仍可能未被发现。只可返回unverified/耗尽，不能据此判Source不可能；本意见不声称任意有界公开事件程序都已完备支持。Spec已有“无穷尽可达保证”边界，正式结果应继续明确此处。

无guard action读取目前仅支持实际get读取的最多4个缺失顶层payload字段，按一个字段一个字段生成；has-only检查、需要多字段联合取值、额外getter/proxy/custom数据都没有被本轮授予完备支持。未支持时不制造context或放松原guard。

## 独立实际执行

### 原维护FSM

使用原EN/ZH FSM的独立源码转译，不改原文件，checkFsmCoverage带artifactSchema3、sourceText及64invocations/1024attempts/900000ms：两者均findings=[]，分别383ms和462ms。脚本与JSON已保存。

主流程实际Node CLI开发收据也已读取：rc9-v2为EN失败/ZH通过；rc9-v3为EN、ZH均exit0且inputsUnchanged；rc9-v4的12/256两者仍按原budget真实失败。这些是可变开发dist的执行记录，不冒称已冻结最终包字节；所报version字符串rc9不足以把多个开发迭代视为同一不可变候选。

因此对维护demo显式使用足够的受支持预算有实际依据。必须保留实际CLI完成、emitted/独立runtime和原Source/GEARS/FSM字节断言，不得手改原FSM、降低正确性断言或把12/256红灯删掉。当前默认预算不承诺这些较大维护demo均可完成。

### 完整相关kernel与补测

临时测试副本导入同一冻结dist；首轮三个文件：standalone-witness18项全过、verify-coverage273项、coverage-budget50项，共**337pass/4fail（341），无skip**，真实exit1和原始JSON/log保留。

四个红分别是：两个dead later child onDone/onError仍拒绝但旧测试copy断言文案不符；portable emitted suite缺本Reviewer临时snapshot的.d.ts；DEV emitted suite的临时路径仍指不存在的snapshot/src。没有把这些笼统说成产品回归，也没有抹去首轮失败。

随后仅在/tmp补齐当前build的声明文件、将临时DEV绝对引用改为同一冻结dist，并采用live最新两项负控regex；只重跑四项，**4pass/0fail、319按选择器过滤**。两项新regex仍要求具体dead arm的unverified/exhausted拒绝，不删除负控。不能把这写成“一次341全绿”；完整候选的全量单次input-bound结果仍由主流程提供。

测试实际覆盖：两次真实counter自重入、无进展/死START/非reenter负控、reached interrupt counter2正负控、guard-free payload读取正控、absolute-path真实前驱/interrupt及private witness拒绝、target-local branchingPrefix+successive2reply、unreachable final/no-root微步、reference、child结果和层级初始化、预算传播/有限深度/attempts/deadline/cancel/actor清理、真实producer/consumer及emitted套件。没有仅凭测试名或聚合数字给未写的SC3条件通过。

### 快照辅助函数独立探针

在仅追加private helper export的/tmp副本上执行12项：普通copy独立且deep equal；accessor、Proxy、cycle、symbol、function、custom对象、超字符串/深度/visits均保守unsupported；共享非循环alias与冻结descriptor保留。getterReads=0，proxyTraps=0。探针只验证新helper的无用户代码读取边界，不把private export加入产品API。

## 已关闭与后续

原false-positive的合成context/私有snapshot已关闭，实际有限循环和public interrupt经普通actor得到的counter前驱可贡献证明。原维护demo剩余false-negative已在当前足够预算源码/CLI开发对照中关闭。旧qdefer导致branchingPrefix两次问答回归的临时红灯已被progress-priority替代方案保留并复测；它没有成为产品断言放宽。

尚未授予：最终单次完整SLC regression、所有生产typecheck/build/pack与最终依赖图/冻结输入、原生三平台候选检查、受影响旧冷生成证据复用裁决、公共registry发布/CI和merge。后续代码/依赖变化依影响范围重新审，不把此源码意见升级为正式交付结果。

记录UTC：2026-11-17T23:12:05.395299+00:00。

当前源/测试/规范摘要：

- `slc/src/verify-coverage.ts`: `0b9581a4b0566e2d30bb8ebc3f95651d415f6dd93c052b95865638da22c8a0f8`
- `slc/specs/packages/verification.md`: `c04114983ff4f5fb0791d5ef3f93f7c4592ad274477d37d918cb824c1e09138d`
- `slc/test/standalone-witness.test.ts`: `c94f80b645c6251068a950dd4c69062999d3f75b1de2d8fe7e925f5599e502ef`
- `slc/test/verify-coverage.test.ts`: `3dc0d1f95f7991ac822ca5fbcf336a1b78ff9104ccc3083962ab8ccfe6e97982`
- `slc/test/coverage-budget.test.ts`: `76e0f38364378659fb89a525ccb78159cc53f00b6d0d4c219586a5cf10b92202`
- `slc/test/completion.test.ts`: `5bb5f4f1d4065feb863054882353489fa72b0ac26e16348e06a0d10696e02866`
- `slc/demo/reference/workflow.playbook/workflow.fsm.ts`: `9a85555fa8ff56c04b69c0937dfca7a738dc7ff3cf4ef9cd5fb7467ab77accf0`
- `slc/demo/reference/workflow.zh.playbook/workflow.zh.fsm.ts`: `5670cac974fae8d9936cd1cb1d9301665f60e310df0b4b9d7c3ff19693fd6787`
