# Cligent recovery helper review v4 — inherited npm configuration

Acceptance AT-slc-global-20261117. Result: PASSED for the affected P2 correction and this early implementation-review scope. No unresolved P1/P2 remains from v3. This is not formal acceptance or permission to merge/publish.

## Exact package and difference

Cligent 0.40.0-rc.1, tarball SHA-256 3af03f22b6a62728e53c1f59ce17454792361ccb61bec940d6bfb7310097029b; helper SHA-256 60b8cbb240ccccc4511e6fe41c9fc95e9d7991c4048759dffd2294645630137d.

I compared every file in this tarball with frozen v3 tarball 33954e49b0cf17366bd497c3300cc9b7eb32493ae714815977767901a9f9ad8b. Only bin/repair-included-runtimes.mjs changed. Its entire text difference consists of adding --legacy-peer-deps=false once to npm install and once to npm ls. The package replacement, validation, backup and rollback implementation is unchanged. Comparison retained at /tmp/sdk-helper-v3-review-gVbag8/v3-to-v4-helper.diff.

## Actual affected-environment test

On the verified Ubuntu VM using exact Linux x86_64 Node22.23.4/npm10.9.9, I created a NEW global prefix with spaces and Chinese characters and installed only the v4 tarball. No repository or user-auth/config file was changed. Shared npm download cache /home/bobo/.npm was explicitly reused; this is not cold-network proof.

The initial normal SDK/native tree was available. I added a synthetic optional OpenCode sentinel, an unrelated host sentinel and its custom .bin symlink, then moved the actual selected Codex native package and BOTH required Claude peer packages outside the resolution paths. The installed readiness gate refused the damaged configuration.

With npm_config_legacy_peer_deps=true inherited by the repair process, I executed its ACTUAL printed node/helper shell command unchanged. It exited 0 in 23.869s. Both SDK/native adapters became available from the real owner tree; the active versions were the descriptor-tested Claude 0.3.325 / Codex 0.159.1. All required peers resolved from that SDK's own installed context:
- @anthropic-ai/sdk 1.9.0, satisfying >=0.93.0;
- @modelcontextprotocol/sdk 1.32.2, satisfying ^1.29.0;
- zod 4.6.6, satisfying ^4.0.0.

Both npm subprocess debug records explicitly show normalized --legacy-peer-deps false despite the inherited true value, confirming the override is applied to installation AND validation. npm normalizes the equals-form option into two debug tokens; this was read directly rather than inferred from source.

The installed package.json remained byte-identical, SHA-256 509794c1ef66dd674c1ee0278b5bcf0f1e5f4fc578cc86eeea12b02adb6362d2. Runtime ranges and exact independent development targets remained unchanged. Optional/host sentinel bytes and .bin link were unchanged; no repair stage remained. Independent local native --version execution exited 0 for Claude Code 2.1.325 and codex-cli 0.159.1. No model/provider request was made.

Evidence: v4 summary.json, before/fault/after SDK and peer probes, actual shell command receipt, full helper log, both npm debug records, native-version-execution.json and v4-independent-checks.json.

## Coverage carried from v3, not rerun under the v4 hash

The v3 record proved all four actual SDK/native faults, required peer completeness, unrelated optional/host/.bin preservation, unchanged manifest and two exception-driven rollback paths (late readiness failure and late package-rename EACCES). The complete file/mode/link tree matched before/after rollback. Those raw receipts REMAIN IDENTIFIED WITH THE V3 HASH; I did not rerun all four faults or both rollback injections under the v4 package.

Carrying that implementation coverage is justified by the complete packed-file and source comparison: only two explicit npm-option overrides changed, and those options are false by default in the v3 tested environment. The affected inherited-true branch was actually rerun here on v4. This is an explicit review inference over unchanged code, not a fabricated same-hash execution claim.

See sdk-implementation-v3.md for the full v3 history, including its safely rejected legacy=true case. That v3 P2 is closed by this v4 execution. The earlier test-harness setup errors were before product-helper invocation and remain separately retained.

## Remaining limits

The helper itself performs no audit bypass or changes to ordinary SLC installation. The full-development picomatch audit finding remains an external failed gate; it is not marked passed by this recovery result. Production audit, candidate-registry proof, OIDC and eventual merge remain independently gated. No publication or merge was performed here.

Global-layout hidden-lock behavior was checked in v3: no owner hidden lock was imported and npm loadActual read the real new versions. A pre-existing ancestor hidden lock in every nested/hoisted consumer is not covered. Native Windows npm discovery/rename behavior, forced process death/concurrent repair, real provider authentication and the complete SLC compilation matrix are not established by these tests.

## Evidence identities

V4 archive: /tmp/sdk-helper-v3-review-gVbag8/v4-review-evidence.tar.gz
V4 archive SHA-256: 202d5152e91703fdde0aae75378b97b0d0affeb7f0b07fe08723289088c38eb0
V4 extracted evidence: /tmp/sdk-helper-v3-review-gVbag8/v4-extracted/v4-evidence
V3 archive: /tmp/sdk-helper-v3-review-gVbag8/v3-review-evidence.tar.gz
V3 archive SHA-256: 6c553b4fb2fdc49a99ec01a286db704ad04c80f500fb99ed82e19f375e5a58d7
Per-file SHA-256 indexes are inside both archives. Temporary VM data remains isolated for authorized follow-up; large installed trees and Node binaries are excluded from the archives.
