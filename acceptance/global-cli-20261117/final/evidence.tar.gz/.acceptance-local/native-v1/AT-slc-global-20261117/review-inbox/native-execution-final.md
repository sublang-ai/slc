# Independent final review of native history-import-05

Conclusion: **30 historical local cold compilations passed; 18 remain insufficient_evidence because the actual GLM provider rejected compilation requests for quota.** These are 48 externally executed observations imported through `history`, not `operations.execute` runs and not a final-candidate matrix approval. All 48 requested per-target opinion files are present at the exact paths in `evidence/history-import-05/review-targets.json`; every opinion has `covers: []` because the imported history results declare no obligations and retain unknown formal coverage.

The reviewed producing cohort is exactly **@sublang/slc 0.23.0-rc.4 / @sublang/playbook 19.1.0-rc.4 / @sublang/cligent 0.40.0-rc.2**, frozen cohort SHA256 `d98865e1b2463092844cbcafd454209a37941b2f94639ad690bd27c49fae56b2`. This review cannot be transferred to rc6 or another current source/package identity. Native runs selected XState **5.33.4**, Node **25.5.0**, TypeScript **6.0.3**, @types/node **25.9.9**, and @sublang/spex **3.0.0**. Both acquired SDK identities are recorded: @openai/codex-sdk **0.169.0**, @anthropic-ai/claude-agent-sdk **0.3.326**. Actual configured backends were Codex **gpt-6.1-sol** with native **codex-cli 0.169.0**, and Claude Code **2.1.326** using **GLM glm-5.3** through the authorized GLM endpoint; the latter is not an Anthropic-model result.

| Native platform / backend | Historical passed | Insufficient evidence |
| --- | ---: | ---: |
| Linux 6.8.0-149-generic x64 / Codex | 8 | 0 |
| Linux 6.8.0-149-generic x64 / Claude Code + GLM | 2 | 6 |
| Darwin 24.3.0 arm64 / Codex | 8 | 0 |
| Darwin 24.3.0 arm64 / Claude Code + GLM | 3 | 5 |
| Windows 10.0.26100 x64 / Codex | 8 | 0 |
| Windows 10.0.26100 x64 / Claude Code + GLM | 1 | 7 |
| Total | 30 | 18 |

## Inputs and independent work

Read the project conventions, SLC delivery-acceptance, standalone-compilation and verification specifications, and Playbook artifact-environment specification. Anchored SC2 to frozen definition `definitions/000001.json` SHA256 `15e40cc1436119f3fbc6949406b2b048d93d1b3265aecb437b28684875f34d33`, current case design `design-sc2-v2`, registered `match-sc2-v5`, and the scoped harness/evidence conclusions in `native-design-v6.md`. The frozen workflow bytes are SHA256 `af0a67466cfb4d5efb79caee263ee433ebc6a9fc7090cd6fbb071a1a998ab969`.

Independently checked all 48 exact target receipt digests and all **3,690 imported artifact references**, plus declared execution-input and attachment digests. Associated each imported history execution with its actual compile receipt, argv, timestamps, elapsed time, exit code, raw streams, native result, source snapshot, frozen config, bound harness/wrapper, producing package cohort and imported toolchain record. This is not an inference from harness status or the previously authored audit index.

Read the actual imported invocation logs and verified native/backend/model coordinates, one cold invocation per child, executed phase records, actual Agent calls and available acquired native adapter/SDK provenance. Independently checked every parent-fixture byte map: CommonJS/ESM declarations, missing dependencies, deliberate conflicting runtimes, unrelated broken typings/tsconfig, distinct physical compatible runtime copies, empty-parent state, Git ancestry and Chinese/spaced child paths. Parent inventories and ancestor metadata before/after agree in all 48 observations.

Directly reran the exported read-only `checkNativeEvidence` against each of the **30 imported original success archives**, using that archive's imported native toolchain record. All 30 verified: **41 captured snapshots and 6 completed checker chains per case**, with final fsm/continuation/linked/lifecycle successful input snapshots tied to the final accepted manifest/file hashes. Lifecycle reports include actual passed initialize and dispose. The separate native entry-check JSON is verified with zero findings, private ESM metadata and recorded selected links agree, and the child root has no user project/Git prerequisite. Compiler tool roots are under the acquired installation, and their recorded compiler build identity agrees with invocation-start: `1a6ae516828616e121375056f2f97262e93cb4697ff9eb69aec003071258530e`.

The postcheck source is SHA256 `b2d8f726c77ae48692368a41a2f11690e211578e12e5c47791ec8165df3e6a31`; recomputed results agree with the imported success-evidence-audit records, including final gate input/event positions, snapshot counts, event/manifest/toolchain digests. Full successful pipeline prefixes and Source-to-GEARS records are retained; business execution remains false. Native Windows originals were additionally compared file by file against the complete native capture/gzip and its receipt digest, requiring zero collection comparisons. Old partial `native-05` Windows evidence was not substituted for the complete archives or modified.

Directly reran `auditFailedNativeCase` against each of the **18 imported original failures**, using imported toolchain records and the registered frozen configuration. All 18 failure archives verified; the independently recomputed conclusions agree with `native-failed-execution-audit-v7.json`. Failure auditor source SHA256 is `caadb1508a6d13631b235d3464c3f26772b5901894c78947cc977f03bfa3e427`. Actual process stderr, terminal Agent event, final failed phase-return and failed invocation diagnostics consistently record HTTP **429**, provider **1308**, and the five-hour usage limit. The provider's reset literal is retained in the per-case reasons without inventing a timezone. This supports an **environment/provider-quota block**, not a demonstrated product defect; the original compiler classification and raw execution-failed records remain unedited.

## Remaining unsuccessful scope

All 24 Codex coordinates passed historically. Claude Code/GLM passed only Linux empty/commonjs; macOS empty/commonjs/esm-git; Windows empty. The remaining GLM coordinates are still unsuccessful:

- Linux esm-git completed text2gears, optimize and prefix, then failed gears2fsm; no checker job or accepted lifecycle/entry/manifest was reached. Its 22 snapshots were independently verified.
- Windows commonjs completed through gears2fsm, including two FSM checks and one continuation check with no findings, then failed link. Linked/lifecycle acceptance, entry and manifest were not reached; 33 snapshots were verified.
- The other 16 failed during text2gears, before any checker job: Linux compatible-runtime/conflicting-runtime/missing-runtime/ambient-types/spaces-chinese; macOS compatible-runtime/conflicting-runtime/missing-runtime/ambient-types/spaces-chinese; Windows esm-git/compatible-runtime/conflicting-runtime/missing-runtime/ambient-types/spaces-chinese. Each has 13 verified snapshots. A phase may spend time retrying before the terminal quota failure; duration does not make it successful.

No failed cold run has an accepted entry, build-manifest, accepted build history or lifecycle acceptance. Their preserved partial outputs are evidence of only the phases/checks actually reached. Their evidence is sufficient to classify the observed failure, but insufficient to approve the required successful full cold compilation, hence `insufficient_evidence` rather than `passed`.

The reviewed successful history is limited to these exact installed rc4 local production packages and this frozen workflow. This does **not** close the complete 48-coordinate SC2 success requirement, prove rc6/current formal execution, prove registry-only single-package acquisition, approve SC1/SC3/SC4 or CI/PR merge, or score business-workflow execution/output quality. No new compilation, model/provider request or business execution was made during this review. Changes made by this reviewer are confined to the 48 assigned opinion JSON files and this summary.
