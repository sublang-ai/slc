# Compiler implementation review v1

- 验收 ID：AT-slc-global-20261117；本文件是早期实现复核，不是正式交付验收，不授予平台或真实 Agent 编译通过结论。
- 独立 Reviewer：`/root/slc_impl_review`，新上下文接收路径和范围后独立读取源码、specs 和项目 AGENTS.md；未修改产品代码或规格，仅在临时目录制作复现和写本意见。
- 范围：SLC managed compilation、isolated checker/worker、runner、entry emission、coverage witnesses，以及 Playbook artifact environment、fresh loader 和 host provisioning。对照 `standalone-compilation`、`verification`、`incremental-compilation`、`delivery-acceptance`、`artifact-environment` 当前 specs。
- 方法：静态调用链审查及本机 Node v25.5.0 的小型真实模块加载复现；未启动付费 Agent，未运行完整大测试，未替代 macOS/Linux/native-Windows 的正式矩阵。
- 结论：**needs_revision**。当前仍有下列 3 项可操作问题。复核期间主 Agent 持续修订同一工作区；末尾列出本次最终读取的源码摘要，后续改动需重新判断受影响发现。

## F1 · P1：运行文件清单遗漏 CommonJS require 依赖，实际代码变化仍获身份校验通过

位置：`slc/src/managed-compilation.ts:149-160`，以及 `playbook/src/artifact-environment.ts:283-294`。

`runtimeFiles()` 只识别 import/export/import()，不识别 `require('./helper.cjs')`；manifest validator 只核对清单已有记录，没有从实际 entry/FSM/linked/support 重建或校验完整运行闭包。因此正常可加载的 `entry.mjs -> linked.ts -> support.cjs -> require('./helper.cjs')` 会遗漏最后的 helper，修改该文件不会导致 runtime identity 失配。也未对清单中 entry/FSM/linked 的具体路径和实际导入目标建立闭包约束，只有 kind 的存在性。

实际复现：`/tmp/slc-review-probe.mjs`。用真实 managedCompilation 环境准备、真实 isolated lifecycle、manifest publication/validation 和 Playbook fresh import；回调仅提供确定性生成文件，无 Agent。首次通过，manifest files 为 `flow.playbook.ts, support.cjs, flow.fsm.ts, ../flow.mjs`，缺少 `helper.cjs`；将 helper 从 `module.exports = 1` 改成 `module.exports = 999` 后，`validateArtifactManifest(entry)` 仍成功，`importFreshArtifact(entry).default.id` 实际为 `999`。本次产物在 `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-review-r7fFMT/`。该脚本首次运行是在 finalize 重构前；与本发现有关的 runtimeFiles 正则和 validator 闭包行为在最终读取时仍保持上述实现。

依据：`standalone-compilation-5/-6`、`artifact-environment-5` 要求完整运行支持闭包及变化拒绝，并明确 CommonJS 的新鲜加载责任。

建议：用能正确区分代码、注释和类型边的解析/模块解析机制收集本地运行依赖，包含允许的 CommonJS require；manifest 校验同时证明每个实际可执行入口及其本地闭包均在受检文件集，无法静态证明的依赖应明确拒绝或采用可审计的声明契约。至少补真实 CJS 两级依赖的变更/越界拒绝集成场景。

## F2 · P2：派生验证产物仍从父进程旧传递模块生成

位置：`slc/src/runner.ts:1008-1022`、`emitVerification()` 的派生调用，`slc/src/verify.ts:5345-5349`；entry emission 的 `linkedOptionsValidator` 同样使用该 loader。

主要 producer/consumer gates 已在本轮反馈后改成 isolated worker，但派生测试、schema reconciliation 和 entry 能力探测仍通过只给顶层文件加 hash query 的 `loadFsmModule` 导入。顶层 FSM 不变而本地传递依赖变化时，父进程仍复用旧实例；新 worker 看到的是新代码，派生 pin/测试却能来自旧代码，不能作为同版证据。

实际复现：`/tmp/slc-review-derive.mjs` 直接调用当前真实 `emitFsmIntrospectionTest`。`flow.fsm.ts` re-export `shape.ts`；首次生成后，给 shape.ts 的 states 新增 `extra`，再次生成结果：`identicalPinsAfterChangedHelper: true`、`secondContainsExtra: false`；随后 Playbook `importFreshArtifact` 读取实际当前模块的 state keys 为 `extra, work, awaitBossReply, failed, done`。产物目录 `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-derive-S7MbRb/`。

另一个初始复现 `/tmp/slc-review-stale.mjs` 显示错误 continuation helper 在同进程直接检查中仍是 `[]`，新 worker 则正确拒绝。这里原 consumer gate 的问题已被主 Agent 修订，**不再作为当前未修 gate 缺陷重复计算**；上述派生读取仍是当前缺口。

依据：`verification-72` 的 fresh transitive state/current revision 要求及派生验证文件与实际被检查 FSM 同版的验证契约。

建议：统一本地 artifact 的 fresh transitive loader，或将派生读取、函数探测和序列化结果一起放入隔离上下文；不要只隔离最终拒绝 gate。补同进程仅修改依赖后重新派生 pin/entry 的集成场景。

## F3 · P2：候选构造/初始化/释放异常被统一误报为 checker crash

位置：`slc/src/verification-worker.ts:51-70`。

`entry.createRuntime`、`runtime.init` 和 `runtime.dispose` 的业务候选异常都进入 worker 最外层 catch，被发成 `error: checker-failed: ...`，父级 isolatedCheck 随即 reject。已确定的候选构造或生命周期缺陷被误归为基础设施故障，丢失 lifecycle 阶段的结构化 artifact finding，也没有正常的 lifecycle findings 记录。

实际复现：`/tmp/slc-review-history.mjs` 通过真实 `runSlc`、临时确定性 pipeline 和无 Agent executor 产出候选 factory，其中构造函数抛 `candidate constructor failed`。当前结果为 `ok:false, diagnostics:["checker-failed: candidate constructor failed"]`。候选目录 `/var/folders/jh/mt3s144j7wg98ww3zyqc1np00000gn/T/slc-history-IKX9pO/`。这是有效拒绝，但原因分类错误，不应当作 compiler worker crash。

依据：`verification-73` 将 established artifact defect 与 checker infrastructure crash 区分；`verification-79` 明确要求具体 constructor/initializer/disposal failure 为 artifact finding。

建议：在生命周期各个候选边界捕获并返回带阶段的 artifact findings，保留 dispose 的 finally 语义和原始失败；只有 checker 导入、worker 本身或基础设施故障走顶层 checker-failed。

## 复核过程中已修订的早期发现

此前 runner 在 managed lifecycle 之前发布 `.slc/builds`/latest；已直接反馈给主 Agent。当前新增 finalize 在 publishIncremental 之前执行。上述真实 `runSlc` 构造失败复现现已验证 `history ENOENT`，不再把该旧顺序算作当前发现。主要 FSM consumer/retained completion 的直接 continuation gate 也已改 isolatedCheck；剩余 fresh-state 问题仅按 F2 的派生产物范围判断。

## 边界与后续

没有验证 SDK 自动 registry acquisition、两个真实 backend、原生 Windows junction/命令、Linux 或真实全局独立安装。这些仍需按 delivery-acceptance 的独立本地/registry 层验收。本轮小型 seams 不构成那些交付通过证据。其他覆盖预算、事件 witness 的复杂有序语义未做穷举；未给它们通过判定。

最终读取时间：2026-11-17T15:51:13.826101+00:00。

源码 SHA-256：
- `slc/src/managed-compilation.ts`: `c76efef7e0c6ada4f56f455c9e629a38221b6dc4058751756ee8ea32e731f587`
- `slc/src/runner.ts`: `169ebd3faae30738448ff1e515b081234ce0b11f5d59549cec704d15506853a8`
- `slc/src/verification-worker.ts`: `e6be426bb39ad57911b5526b20f4872280da42107632fc535eb783008b10f188`
- `slc/src/verify.ts`: `a2c08c7df8feeb0514128ca860feca6d5d21417c43804d20af4c3b3d11d4c848`
- `playbook/src/artifact-environment.ts`: `fae1d5950f23477d7b3528147f8b20d15d5b7b46ab79d00eb6a4c2e2be26967f`
- `playbook/src/fresh-artifact.ts`: `66f439cf5820fedc4d142a2481d95995258fe7de2f70a35aa062ffc72acfe107`
